---
name: brunson-secrets
description: "Book reference only: Russell Brunson's Secrets trilogy (DotCom, Expert, Traffic Secrets). Use when asked what Brunson teaches, for funnel strategy or value-ladder design, hook-story-offer diagnosis, Epiphany Bridge or Perfect Webinar structure, or Dream 100 and traffic strategy. Do NOT use to write Reece copy (use antifragile-copywriter)."
---

<!-- argument-hint: [topic, framework name, or chapter id like b2-ch11] -->

# The Secrets Trilogy: DotCom Secrets · Expert Secrets · Traffic Secrets
**Author**: Russell Brunson | **Words**: ~278K | **Chapters**: 67 (28 + 19 + 20 "Secrets") | **Generated**: 2026-09-18

Chapter ids: **b1** = DotCom Secrets (funnels, value ladder, scripts), **b2** = Expert Secrets (movement, story selling, the Perfect Webinar), **b3** = Traffic Secrets (dream customer, Dream 100, platforms).

## How to Use This Skill
> For Reece copy, use **antifragile-copywriter**; this skill is a strategy reference.
>
> **Most relevant for Reece:** funnel by price (b1-ch03, [cheatsheet](cheatsheet.md)), Hook-Story-Offer diagnosis (b1-ch02, b1-ch28), Epiphany Bridge (b2-ch07 to b2-ch10), follow-up (b1-ch07, b3-ch06), application and phone close (b1-ch17, b1-ch24, b1-ch25), Dream 100 (b3-ch02).

- **No arguments**: use the core frameworks below.
- **Topic** (e.g. `upsells`, `webinar`, `Instagram`): find it in the Topic Index and read that chapter file before answering.
- **Chapter** (e.g. `b2-ch09`): load `chapters/b2-ch09-*.md`.
- **Decisions** (which funnel, what's broken, what threshold applies): read [cheatsheet.md](cheatsheet.md).

If a question isn't answered by the Core Frameworks, read the relevant chapter file before answering.

---

## Core Frameworks & Mental Models

**1. The Secret Formula (b1-ch01).** Answer four questions in order before building anything:
- **Who** is the dream customer?
- **Where** do they congregate?
- What **bait** attracts them?
- What **result** will you give them?

The bait decides who you attract. Build a named, pictured Dream Customer Avatar (b3-ch01), and aim every message at one core desire: health, wealth or relationships. Asking people to hold two beliefs cuts conversion roughly in half.

**2. Hook, Story, Offer (b1-ch02, b3-ch03).** Every ad, page, email and step has all three. Diagnose any failure by asking which one broke:
- **Hook**: stops the scroll.
- **Story**: builds a bond with the Attractive Character and breaks false beliefs.
- **Offer**: is never a commodity. Stack it so the stated value is ≥10x the price.

**3. Value Ladder (b1-ch03).** Offers climb in value and price. Match the funnel type to the price:
- $0: lead funnel
- $1–100: unboxing funnel
- $100–2K: presentation funnel
- $2K+: phone funnel

Continuity sits alongside. Build one funnel and scale it to the **Two Comma Club** ($1M) before building the next. Then stack funnels: the next funnel's entry offer goes on the last page of the previous one (b1-ch27).

**4. Attractive Character (b1-ch04).** Backstory, parables, character flaws and polarity. Choose one identity: Leader, Adventurer, Reporter or Reluctant Hero. Relationships sell; the follow-up (Soap Opera Sequence → daily Seinfeld emails) delivers the character (b1-ch07).

**5. Seven Phases of a Funnel (b1-ch06).**
1. Traffic temperature
2. Pre-frame bridge
3. Qualify subscribers
4. Qualify buyers (right after opt-in)
5. Identify hyperactive buyers
6. Age and ascend
7. Change the selling environment

Each step asks for one action and pre-frames the next. Match the message to temperature: hot sees the offer, warm sees the character, cold sees the problem.

**6. Funnel Hacking (b1-ch05).** Buy and log 6–10 competitor funnels. Model the structure; never copy the words. If nobody is making money in a market, don't enter it.

**7. Funnel Audibles (b1-ch28).** Scale while CPA < ACV; when CPA > ACV, change one element at a time against the control. Test with one full-funnel customer's value (or $100, b3-ch09). Benchmarks are in the cheatsheet.

**8. Movement Formula (b2-ch01, b2-ch06).** Charismatic Leader + New Opportunity + Future-Based Cause. Build identity: a tribe name, "I am an X" statements, a manifesto, and milestone awards. Publish in the Prolific Zone: polarizing but believable. You only need to be one chapter ahead of the person you guide.

**9. New Opportunity > Improvement Offer (b2-ch03, b2-ch04).**
- Improvement ("better / faster") makes the buyer admit failure, so their status drops.
- A new vehicle replaces the old one: an opportunity switch on the front end, an opportunity stack on the back end.
- Create a category rather than fighting the Category King.
- Sell to the Frustrated, not the Diehards.

**10. Epiphany Bridge (b2-ch07 to b2-ch10).** Emotion buys; logic justifies. Retell the story that gave *you* the belief, in five phases:
1. Backstory: start where the listener is now.
2. Journey: the old vehicle fails.
3. New opportunity discovered.
4. Framework.
5. Achievement plus transformation (Hero's Two Journeys).

Map objections with Chains of False Belief. Keep Four Core Stories ready: origin, vehicle, internal and external. Use "kind of like" analogies so a third-grader could follow.

**11. The Perfect Webinar (b1-ch22, b2-ch11 to b2-ch15).**
- **Big Domino**: "If I can make them believe [opportunity] is key to [desire] and only attainable through [vehicle]…"
- Origin story.
- **Three Secrets**: break the vehicle, internal and external false beliefs, with one story each. Teach the *what*, never the *how*.
- **The Stack**: restack on every slide, use If-All statements, then reveal the price.
- **Trial closes** throughout.
- A live-only bonus plus a countdown.

Time ratio: 1/6 for the intro, 1/6 for each secret, 2/6 for the stack and close. It works at 90, 60 or 5 minutes (b2-ch18) or as a whiteboard Shortcut (b2-ch17). Run it live 60+ times before automating it (b2-ch16).

**12. Scripts by stage (b1-ch18 to b1-ch25).**
- Curiosity headlines (hook, curiosity, pre-frame).
- Who-What-Why(PAS)-How for cold video.
- Star-Story-Solution for VSLs.
- OTO: "your order isn't complete".
- Four-video product launch.
- Four Question Close (Dan Sullivan Question, then stay silent after the ask).
- Setter + Closer with four commitments.
- Takeaway selling: the prospect must convince you.

**13. Traffic: Dream 100 and "Own > Control > Earn" (b3-ch02, b3-ch04, b3-ch05).**
- List 100+ people who already congregate your dream customers, per platform.
- **Work your way in** (relationships, guest spots, your own show).
- **Buy your way in** (ads to their audiences).
- Turn all traffic into **traffic you own** (lists at ≈$1 per name per month).
- Dig your well before you're thirsty.

**14. Fill Your Funnel on any platform (b3-ch07 to b3-ch15).**
1. Learn the platform's history and algorithm goal.
2. Model your Dream 100 there.
3. Set a publishing plan (daily, "document, don't create").
4. Work in.
5. Buy in.
6. Point to a funnel.

Master one platform for 12 months, then pursue **Conversation Domination** through a Master Show cut into each platform's native formats. Ads: prospect heavily, retarget people who engaged (5 days) and landed (7 days).

**15. Growth hacking (b3-ch16 to b3-ch20).** A Funnel Hub captures the Shadow Funnel. OPDC: solo ads priced from click history, integration marketing. An Affiliate Army: ask ~100 to get ~15 promoting, pay ~50% of profit. Cold traffic needs a bridge (an article page, then a lead funnel). Build viral loops: tell-a-friend pages and a default-on badge.

---

## Chapter Index

### b1 — DotCom Secrets
| id | Title | Key frameworks |
|---|---|---|
| [b1-ch01](chapters/b1-ch01-secret-formula.md) | The Secret Formula | 4 questions, Dream Customer Avatar |
| [b1-ch02](chapters/b1-ch02-hook-story-offer.md) | Hook, Story, Offer | HSO, Offer Stack, 10x rule |
| [b1-ch03](chapters/b1-ch03-value-ladder.md) | The Value Ladder | Value Ladder, VLMS, Two Comma Club |
| [b1-ch04](chapters/b1-ch04-attractive-character.md) | The Attractive Character | 4 identities, 6 storylines, polarity |
| [b1-ch05](chapters/b1-ch05-funnel-hacking.md) | Funnel Hacking | Modeling vs copying |
| [b1-ch06](chapters/b1-ch06-seven-phases-of-a-funnel.md) | Seven Phases of a Funnel | Pre-frame, traffic temperature |
| [b1-ch07](chapters/b1-ch07-follow-up-funnels.md) | Follow-Up Funnels | Soap Opera Sequence, Seinfeld, own/control/earn |
| [b1-ch08](chapters/b1-ch08-lead-squeeze-funnels.md) | Lead Squeeze Funnels | Lead magnet, reverse squeeze |
| [b1-ch09](chapters/b1-ch09-survey-funnels.md) | Survey Funnels | Bucket question, calculating page |
| [b1-ch10](chapters/b1-ch10-summit-funnels.md) | Summit Funnels | Virtual summit, All-Access Pass *(low relevance: online/info-product)* |
| [b1-ch11](chapters/b1-ch11-book-funnels.md) | Book Funnels | Free+shipping, bump, OTO, CPA vs ACV *(low relevance: online/info-product)* |
| [b1-ch12](chapters/b1-ch12-cart-funnels.md) | Cart Funnels | Bestseller bundle, offer wall *(low relevance: online/info-product)* |
| [b1-ch13](chapters/b1-ch13-challenge-funnels.md) | Challenge Funnels | Paid challenge, completion upsells *(low relevance: online/info-product)* |
| [b1-ch14](chapters/b1-ch14-video-sales-letter-funnels.md) | VSL Funnels | Spoiler box, hidden CTA |
| [b1-ch15](chapters/b1-ch15-webinar-funnels.md) | Webinar Funnels | Live→automated, replay deadline, SLO |
| [b1-ch16](chapters/b1-ch16-product-launch-funnels.md) | Product Launch Funnels | Sideways sales letter *(low relevance: online/info-product)* |
| [b1-ch17](chapters/b1-ch17-application-funnels.md) | Application Funnels | Takeaway sale, revenue qualifier |
| [b1-ch18](chapters/b1-ch18-curiosity-headline-scripts.md) | Curiosity Headline Scripts | Hot/warm/cold headlines |
| [b1-ch19](chapters/b1-ch19-who-what-why-how-script.md) | Who What Why How Script | PAS, 4 amplifiers |
| [b1-ch20](chapters/b1-ch20-star-story-solution-script.md) | Star Story Solution Script | If-All close, 10x anchor |
| [b1-ch21](chapters/b1-ch21-oto-script.md) | OTO Script | Open loop, the one thing |
| [b1-ch22](chapters/b1-ch22-perfect-webinar-script.md) | Perfect Webinar Script | Stack, 3 secrets |
| [b1-ch23](chapters/b1-ch23-product-launch-script.md) | Product Launch Script | 4-video launch *(low relevance: online/info-product)* |
| [b1-ch24](chapters/b1-ch24-four-question-close-script.md) | Four Question Close | Dan Sullivan Question |
| [b1-ch25](chapters/b1-ch25-setter-closer-scripts.md) | Setter & Closer Scripts | Four commitments |
| [b1-ch26](chapters/b1-ch26-clickfunnels.md) | ClickFunnels | Funnel by price, build process *(low relevance: online/info-product)* |
| [b1-ch27](chapters/b1-ch27-funnel-stacking.md) | Funnel Stacking | Ascension points, $1M gate |
| [b1-ch28](chapters/b1-ch28-funnel-audibles.md) | Funnel Audibles | Benchmarks, marketing math, 12-step recap |

### b2 — Expert Secrets
| id | Title | Key frameworks |
|---|---|---|
| [b2-ch01](chapters/b2-ch01-finding-your-voice.md) | Finding Your Voice | Movement Formula, 5 phases to expert, Prolific Zone |
| [b2-ch02](chapters/b2-ch02-teaching-your-frameworks.md) | Teaching Your Frameworks | Framework for Teaching Frameworks |
| [b2-ch03](chapters/b2-ch03-three-core-markets.md) | Three Core Markets | Category King, Frustrated buyers |
| [b2-ch04](chapters/b2-ch04-new-opportunity.md) | The New Opportunity | Opportunity switch/stack, status |
| [b2-ch05](chapters/b2-ch05-irresistible-offer.md) | More Money for the Same Framework | Repackaging, Stack Slide |
| [b2-ch06](chapters/b2-ch06-future-based-cause.md) | The Future-Based Cause | Identity shift, manifesto, awards |
| [b2-ch07](chapters/b2-ch07-story-selling.md) | The Epiphany Bridge | Emotion→logic, Kind of Like Bridge |
| [b2-ch08](chapters/b2-ch08-heros-two-journeys.md) | The Hero's Two Journeys | Character/desire/conflict |
| [b2-ch09](chapters/b2-ch09-epiphany-bridge-script.md) | Epiphany Bridge Script | 5 phases / 14 questions |
| [b2-ch10](chapters/b2-ch10-four-core-stories.md) | The Four Core Stories | Chains of False Belief |
| [b2-ch11](chapters/b2-ch11-perfect-webinar-framework.md) | Perfect Webinar Framework | 3 phases, time ratio |
| [b2-ch12](chapters/b2-ch12-big-domino.md) | The Big Domino | Domino statement, the Ruler |
| [b2-ch13](chapters/b2-ch13-three-secrets.md) | The Three Secrets | Vehicle/internal/external beliefs |
| [b2-ch14](chapters/b2-ch14-stack-and-closes.md) | The Stack and the Closes | Restacking, If-All |
| [b2-ch15](chapters/b2-ch15-trial-closes.md) | Trial Closes | 16 closes |
| [b2-ch16](chapters/b2-ch16-testing-live.md) | Testing Your Presentation Live | Live webinar funnel, metrics |
| [b2-ch17](chapters/b2-ch17-perfect-webinar-shortcut.md) | Perfect Webinar Shortcut | 8-question cheat sheet |
| [b2-ch18](chapters/b2-ch18-five-minute-perfect-webinar.md) | Five-Minute Perfect Webinar | Price-to-length rule *(thin)* |
| [b2-ch19](chapters/b2-ch19-expert-secrets-value-ladder.md) | Plugging Into Your Value Ladder | Sideways PW, emailed PW |

### b3 — Traffic Secrets
| id | Title | Key frameworks |
|---|---|---|
| [b3-ch01](chapters/b3-ch01-dream-customer.md) | Your Dream Customer | Avatar, searcher vs scroller |
| [b3-ch02](chapters/b3-ch02-dream-100.md) | The Dream 100 | Congregations, one-to-one/one-to-many |
| [b3-ch03](chapters/b3-ch03-hook-story-offer-attractive-character.md) | HSO & Attractive Character | HSO diagnosis *(thin)* |
| [b3-ch04](chapters/b3-ch04-work-your-way-in-buy-your-way-in.md) | Work Your Way In / Buy Your Way In | Earn vs control, break-even |
| [b3-ch05](chapters/b3-ch05-traffic-you-own.md) | Traffic That You Own | $1/name/month |
| [b3-ch06](chapters/b3-ch06-follow-up-funnels.md) | Follow-Up Funnels | Three closes, multi-channel |
| [b3-ch07](chapters/b3-ch07-infiltrating-dream-100.md) | Infiltrating the Dream 100 | Your own show, Fill Your Funnel |
| [b3-ch08](chapters/b3-ch08-fill-funnel-organically.md) | Fill Your Funnel Organically | Party & House *(thin)* |
| [b3-ch09](chapters/b3-ch09-fill-funnel-paid-ads.md) | Fill Your Funnel with Paid Ads | Prospecting, retargeting |
| [b3-ch10](chapters/b3-ch10-instagram.md) | Instagram | JK5, Highlights mini-webinar |
| [b3-ch11](chapters/b3-ch11-facebook.md) | Facebook | 4 areas, boost test |
| [b3-ch12](chapters/b3-ch12-google.md) | Google | Skyscraper, 10×10 keywords |
| [b3-ch13](chapters/b3-ch13-youtube.md) | YouTube | Focus phrase, A-B-C hack, playlists |
| [b3-ch14](chapters/b3-ch14-after-the-slaps-and-snaps.md) | After the Slaps and Snaps | Any platform, podcasts |
| [b3-ch15](chapters/b3-ch15-conversation-domination.md) | Conversation Domination | Master Show, one platform first |
| [b3-ch16](chapters/b3-ch16-funnel-hub.md) | The Funnel Hub | Shadow Funnel |
| [b3-ch17](chapters/b3-ch17-other-peoples-distribution-channels.md) | Other People's Distribution Channels | Solo ads, integration marketing |
| [b3-ch18](chapters/b3-ch18-affiliate-army.md) | Your Affiliate Army | Recruitment, commissions, rolling launch *(low relevance: online/info-product)* |
| [b3-ch19](chapters/b3-ch19-cold-traffic.md) | Cold Traffic | Food Court Test, cold bridge |
| [b3-ch20](chapters/b3-ch20-other-growth-hacks.md) | Other Growth Hacks + Conclusion | Viral loops, 5-step plan |

## Topic Index
- **Ads (paid) / retargeting** → b3-ch09, b3-ch04, b1-ch28, b3-ch11
- **Affiliates / JV** → b3-ch18, b1-ch10, b1-ch16
- **Application / high-ticket** → b1-ch17, b1-ch24, b1-ch25
- **Attractive Character** → b1-ch04, b3-ch03, b2-ch01
- **Benchmarks / metrics** → b1-ch28, b2-ch16, b3-ch13
- **Big Domino / beliefs** → b2-ch12, b2-ch13, b2-ch10
- **Book / free+shipping** → b1-ch11
- **Challenge** → b1-ch13
- **Closing / sales calls** → b1-ch24, b1-ch25, b2-ch14, b2-ch15
- **Cold traffic** → b3-ch19, b1-ch06
- **Community / movement** → b2-ch01, b2-ch06
- **Dream 100** → b3-ch02, b3-ch04, b3-ch07
- **Dream customer / avatar** → b1-ch01, b3-ch01
- **Email / follow-up** → b1-ch07, b3-ch06, b2-ch19
- **E-commerce / physical** → b1-ch12
- **Epiphany Bridge / storytelling** → b2-ch07, b2-ch08, b2-ch09, b2-ch10, b1-ch20
- **Facebook / Instagram / YouTube / Google / podcasts** → b3-ch11 / b3-ch10 / b3-ch13 / b3-ch12 / b3-ch14
- **Frameworks (teaching)** → b2-ch02
- **Funnel hacking** → b1-ch05
- **Funnel stacking / ascension** → b1-ch27, b3-ch06
- **Headlines / hooks** → b1-ch18, b1-ch02
- **Lead funnels** → b1-ch08, b1-ch09, b1-ch10
- **Market selection / positioning** → b2-ch03, b2-ch04
- **Offer / stack / pricing** → b1-ch02, b2-ch05, b2-ch14
- **Organic content / publishing** → b3-ch07, b3-ch08, b3-ch15
- **Perfect Webinar** → b1-ch22, b2-ch11–b2-ch18
- **Pre-frame / traffic temperature** → b1-ch06
- **Product launch** → b1-ch16, b1-ch23
- **Upsells / OTO / order bump** → b1-ch11, b1-ch21
- **Value Ladder** → b1-ch03, b2-ch19
- **VSL** → b1-ch14, b1-ch20
- **Webinar funnels** → b1-ch15, b2-ch16
- **Viral / growth hacks** → b3-ch16, b3-ch17, b3-ch20

## Supporting Files
- [glossary.md](glossary.md): key terms with chapter references
- [patterns.md](patterns.md): techniques with when, how and trade-offs
- [cheatsheet.md](cheatsheet.md): funnel-by-price table, diagnostics, benchmarks, thresholds, positioning tree

---

## Scope & Limits
These are synthesized summaries of the three books, not the book text. Traffic Secrets platform tactics date from 2020 and may be stale; the frameworks hold. Chapters tagged "low relevance" cover online and info-product funnels that rarely fit a local, in-home-sales business. Numbers quoted are Brunson's own examples, not guarantees. For a specific business, combine this skill with real funnel data.
