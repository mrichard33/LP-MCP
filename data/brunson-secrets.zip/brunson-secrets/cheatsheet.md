# Cheatsheet — Decide Like Brunson

## Which funnel? (by price)
| Price | Funnel family | Script |
|---|---|---|
| $0 | Lead: squeeze, survey, summit | Curiosity headline (b1-ch18), Who What Why How (b1-ch19) |
| $1–100 | Unboxing: book, cart, challenge | Star Story Solution (b1-ch20), OTO script (b1-ch21) |
| $100–2K | Presentation: VSL, webinar, launch | Perfect Webinar (b1-ch22), Product Launch (b1-ch23) |
| $2K+ | Phone: application → call | Four Question Close (b1-ch24), Setter/Closer (b1-ch25) |
Under ~$100 but needs explaining → 5-min Perfect Webinar or a 20–30 min VSL. The higher the price, the longer the presentation.

## Diagnose a failing step
- **Low CTR / opt-in** → hook problem; test new hooks and headlines first. Doubling CTR can multiply profit many times over.
- **Clicks but no sale** → story (belief not broken) or offer (commodity; stack < 10x).
- **CPA > ACV** → call an audible on one step at a time; don't scale.
- **CPA < ACV** → scale spend now.
- **Front end loses money** → check break-even on day X of follow-up before killing it.
- **Webinar cost per registrant > $3–5** → fix the page, message or targeting before scaling.
- **Show-up < 25%** → add indoctrination and reminders (day before, morning of, −1h, −15m, live).

## Benchmarks (b1-ch28)
Opt-in >20% · two-step order form >10–15% · book/cart sale 1–5% · order bump >20% · OTO/downsell 3–15% · VSL 1–3% · webinar registration >20% · live show-up 10–20% · auto show-up 50–80% · live webinar buy rate >10% hot / 1–5% cold · auto-webinar 3–8% · cost per application <$100.
Webinar close rate among people at the pitch: 5% = profitable, 10% ≈ $1M/yr, 15% ≈ $10M/yr (b2-ch16).

## Hard rules & thresholds
- **One desire, one belief per message.** Each extra belief roughly halves conversion (b2-ch03, b2-ch12).
- **Stack ≥10x price** before revealing the price (b2-ch05).
- **Time ratio**: intro, secret 1, secret 2 and secret 3 get 1/6 each; the stack and close gets 2/6. For 90 minutes that's 15/15/15/15/30 (b2-ch11).
- **Trial closes** after every case study; one test lifted earnings per registrant 75% (b2-ch15).
- **Live before automated**: 60+ live runs or $1M before automating (b2-ch16).
- **Two Comma Club gate**: don't build funnel #2 until #1 has done $1M (b1-ch27, b3-ch20).
- **One platform for 12 months** before expanding (b3-ch15).
- **List value** ≈ $1 per name per month, so target list size ≈ annual income goal ÷ 12 (b3-ch05).
- **Info-funnel upsells**: at most 2 (or 1 + downsell), never "more of the same". **Physical products**: the first upsell is more of the same at a buyer's discount (b1-ch11, b1-ch12).
- **Test budget**: $100, or one full-funnel customer's value (b3-ch09, b1-ch28).
- **Dream 100 odds**: 100 asked → ~30 say yes → ~10 promote; buy ads to the rest (b3-ch04).
- **Affiliates**: ask ~100 to get ~15 promoting; recruit 60–90 days out; pay ~50% of profit (b3-ch18).
- **Replays** stay up 48–72h with a real deadline; ~80% of registrants miss the live event (b1-ch15).
- **Urgency must be real**: seats, stock, deadline (b1-ch07).

## Positioning decision tree
- Is your pitch "better / faster / -er"? → Reframe it as a **New Opportunity** (b2-ch04).
- Third or later into a niche? → Create your own **category** (b2-ch03).
- Is the prospect a Diehard for a competitor? → Stop selling to them; target the **Frustrated** (b2-ch03).
- Mainstream message nobody objects to? → Push toward polarity (the **Prolific Zone**) (b2-ch01).
- No credentials? → Take the **Reporter** identity; serve people one chapter behind you (b1-ch04, b2-ch01).

## Traffic temperature → message
| Temp | Who | Lead with | Bridge |
|---|---|---|---|
| Hot | Your lists | The offer | None |
| Warm | Dream 100 audiences | The Attractive Character plus a borrowed endorsement | Short |
| Cold | Problem-aware strangers | The problem, in their words | Article or lead funnel, then content (b3-ch19) |

## Tells & smells
- A headline about *you* or one that reveals the answer → rewrite it about the reader with a curiosity gap.
- Saying "order complete" before the OTO → you've closed the buying loop.
- A prospect who blames a spouse or a past program → don't enrol them.
- Teaching the *how* in a pitch → you're in teacher mode, and sales fall.
- Asking for two actions on one page → a confused mind says no.
- Stats checked before episode ~40 → too early; your voice hasn't formed yet.
