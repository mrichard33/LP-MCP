# Patterns & Techniques — Secrets Trilogy

## Funnel Hacking (Buy-and-Log)
**When to use**: Before building any new funnel.
**How**: Buy 6–10 competitor funnels, including the upsells. Log the Hook, Story and Offer on every page. Model the structure and pricing, and write your own words. (b1-ch05)
**Trade-offs**: Costs money and time. If nobody is selling in the market, don't build, because there is no proof that buyers exist.

## Hook, Story, Offer Diagnosis
**When to use**: Any ad, page or email underperforms.
**How**: Low CTR or opt-in rate: test new hooks. Engaged but not buying: fix the story, then the offer. Change one element at a time against the control. (b1-ch02, b1-ch28, b3-ch03)
**Trade-offs**: You need enough traffic to isolate which element is at fault.

## Offer Stack (10x Rule)
**When to use**: Pricing any offer, or when you meet price resistance.
**How**: Core product + framework + tools + one bonus per false belief (vehicle, internal, external). Re-show the growing stack as you add each item. Stated value should be ≥10x the price. Favor tools over more information. (b1-ch02, b2-ch05, b2-ch14)
**Trade-offs**: Inflated values erode trust, and bundling adds fulfillment cost.

## Value Ladder Funnel Selection
**When to use**: Deciding which funnel to build.
**How**: $0 → lead funnel (squeeze, survey, summit). $1–100 → unboxing (book, cart, challenge). $100–2K → presentation (VSL, webinar, launch). $2K+ → phone (application + setter/closer). Build one funnel and take it to $1M before adding the next. (b1-ch03, b1-ch26, b1-ch27)
**Trade-offs**: Focusing on one funnel delays diversification.

## Free-Plus-Shipping Unboxing
**When to use**: Cold traffic with an info or physical front end.
**How**: Free item plus shipping → order bump → OTO1 (the core product) → OTO2 or a downsell. Keep "No thanks" links loss-framed. Never say "thank you" until the last offer. (b1-ch11, b1-ch21)
**Trade-offs**: Shipping logistics; buyers are cheaper to acquire but lower intent.

## Soap Opera Sequence → Seinfeld
**When to use**: Every new subscriber or buyer.
**How**: A five-email sequence (set the stage, high drama and backstory, epiphany, hidden benefits, urgency), each ending on an open loop. Then send daily Seinfeld broadcasts (~90% entertainment, one offer each). (b1-ch07, b3-ch06)
**Trade-offs**: Requires daily writing discipline.

## Three Closes Email Sequence
**When to use**: Selling to a list without a live event.
**How**: Emotion emails (stories), then logic emails, then fear emails (real urgency or scarcity). One version is five emotional Perfect Webinar emails plus 2–4 logic and fear emails. (b3-ch06, b2-ch19)
**Trade-offs**: Each email gets less attention than a live pitch.

## Perfect Webinar
**When to use**: Any one-to-many sale of $100 or more.
**How**:
- Intro: Big Domino statement, Ruler, origin story.
- Three Secrets: one story each, breaking the vehicle, internal and external beliefs.
- Stack and closes: If-All statements, price reveal, trial closes throughout, then a live-only bonus with a countdown.
- Timing: 1/6 per section and 2/6 for the stack, whatever the length. (b1-ch22, b2-ch11–15)

**Trade-offs**: Needs a real story for each belief. Over-teaching tactics kills sales.

## Epiphany Bridge Story
**When to use**: Whenever someone asks "what is X?", or you meet resistance to logic.
**How**: Backstory (start where they are now), the journey with the old vehicle failing, discovering the new opportunity, the framework, achievement plus transformation. Use a 30-second version with one sentence per phase. (b2-ch07–10)
**Trade-offs**: The long form needs a time budget, so scale it to the channel.

## Four Question Close / Setter–Closer
**When to use**: $2K+ offers after an application funnel.
**How**: Frame the call, then ask about their desired future, obstacles and resources, review them, and ask "Do you want my help?". Stay silent until they answer. With a team, the setter qualifies (pain, goals, finances) and the closer runs four commitments: time, coachability, decisiveness and resources. (b1-ch24, b1-ch25)
**Trade-offs**: Lower volume and higher fit; turn away people who blame others.

## Dream 100 Infiltration
**When to use**: The start of any traffic plan.
**How**: List 100+ congregations per platform. Days 0–14: consume and comment. Days 15–30: send no-pitch DMs. Days 31–60: send them your free product, then ask. Buy ads to the audiences of the members who say no. Use your own show as leverage. (b3-ch02, b3-ch04, b3-ch07)
**Trade-offs**: Slow, and needs PHD (pig-headed discipline).

## Fill Your Funnel Framework (Any Platform)
**When to use**: Entering a new platform.
**How**: Learn the platform's history and algorithm goal. Model your Dream 100 there. Set a publishing plan. Work your way in (organic content and collaborations). Buy your way in (ads to Dream 100 audiences). Every call to action points to a funnel. (b3-ch07, b3-ch10–14)
**Trade-offs**: Platform tactics date quickly; the framework itself holds.

## Prospecting + Retargeting Ads
**When to use**: Buying your way in.
**How**: Test each funnel with $100. Prospect with a high volume of creative (roughly 80% of spend for 20% of results). Retarget people who engaged (5 days), landed (7 days) and your owned lists (ongoing). Scale while CPA < ACV. (b3-ch09, b1-ch28)
**Trade-offs**: Ads fatigue in weeks, so creative production never stops.

## Publishing Strategy → Conversation Domination
**When to use**: Building an audience.
**How**: Publish daily on one primary platform plus email for 12 months ("document, don't create"). Then run a weekly Master Show cut into each platform's native formats. Seed each new asset to your owned lists before paying for ads. (b3-ch07, b3-ch15)
**Trade-offs**: Needs a production team to scale.

## Affiliate Army Launch
**When to use**: Proven webinar or front end with a known LTV.
**How**: Ask about 100 partners to get about 15 promoting. Start recruiting 60–90 days before the launch. Provide an affiliate center with swipes, contests and bonuses. Pay about 50% of profit, and up to 100%+ on the front end once LTV is known. Run it as a group or rolling launch. (b3-ch18)
**Trade-offs**: Cash float and support load.

## Cold Traffic Bridge
**When to use**: Scaling past warm and hot audiences.
**How**: Article-style landing page → lead funnel → content follow-up → front-end offer. Pass the Food Court Test (would strangers raise their hands?). Budget a payback period of 1 week to 3+ months. (b3-ch19, b1-ch06)
**Trade-offs**: Slower payback; sending cold clicks straight to a warm funnel fails.

## Funnel Stacking
**When to use**: You have a second funnel.
**How**: Put the next funnel's entry offer on the prior funnel's final or thank-you page and in its follow-up emails. (b1-ch27)
**Trade-offs**: May distract slow-moving buyers.

## Survey / Bucket Routing
**When to use**: Several buyer types for one product.
**How**: One bucket question plus engagement questions → a "calculating" page → opt-in → a results page and email sequence for each bucket. (b1-ch09)
**Trade-offs**: Content multiplies with every bucket.

## Challenge Funnel
**When to use**: Webinar fatigue or weak free-book economics.
**How**: A $47 challenge lasting 14–30 days with one clear promise of X in Y days. Bumps and upsells should help people complete it. End with a Perfect Webinar pitch. (b1-ch13)
**Trade-offs**: Heavy live-delivery workload.

## Growth Hacks
**When to use**: Signup or registration flows.
**How**: Tell-a-friend page that rewards referrals with a gift. Default-on "made with" affiliate badge. Integration slots in partners' sales processes. Solo ads priced from click history. (b3-ch17, b3-ch20)
**Trade-offs**: Some users find these intrusive.
