# Traffic Secrets — Secret #4: Work Your Way In, Buy Your Way In

## Core Idea
With your Dream 100 built, you reach their audiences two ways. You **Work Your Way In** by earning endorsements, which is Traffic You Earn and is paid for with time. You **Buy Your Way In** by targeting their followers with ads, which is Traffic You Control and is paid for with money. Start by digging your well before you're thirsty. Run both at once, and scale paid traffic only behind a break-even (or better) funnel.

## Frameworks Introduced
**Dig Your Well Before You're Thirsty (Harvey Mackay)**: build the relationship long before you need anything.
- When to use: the moment someone goes on your Dream 100, not when your product is ready.
- How: (1) **Subscribe to everything** they publish. Use a dedicated email address with a folder filter per person so you can skim their last dozen emails before any contact. (2) **Buy their products** (funnel hacking) to see their back end and become a real customer who can praise them. (3) **Serve them**: post about their podcast or product and tag them, send gifts, make assets they can use. Use social apps only to produce content and to "spy." Brunson spends about 15 minutes twice a day scanning.
- Why it works / failure mode: owners respond to people they recognize and who have given first. Failure mode: showing up asking for something with no idea who they are.

**The Four-Phase Dream 100 Relationship Timeline** (the ClickFunnels launch):
- **Phase 1 (days 1–14)**: follow, consume, and comment meaningfully. Look for ways to serve.
- **Phase 2 (days 15–30)**: open a dialogue by email or DM, with no pitch.
  - Red flags: templated or copy-paste messages; telling your own story too soon (that asks them to serve you).
  - Green lights: they've already seen your face in their comments; you tell them specifically how they've impacted you; you've done your homework on their family, passions and topics; you ask for nothing yet. Treat it like dating.
- **Phase 3 (days 31–60)**: make them a fan. Give free access to the product (free accounts, books, courses). Never ask anyone to promote something they haven't experienced.
- **Then (Phase 4)**: Work Your Way In and Buy Your Way In.

**Work Your Way In: Traffic You Earn (the Hollywood virtual book tour)**: get featured on your Dream 100's platforms the way stars do talk shows the week before a premiere.
- How: send pre-release versions, follow up with a certified letter, offer an affiliate commission (e.g., $20 per book), and ask for an interview, an email to their list, a review or a story post. Let each promote in whatever way suits them. Advanced move: be interviewed on *their* page (not yours), then ask to be added as an ad-account user and pay to boost that video to their audience yourself while still paying their commission.
- Ongoing cadence: aim for at least **2 guest interviews per week**, each ending with a CTA to your current funnel.
- Trade-offs: converts better than almost any paid traffic but is harder to scale; costs time, not money. Start here with no budget (Brunson's first 8 years were all earned traffic). Once consistent, it reaches critical mass and keeps running.

**Buy Your Way In: Traffic You Control**: target the followers of Dream 100 members with paid ads.
- Why: (1) it's fast, with immediate feedback; (2) it tests hooks on each audience before you get an interview (dozens of headlines and images were tested on Tony Robbins's audience first); (3) about 90% of the Dream 100 will never promote you, and this still reaches their audiences, including people who dislike you; (4) it's how you scale fast.
- Expected yield when you pitch 100 people: about 30 say yes and about 10 actually promote.

**Break-Even Funnel / Average Cart Value (ACV)**: design the front end so that each $1 in ads returns at least $1 immediately. Then you effectively no longer have an advertising budget, and the back end (a core offer such as ClickFunnels at $97/mo) is pure profit.

## Key Concepts
- **Traffic You Earn**: endorsements and appearances, paid for with time.
- **Traffic You Control**: paid ads aimed at Dream 100 audiences, paid for with money.
- **Funnel hacking**: buying competitors' products to study their funnels and back end.
- **ACV (Average Cart Value)**: total front-end revenue per buyer across the product, bump and OTOs.
- **Order form bump**: a checkbox add-on on the order form.
- **OTO (one-time offer)**: a one-click upsell right after purchase.
- **CPA**: cost per acquisition. ClickFunnels trials once cost about $250, which is why those ads were turned off.
- **Virtual book tour**: a coordinated wave of Dream 100 interviews around a launch.

## Mental Models
- Use earned traffic first when you have no budget; add paid traffic to speed up, test hooks, and reach the ~90% who won't promote you.
- Think of paid traffic as a faucet: turn off the ads and the traffic stops. Earned traffic becomes a spring once it reaches critical mass.
- Think of a break-even front end as "no ad budget." Spend is unlimited as long as ACV ≥ CPA.
- Use Dream 100 audiences as a hook-testing lab before your big endorsement moment.

## Anti-patterns
- **Waiting until launch to build relationships**: the well is dry when you need it.
- **Templated outreach / telling your story first / asking early**: guarantees a "no."
- **Only paid ads**: you're at the mercy of Google or Facebook policy changes.
- **Only earned traffic**: you depend entirely on others to spread your message.
- **Scaling on VC money**: the "steroids" route. Scale with a profitable funnel instead.
- **Getting interviewed on your own page**: only your people see it. Get interviewed on theirs.

## Worked Example
*DotCom Secrets* book funnel (ad cost of about $23 per buyer):
| Step | Price × take rate | Adds | Running ACV | Net vs. $23 |
|---|---|---|---|---|
| Free book + S&H | $7.95 | $7.95 | $7.95 | −$15.05 |
| Order bump (audiobook) | $37 × 20.8% | $7.70 | $15.65 | −$7.35 |
| OTO1 (course) | $97 × 9.92% | $9.62 | $25.27 | +$2.27 |
| OTO2 (traffic course) | $297 × 4.19% | $12.44 | $37.71 | **+$14.71** |
After that, a 90-day follow-up funnel (email, retargeting, Messenger) moved buyers into ClickFunnels at $97/mo. Spend grew from $100/day to $25,000+/day. The Expert Secrets launch used a Tony Robbins interview on his page plus ads through his account: 2.8M views in launch week and 71,248 copies sold, against about 10K for an average NYT bestseller's opening week. The ClickFunnels launch Dream 100 grew to 736 names, which became the source of most of 100,648 paying members.

## Key Takeaways
1. Start digging your well the day you add a name. Subscribe, buy, and serve before you ask for anything.
2. Follow the 60-day phases: consume and comment, then a no-pitch dialogue, then free product access, and only then ask.
3. Book at least 2 podcast/guest interviews per week, each with a funnel CTA.
4. Run interest-targeted ads to Dream 100 audiences at the same time to test hooks and reach non-promoters.
5. Build a front end with a bump and 2 OTOs until ACV covers CPA, then scale spend.
6. Balance earned and controlled traffic, then convert both into traffic you own (b3-ch05).

## Connects To
b3-ch02 (Dream 100), b3-ch05 (Traffic You Own), b3-ch07 (infiltrating the Dream 100 in detail), b3-ch09 (paid ads), b3-ch11 (Facebook), b3-ch18 (affiliate army), b1-ch03 (value ladder), b1-ch05 (funnel hacking), b1-ch07 (follow-up funnels), b1 book funnel/OTOs.
