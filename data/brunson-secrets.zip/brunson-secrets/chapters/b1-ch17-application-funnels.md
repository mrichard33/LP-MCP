# Dotcom Secrets Secret 17: Application Funnels

## Core Idea
Sell high-ticket offers ($2,000+) by generating leads online and closing them on the phone—but only call people who have applied and sold you on why you should work with them. A three-page application funnel (success story/case study → application → homework) pre-qualifies, pre-frames, and pre-sells prospects so two salespeople can outperform a 60-person call center. This chapter's range also opens Section 3 (Funnel Scripts): scripts are frameworks, not word-for-word copy.

## Frameworks Introduced

**Application Funnel (3 pages)**: Success Story / Free Case Study page → Application page → Homework page → phone call.
- When to use: Coaching, consulting, services, or programs priced roughly $2,000–$100,000 where you want to screen who you work with.
- How:
  1. **Success story or free case study page** — cast the vision of the result. Either a client tells their story of working with you, or you walk through a case study showing the *strategy* (what), not the *tactics* (how). Three goals: watch the video, invite them to apply, capture email for follow-up if they abandon.
  2. **Application page** — long-form application that makes them sell you (takeaway sale). Add a video explaining what working with you looks like and a testimonial rush (back-to-back video testimonials) playing while they fill it out. Core questions below.
  3. **Homework page** — (a) build connection with your attractive character via your story video; (b) tell them what happens next and give prep homework (watch/read) to pre-induct; (c) get them to call *you*.
- Why it works: Positioning flips—the prospect is persuading you. Applicants who call in are worth about 4x those you call.
- Failure mode: Calling every buyer (the old DVD call-center model): huge overhead (~$1M/month) and low efficiency.

**Application Questions (qualification set)**:
- **Revenue qualifier** (disguised ability-to-pay): business type, monthly ad spend, how often they eat out, monthly investing, past spend solving this problem.
- **What does success look like?** — use the Dan Sullivan Question (imagine three years from now looking back: what must have happened personally and professionally for you to be happy?). Reject visions you can't satisfy (e.g., $10M in 12 months with no product).
- **Why would you be a good fit for the group?** — makes them sell themselves; protects group integrity.
- **How can you contribute to the group?** — attract givers, repel takers.

**Funnel Scripts as Frameworks (Section 3 intro)**: a funnel captures your best pitch once and runs it forever; the script (sales copy) is the biggest lever. Weave your stories, attractive character, and message into each script rather than reading it verbatim.

## Key Concepts
- **Takeaway sale** — positioning where the prospect must convince you to accept them.
- **Success story page** — client testimonial video as the funnel's front door.
- **Free case study** — you show what you did (strategy) and withhold how (tactics).
- **Testimonial rush** — stacked video testimonials playing during the application.
- **Revenue qualifier** — indirect question revealing whether they *can* pay, not just want to.
- **Dan Sullivan Question** — three-years-from-now success question.
- **Pre-induction homework** — pre-call content that increases close rate.
- **Inbound call premium** — applicants who call you are worth ~4x.

## Mental Models
- Think of the application as the prospect's sales pitch to you.
- Use "strategy, not tactics" content when you want curiosity to drive applications.
- Think of fewer, better calls: only call the cream of the crop who applied.

## Anti-patterns
- **Asking "can you afford it?" directly**: disguise the revenue qualifier instead.
- **Accepting mis-aligned success visions**: you will never make them happy.
- **Cold-calling every buyer**: expensive, inefficient, burnt-out team.
- **Teaching the how on the case study**: removes the reason to apply.
- **Treating scripts as word-for-word**: loses the attractive character that keeps people ascending.

## Worked Example
Matt Bacak's model: sell a free CD for $4.95 shipping → call buyers a few days later → 1 in 10 bought an $8,000 in-office workshop. Russell copied it in a crisis: burned a best-seller to DVD, sold 800+ at $4.95 to his list, called everyone ("did you watch it yet?"), and by Christmas 11 people had wired $5,500 each for a January workshop. Scaled to 60 reps and 6,000 DVDs/week but ~$1M/month overhead, so it was shut down. Later version: email best customers inviting applications → dozens of applications within hours → two reps call applicants. Result: similar gross revenue and nearly 10x the net versus the 60-person call center.

## Key Takeaways
1. For $2,000+ offers, build a three-page application funnel instead of a sales page.
2. Lead with a success story or strategy-only case study; capture email on page one.
3. Make the application do the selling: disguised revenue qualifier, Dan Sullivan success question, fit, contribution.
4. Use the homework page to deepen connection, pre-induct, and prompt applicants to call you (4x value).
5. Staff with a setter/closer pair (b1-ch25) or use the Four Question Close yourself (b1-ch24).

## Connects To
b1-ch24 (Four Question Close), b1-ch25 (Setter and Closer), b1-ch16 (changing the selling environment), b1-ch04 (attractive character), b1-ch03 (value ladder high-ticket tier), b1-ch27 (webinar/VSL → application stacking), b1-ch28 (cost per application < $100), b2-ch10 (four core stories), b2-ch19 (Expert Secrets value ladder).
