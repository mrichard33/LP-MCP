# Traffic Secrets — Secret 12: Google Traffic Secrets

## Core Idea
Google rewards whatever gives its searchers the best experience. Stop trying to hack the algorithm. Build Dream 100 keyword and blogger lists, publish "skyscraper" linkable assets, earn white-hat links, and buy placements on pages that already rank while you wait to climb.

## Frameworks Introduced

**The Four Phases of Google (history of the Google Slap)**
1. Popularity through backlinks: more links beat fewer, which led to link farms and spam.
2. PageRank and on-page optimization: link quality got weighted, which led to bought high-PR links and "spun" scraped articles.
3. The Google Zoo: Panda (2011) hit content farms and scrapers. Penguin (2012) hit bought and network links. Hummingbird (2013) began reading search intent.
4. Mobilegeddon (2015, mobile-friendly ranking) and Fred (2017), which penalized thin, monetization-first, pop-up-heavy pages.
- When to use: to predict where search is heading. Every slap pushed toward the same thing, a better user experience.
- Why it works / failure mode: every black-hat method Brunson tried "caught up with him eventually." Align with Google's intent (it earns from ads, so it needs happy searchers) and you get free traffic that lasts.

**Two Dream 100 lists for Google**
- **Dream 100 bloggers**: search "[dream keyword] blog" and look at blog networks such as Medium.
- **Dream 100 keywords**: pick 10 dream keywords, then 9–10 long-tail variants for each from Google autosuggest and "related searches," for about 100 in total. Add keyword tools for volume, competition, and CPC.

**Skyscraper Technique (Brian Dean)**
- When to use: a linkable asset (a "Letterman Top 10 list" style post, e.g. "25 SEO tools…") already ranks for your dream keyword. If none exists, write the first one.
- How: (1) Find the tallest skyscraper on page 1. (2) Beat it on all four dimensions: **longer** (50 → 150+ items), **more up to date**, **better designed**, and **more thorough** (depth on each item). (3) Work the dream keyword and its long-tails into the article so one piece ranks for many terms. (4) Scrape the sites linking to the original and send each a personalized email asking for a link to your better version. Dean got 17 links from 160 emails, about 11%. (5) Repeat for the backlinks of the other nine page-1 results. (6) Push traffic you own (email, social) to the article. Aim for at least one new skyscraper a month.
- Why it works: list posts earn natural links, and they drive dwell time, scroll depth, and page depth, which Google can see through Chrome and Analytics.

**Two-click buyer placement (buy your way in)**
- How: while your pages climb, go to the pages already ranking for your dream keywords. Skip sites with no ads. On sites that monetize, buy a solo ad to their newsletter, buy a banner, add them to your GDN placement list if they run AdSense, or pay for a link inside the article.
- Why it works: someone who searches, clicks a result, and then clicks your link has made two clicks. That person is a more serious buyer than a first-click searcher.

## Key Concepts
- **Backlink**: a link from another site, counted as a vote.
- **Google Slap**: an algorithm update that wipes out rankings built on loopholes.
- **Linkable asset / Letterman Top 10 list**: a big numbered list post built to attract links.
- **Long-tail keyword**: a more specific, easier-to-rank variant of a dream keyword.
- **White hat vs. black hat**: techniques Google rewards vs. tricks it eventually punishes.
- **Guest posting / contributor column**: writing on others' high-traffic sites for instant readers and quality links.
- **GDN**: Google Display Network, which buys AdSense slots on other sites.
- **Page-1 real estate**: the ten organic spots, the "Boardwalk and Park Place" of the internet.

## Mental Models
- Think of page 1 as prime real estate. You can build your own building (skyscraper) or rent space in the buildings already standing (ads on ranking pages).
- Use "what does the platform want?" as your SEO strategy. Anything that serves the searcher survives updates.
- Treat any hack you have mastered as temporary: the smarter the market gets, the sooner it breaks.

## Anti-patterns
- **Link farms, bought links, spun content**: short-term gains that end in a slap.
- **Thin, pop-up-heavy, monetization-first pages**: exactly what Fred targets.
- **Chasing head terms with a new site**: go after long-tails first.
- **Publishing a skyscraper without outreach**: content alone won't rank without links.

## Worked Example
**Potato-gun and "internet marketing" lessons.** Brunson found about 18K monthly searches for "potato guns," blasted links (directories, forums, FFA pages), climbed to page 2, and was then slapped out of the index. Later he chased "internet marketing" organically for 8 months, reached #4, and was slapped again. The shortcut he found in month 1: most sites ranking for it were SEO operators with no product, living on banners and affiliate links. He bought placements on their pages and had "a positive traffic overnight."
**ClickFunnels keyword build**: 10 dream keywords (sales funnels, digital marketing, landing page, growth hacking…) × autosuggest long-tails ("sales funnels examples," "…templates," "…for Shopify") = about 100 targets.

## Key Takeaways
1. Build a Dream 100 bloggers list and a 100-keyword list (10 × 10).
2. Check page 1 for each keyword and either write the first linkable asset or build a taller skyscraper. Target one a month.
3. Email everyone who links to the original and to the other nine page-1 results. Expect a response rate around 11%.
4. Write at least one guest post a week and work toward contributor columns (Forbes, Entrepreneur).
5. Buy ads or links on pages that already rank while your own pages climb.
6. Layer search ads and GDN using the prospecting-to-retargeting-to-owned structure from b3-ch09. Tactics may be dated (2020), but Google's user-experience goal is not.

## Connects To
b3-ch02 (search-based congregations, Dream 100 keywords), b3-ch04, b3-ch05, b3-ch09 (paid ads, GDN, retargeting), b3-ch13 (YouTube, also owned by Google), b3-ch14 (slaps and snaps), b3-ch15 (top-10 list becomes blog skyscraper), b3-ch17 (solo ads), b1-ch07 (follow-up funnels).
