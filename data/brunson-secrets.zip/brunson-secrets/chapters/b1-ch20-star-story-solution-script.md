# Dotcom Secrets Secret 20: Star, Story, Solution Script

## Core Idea
The core video/text sales letter script for unboxing (low-ticket) funnels: introduce a **Star** (attractive character), tell a **Story** that agitates the problem and reveals the discovery, then present the **Solution** (offer) with a stack, price drop, guarantee, and urgency. Learned from Vince James (12 Month Millionaire, $100M in 23 months); Russell spent ~10 years structuring each section. Runs 20–30 minutes on video; best for offers up to ~$100 that need belief-breaking before the pitch.

## Frameworks Introduced

**Star, Story, Solution Script** (three sections, ~30 beats):
- When to use: Low-ticket VSLs and long-form sales letters (≤ ~$100) where the product needs explanation or false beliefs must break first.
- How:
  - **Section 1 — Star**
    1. *Pattern interrupt / hook* — lead with your curiosity headline as a big promise; open a loop.
    2. *Core desire questions* — get silent "yes" answers about the outcome they want.
    3. *Agitate past failures* — "this isn't the first time you've tried, is it?"
    4. *Big promise (the one thing)* — "by the end of this video I'll reveal [promise]."
    5. *Introduce the star* — the attractive character.
  - **Section 2 — Story**
    6. *High drama* — start at the peak moment, not the beginning.
    7. *Backstory / the wall* — how they got there; hit the wall where the prospect is now.
    8. *Identify the problem* — "the problem wasn't [X], it was [Y]."
    9. *Epiphany or Declaration of Independence* — the realization or decision to change.
    10. *Path to the ultimate solution* — what was tried and failed.
    11. *First signs of success.*
    12. *Conspiracy* — the cards were stacked against you.
    13. *The big lie* — why it's not their fault.
    14. *Common enemy* — who/what is really to blame.
    15. *Rapid growth* — how fast things moved after the truth.
    16. *Case studies* — others who got results.
    17. *Hidden benefits* — unexpected upsides.
  - **Section 3 — Solution**
    18. *Formal introduction* — "that's why I created [offer]."
    19. *Pain and cost* — what it took you to build.
    20. *Ease* — contrast your pain with their easy path.
    21. *Speed* — time saved.
    22. *"So you can"* — each feature followed by its benefit.
    23. *Social proof.*
    24. *Make the offer and build value* — use the Stack Slide (b1-ch22).
    25. *Price anchor* — total value at least 10x the price.
    26. *Emotional close ("if all")* — "if all this did was [outcome], would it be worth it?"
    27. *Reveal the real price* — step down past retail and their guess to today's price, with a reason.
    28. *Guarantee (logic)* — e.g., 30-day money-back.
    29. *Urgency and scarcity* — a real reason to act now.
    30. *Future pacing* → *Call to action* (what to click, what happens next) → *Post-selling* (what buyers are doing right now) → *Takeaway / warning* (we're fine either way; you'll keep working too hard) → *Close with reminder* (restack for skimmers).
- Why it works: Story builds rapport and breaks false beliefs before the prospect sees a price; the solution section then stacks emotional and logical reasons.
- Failure mode: Starting the story chronologically—boring openings lose attention before the backstory matters.

**"So You Can" Feature-to-Benefit Bridge**: after every feature, say "so you can…" and finish with the benefit (burns fat while you sleep, so you can lose weight without exercising).

**If-All Emotional Close**: stack 3–5 "if all this did was X, would it be worth it?" questions (toward pleasure and away from pain) to anchor value before revealing price.

## Key Concepts
- **Star** — the attractive character whose story carries the pitch.
- **Pattern interrupt** — opening that breaks the scroll and makes a big promise.
- **Point of high drama** — the peak moment where the story starts.
- **The wall** — the stuck point that mirrors the prospect's current state.
- **Epiphany / Declaration of Independence** — realization vs. decision to change.
- **Big lie / common enemy / conspiracy** — external blame that frees the prospect from guilt.
- **Price anchor** — total stated value ≥10x actual price.
- **Take-away selling** — signaling indifference to raise desire.

## Mental Models
- Think of the story as the value-builder; the offer is only as valuable as the story makes it.
- Use the 10x rule: if total value isn't 10x price, add more to the offer.
- Think "not their fault" to lower defensiveness before selling.

## Anti-patterns
- **Selling features without "so you can"**: people buy benefits.
- **Weak value gap**: under-10x anchor means the offer needs more stuff.
- **Chronological storytelling**: start at high drama, backfill later.
- **Word-for-word use**: weave in your own character, stories, offer.

## Worked Example
Hook: "I'll show you my weird niche funnel making $17,947/day and how to ethically knock it off in under 10 minutes—but first, a few questions." Core desire questions about working from home. High-drama story: Russell, six weeks married, crawls from under his desk to a call from his ISP: 30+ spam complaints in six hours, internet being shut off. Backstory: he'd done the math (1M-person list × 1% × $50 = $500,000) but didn't know how to build a list—then continues to the problem, epiphany, and offer.

## Key Takeaways
1. Open with a curiosity hook and big promise, not your bio.
2. Start the story at maximum drama; the wall should mirror the prospect's situation.
3. Relieve blame with the big lie and common enemy before offering the fix.
4. Build value with "so you can," social proof, and a stack worth 10x the price.
5. Close with if-all questions, a stepped price reveal, guarantee, urgency, future pacing, and a restack.

## Connects To
b1-ch14 (VSL funnels), b1-ch11 (book funnels), b1-ch12 (cart funnels), b1-ch04 (attractive character), b1-ch07 (soap opera sequence story beats), b1-ch22 (stack slide), b1-ch21 (OTO script), b2-ch09 (Epiphany Bridge script), b2-ch14 (stack and closes).
