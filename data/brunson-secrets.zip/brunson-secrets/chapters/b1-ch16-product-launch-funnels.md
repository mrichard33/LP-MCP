# Dotcom Secrets Secret 16: Product Launch Funnels

## Core Idea
A product launch funnel is a "sideways sales letter" (Jeff Walker): the same presentation as a webinar, tipped on its side and released as four videos over days or weeks so anticipation builds like a Hollywood movie release. Teach in videos 1–3, sell in video 4. This chapter's range also opens Back End Phone Funnels: for offers above about $2,000, change the selling environment by getting prospects offline.

## Frameworks Introduced

**Product Launch Funnel (Sideways Sales Letter)**: Free workshop registration → Video 1 → Video 2 → Video 3 → Offer video + order form.
- When to use: Launching a new business or product to warm or hot traffic—your own list or affiliate/JV partner lists emailed to the videos. Can be rebuilt as an evergreen automated version after the live launch.
- How:
  1. **Free workshop page** — a squeeze page whose lead magnet is the video training itself; show screenshots of the video series at the bottom; use a curiosity headline (Secret 18) and Who, What, Why, How copy (Secret 19).
  2. **Video pages (2–4)** — thumbnails of the series at top (released = color + play button; unreleased = greyed/locked), the current video below, a downloadable lead magnet tied to the lesson, and a comment section for buzz and social proof.
     - Video 1 — **Wow and How**: wow them with the big idea, show how you and others use it.
     - Video 2 — **Transformational Education**: over-the-shoulder walkthrough of the process.
     - Video 3 — **External Forces**: break the outside obstacles and false beliefs; set up the offer.
  3. **Offer page** — only the offer video plus a link to (or embedded) order form; email the list when the cart opens; add bumps and one-click upsells.
- Why it works: Serialized release creates a countdown; people are "lined up" waiting for the moment video 4 drops. Comments supply social proof and community.
- Failure mode: Sending cold traffic straight in—this funnel assumes an existing relationship.

**Change the Selling Environment (Phase 7 → Back End Phone Funnels)**: move high-ticket prospects from a keyboard they control to a setting you control (phone, live event).
- When to use: Offers from roughly $2,000 up to $1M+.
- How: Build rapport online, then invite them offline—most profitably via an application funnel (b1-ch17) that pre-qualifies and warms leads before a sales call.

## Key Concepts
- **Sideways sales letter** — one sales presentation delivered in daily chunks instead of top-to-bottom.
- **Free online workshop** — the lead magnet framing for the video series.
- **Locked thumbnails** — visual cue that more content is coming; drives return visits.
- **Wow and How / Transformational Education / External Forces** — the three teaching videos.
- **Offer video** — the fourth video; the only one that sells.
- **Warm/hot traffic** — people who already know you or a partner who emails them.
- **Selling environment** — who controls the attention during the pitch; offline = you do.
- **Back end phone funnel** — funnels whose goal is a sales conversation for $2,000+ offers.

## Mental Models
- Think of a launch as a movie release: trailer, ticket date, second trailer, press tour, opening night.
- Use a product launch when you have an audience to mail; use a webinar when you need to collect one.
- Think of the phone/event as a room where they can't scroll away.

## Anti-patterns
- **Selling before video 4**: breaks the teach-then-sell rhythm and the anticipation.
- **No hook at the end of each video**: viewers don't return for the next one.
- **Running it only once**: after the live launch, automate it so it keeps selling.
- **Trying to close $2,000+ offers purely on a web page**: you lack control of the environment; take it offline.

## Worked Example
Hollywood formula mapped to a launch: trailer (video 1 hook) → ads with a ticket date (cart-open date emailed) → second trailer (videos 2–3) → talk-show circuit (affiliate/JV emails) → opening night (video 4 offer + order form) → word of mouth (comments, social proof). Page stack: workshop squeeze page with series screenshots → three content pages with locked thumbnails, lead-magnet downloads, and comments → offer page with a single video and order-form link plus bumps/OTOs.

## Key Takeaways
1. Slice your Perfect Webinar-style pitch into three teaching videos plus one offer video.
2. Drive warm or hot traffic (own list, affiliates, JV partners) by email to each release.
3. End every video with a hook to the next and invite comments.
4. Keep the offer page minimal: video + order form, then stack bumps and OTOs.
5. After the live launch, rebuild it as an automated evergreen funnel.
6. For offers over ~$2,000, plan a back-end phone funnel to move buyers offline.

## Connects To
b1-ch23 (product launch script), b1-ch15 (webinar funnel equivalent), b1-ch22 (Perfect Webinar), b1-ch06 (seven phases; phase 7 changing the selling environment), b1-ch17 (application funnels), b1-ch18, b1-ch19, b2-ch04 (new opportunity), b3-ch18 (affiliate army), b3-ch02 (Dream 100 partners).
