# Traffic Secrets — Secret 19: Cold Traffic

## Core Idea
Warm traffic (your Dream 100's audiences) and hot traffic (your own list) can take most companies to multiple eight figures. Scaling past that, toward nine figures, requires cold traffic. Cold prospects are only problem-aware, so they need a different avatar, different language, and a much longer pre-frame "bridge" before they see a warm funnel.

## Frameworks Introduced

**Traffic temperature and awareness (Eugene Schwartz)**
- Formulation: if the prospect knows your product, lead with the product. If they only know the desire, lead with the desire. If they only feel the general problem, lead with the problem and crystallize it into a specific need.
- Hot = your list (product-aware). Warm = Dream 100 followers (solution-aware). Cold = people at the level of the three core desires (health, wealth, relationships), not yet congregated anywhere and often only problem-aware.

**Step 1: Cold Traffic Customer Avatar**
- How: define a person 6–12+ months earlier in the journey than your dream customer. They feel a pain in a core desire but haven't started looking for solutions. For most entrepreneurs this is **you, 5–10 years ago**. Recall the words you used back then and what grabbed you. Brunson's is "12-year-old Rusty," who read piles of business-opportunity junk mail. Test every cold ad and offer against it: would Rusty click, or beg his parents for a credit card?
- Why it works / failure mode: insider vocabulary ("funnels," "traffic") means nothing to cold prospects, and a warm-converting funnel can "go broke before you get a single customer" on cold traffic.

**Food Court Test (language check)**
- How: imagine shouting your pitch at 300 strangers eating lunch. "Who wants to grow their company with sales funnels?" gets blank stares. "Who wants a money-making website?" gets half the room's hands up. Lead with the cold wording, then educate them toward your solution.

**Step 2: Create a Bridge (the pre-frame bridge from the Dotcom Secrets funnel phases)**
- Formulation: the colder the traffic, the longer the bridge between what they believe and your offer. Hot traffic needs almost none (60%+ of 4,500 Funnel Hacking Live attendees said they would buy blind). Warm traffic needs a Dream 100 endorsement email, a pre-sell video, or a funnel that does the pre-framing itself. Cold traffic needs the longest bridge.
- How (the cold bridge sequence): (1) Identify the audience's language, their false beliefs, and the stories that break them. (2) Write an **article landing page** that matches the host site's look and the audience's worldview and bridges to your concept. (3) Link to a lead funnel (newsletter/opt-in). (4) Run a follow-up funnel that sends them to blog posts, YouTube videos, and other content placed to warm them up. (5) Only then introduce the front-end offer.
- Why it works: it mirrors what the successful advertisers on those cold lists were doing: articles in the audience's language, a newsletter, several story-driven emails, then the funnel.

## Key Concepts
- **Hot / warm / cold traffic**: own list / Dream 100 audiences / unaware masses.
- **Problem-aware / solution-aware / product-aware**: awareness levels that decide how you lead your copy.
- **Three core desires**: health, wealth, relationships, the level cold traffic sits at.
- **Pre-frame bridge**: the content that closes the belief gap before the offer.
- **Article landing page**: an editorial-style cold-traffic entry page.
- **Customer data append**: third-party analysis of your customer list that reveals new segments and the sites they visit.
- **Longer break-even window**: warm funnels aim to break even in the first funnel, while cold can take from a week to 2–3+ months.

## Mental Models
- Think of cold traffic as "you, before you knew any of this." Write to that past self.
- Match the bridge length to the traffic temperature. Don't send cold clicks straight to a warm funnel.
- Use the "pile of cash in front of you" rule: take all the warm and hot traffic before stepping over it to reach for cold.

## Anti-patterns
- **Sending a cold list to a warm-traffic funnel**: bounce, no sales, big loss.
- **Using insider jargon with the unaware**: "funnels" fails the food-court test.
- **Going cold without a proven value ladder and follow-up**: you can't float the longer payback.
- **Selling in the first cold touch**: the working cold marketers didn't sell for several emails.

## Worked Example
**The 2.3M-person email flop and fix**: a customer data analysis showed a large share of ClickFunnels customers were conservative Republicans, and named sites they read. Brunson bought a newsletter blast to 2.3M people pointed at a warm-converting funnel, expecting a few hundred thousand dollars. It produced hundreds of thousands of clicks, about 12 sales, and a loss of more than $30K. By staying on those lists he funnel-hacked the other advertisers, whose links went to articles in the audience's own language, then to a newsletter opt-in, then to story emails, then to the offer. Round two used an article page, a lead funnel, and a content follow-up sequence before the front end. Cold traffic then worked, breaking even in about a week on some sources and 2–3+ months on others.

## Key Takeaways
1. Exhaust warm (Dream 100) and hot (owned) traffic before scaling cold.
2. Write a separate cold avatar, your past self 5–10 years back, and take their vocabulary.
3. Run the food-court test on every cold headline.
4. Build the bridge: article page → lead funnel → content follow-up → front-end offer.
5. Make sure the value ladder and follow-up funnels are proven before buying cold, and budget for a payback of 1 week to 3+ months.
6. Mastering cold traffic lets you buy almost anywhere (colder lists, banners on most sites), and it is what gets companies past nine figures.

## Connects To
b1 traffic temperature and pre-frame bridge (funnel phases), b1-ch03 (value ladder), b1-ch07 (follow-up funnels), b2 (false beliefs, epiphany bridge stories), b3-ch01 (dream customer avatar), b3-ch05 (traffic you own), b3-ch17 (buying solo ads and banners), b3-ch09 (paid ads).
