# Expert Secrets — Secret 4: The New Opportunity

## Core Idea
Movement leaders never sell "better, faster, more" (the -ER words). They offer a **New Opportunity**: a new vehicle in a new category that replaces what isn't working. Improvement offers make buyers admit failure and lose status. New opportunities let them move away from the pain toward a new dream. Each business should have exactly one opportunity switch, and everything else on the value ladder is an opportunity stack inside it.

## Frameworks Introduced
**New Opportunity vs. Improvement Offer**
- Improvement offer: a better mousetrap, sold into a red ocean.
- New opportunity: a new category (the iPod rather than a better CD player, the electric car rather than a better car, funnels rather than better websites).
- Why people reject improvement offers: (1) *improvement is hard*, since they've already tried and felt the pain. (2) *Desire vs. ambition*: roughly 2% are ambitious enough to buy improvement, so you exclude about 98%. (3) *Memories of poor past decisions*: saying yes means admitting they failed. (4) *Commodity pricing*: a race to the bottom. If you can't be the cheapest, be the most expensive.
- Why new opportunities work: *new discovery* (sharing something new raises status and drives virality), *no pain or disconnect* (no admission of past failure), *dream replacement* ("where there is no vision, the people perish"), and *greener pastures* (take them over the fence instead of fixing their grass).

**Status (the core buying driver, via Perry Belcher)**: the subconscious asks, "Will this increase or decrease my status?" Status here means self-perception. People weigh hope of higher status against fear of lower status. Buying causes a temporary status drop, which they accept only if they expect a larger gain later.
- How: load up the status-gain side (appearance of intelligence, wealth, power, happiness, physical appearance, style) and cut the risk side (money-back guarantees, risk reversal, done-for-you options).
- Why it works / failure mode: status is the one question behind every yes or no. Improvement offers fail because they force a status drop through the admission of past failure.

**How to Create a New Opportunity (4 steps)**:
1. **Results they want**: identify the core desire and the specific result. Use the Dan Sullivan Question: "If we were meeting three years from today, what has to happen for you to feel happy with your progress?"
2. **Current vehicle**: list every old vehicle they've tried without success (diets, eBay, Amazon, websites, CRMs, autoresponders).
3. **The Opportunity Switch**: don't improve the old vehicle. Throw rocks at it, tell them it wasn't their fault, and switch them into your new vehicle. Every front-end asset (ads, lead magnets, books, webinars, podcasts) should perform this switch. Build break-even front-end funnels for colder submarkets (e.g., brick-and-mortar, ecom, network-marketing, and freelancer versions of "why you need a funnel").
4. **The Opportunity Stack**: **one and only one opportunity switch per business**. Later offers package the *same* opportunity at the next level (software, challenge, scripts tool, event, agency course, membership, newsletter, coaching, traffic book). They don't launch new new-opportunities.
- Why it works / failure mode: each additional "new opportunity" contradicts the last one, erodes trust, and makes the list less responsive. Brunson's business nearly crashed this way before ClickFunnels.

## Key Concepts
- **New Opportunity**: a new vehicle or category that replaces, rather than improves, the old one.
- **Improvement offer**: a "-ER" pitch (better, faster, cheaper) for an existing vehicle.
- **Status**: self-perceived standing. The only thing that moves people toward or away from an offer.
- **Vehicle**: the method a customer uses to pursue their desired result.
- **Opportunity switch**: moving someone from their old vehicle to your new one.
- **Opportunity stack**: further offers that deepen the same opportunity instead of replacing it.
- **Desire vs. ambition**: everyone has desire, and few have the ambition improvement requires.
- **Selling away from pain**: new opportunities let buyers leave without admitting failure.

## Mental Models
- Use the "-ER word" test. If your headline says better, faster, or easier, you've written an improvement offer.
- Think of every buy decision as a status scale. Add to the gain side and subtract from the risk side.
- Think "one switch, many stacks" when planning the value ladder.
- Use the rule that it isn't their fault. Blame the old vehicle to justify their past failures.

## Anti-patterns
- **Building a better mousetrap**: you become a shark fighting over scraps.
- **Serial new opportunities**: each one contradicts the last, and trust and list response decay.
- **Selling through pain**: forcing admission of failure lowers status and kills the sale.
- **Competing as the #2 cheapest**: there's no strategic advantage to it.
- **Ignoring the status-drop fear** of someone who has already failed 27 diets.

## Worked Example
**Funnel Hacking Live certification (opportunity stack).** At the first FHL, about 600 attendees already believed in funnels (they had already been switched). Every "new opportunity" idea would have distracted from funnels. Brunson reframed the question: what opportunity can be stacked *inside* funnels? The answer was a funnel-builder certification to start a career building funnels for others. The goal was 50 sign-ups, and more than 150 people rushed the table. From this he learned that value-ladder offers repackage the opportunity buyers already believe in. For a health company the same logic means switch once, then stack supplements, coaching, and meal plans.

## Key Takeaways
1. Ask your dream customers the three-year Dan Sullivan Question to find the true result.
2. List every old vehicle they've tried, then throw rocks at those vehicles, not at the customer.
3. Name one new vehicle and category. Make every front-end asset an opportunity switch into it.
4. Stack all back-end offers inside that single opportunity. Never launch a competing "new new" opportunity.
5. Audit each offer for status: add status gains and add risk reversal.
6. Build break-even front-end funnels aimed at colder submarkets to widen reach.

## Connects To
b2-ch03 (category creation), b2-ch05 (packaging the opportunity and the stack slide), b2-ch10 (vehicle / internal / external false beliefs), b2-ch12 (Big Domino), b1-ch03 (value ladder), b1-ch02 (hook-story-offer).
