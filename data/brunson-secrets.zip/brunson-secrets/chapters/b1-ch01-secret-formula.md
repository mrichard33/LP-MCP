# DotCom Secret 1: The Secret Formula

## Core Idea
Every business is built on four questions, answered in order: who is your dream customer, where do they congregate, what bait (Hook, Story, Offer) attracts them, and what result do you ultimately want to deliver (Value Ladder). Choose the customer first; the product follows.

## Frameworks Introduced

**The Secret Formula (four questions)**
1. Who is your dream customer?
2. Where are they congregating?
3. What is the bait you will use to attract them (Hook, Story, Offer)?
4. What is the unique result or value you want to create for them (Value Ladder)?
- When to use: before launching a business, product, or funnel; when you dislike the customers you have; when a product is not selling despite a decent funnel.
- How: answer each question on paper before building anything. Steps 3 and 4 hand off to their own frameworks (b1-ch02, b1-ch03).
- Why it works / failure mode: you attract customers based on the content and offers you put in the market ("change your bait, change your customers"). Starting with a product and waiting to see who shows up leaves you serving people you never chose, and may leave you miserable in a business that makes money.

**Dream Customer Avatar**
- When to use: step 1 of the Secret Formula; any time a copy, content, or offer decision is ambiguous.
- How: (1) Ask what they look like, what they are passionate about, and what their goals, dreams, and desires are. (2) Name them. Write one avatar per gender if you serve both (Brunson used "Julie" and "Mike"). (3) List their traits: stage of business, values (e.g. growth over money), what they want to learn next. (4) Find a real photo that matches and hang it where you work. (5) Resolve decisions by asking what the avatar would want. John Lee Dumas's version is "WWJD: what would Jimmy do?"
- Why it works: every headline, call to action, ad, and piece of content speaks to one person, which attracts that person and repels everyone else.

**Congregations**
- When to use: step 2; this is the basis of all traffic work.
- How: list where the avatar already gathers: top websites, forums and message boards, Facebook groups, influencers they follow on Facebook and Instagram, podcasts, email newsletters, blogs, YouTube channels, and the Google keywords they search. Then put your bait in front of those groups.

## Key Concepts
- **Dream customer**: the specific person you choose to serve, picked as carefully as a spouse because you will spend more time with them than with friends.
- **Bait**: the offer and content you put in the market. It decides who you attract.
- **Congregation**: a group gathered around a shared interest (church, forum, fan site). The internet lets tiny, scattered niches gather in one place.
- **Hook**: the ad or attention-grabber that holds the dream customer long enough to hear a story.
- **Story**: builds rapport and breaks the false beliefs that stop the buy.
- **Offer**: the thing you created to get the dream customer the result they want.
- **Unique result**: the outcome you deliver. A business sells results, not products, and once results are the frame, price stops being the barrier.
- **Pinnacle**: the highest-value place you would take a client if they could pay anything.

## Mental Models
- Think of your customer list as a direct output of your bait. To change customers, change the offer, not the people.
- Think of the internet as a map of congregations. Traffic means finding the right room, not creating demand.
- Use the pinnacle question ("if they paid anything, what would I do to guarantee their result?") to set the top of your Value Ladder, then build down from it.

## Anti-patterns
- **Product-first launches**: you fall in love with an idea, ship it, and serve whoever shows up, often people who drain you.
- **Selling to "anyone and everyone"**: a broad market (all women who use makeup) gives you no momentum and copy that speaks to nobody.
- **Beginner-heavy customer base when you want to sell high-ticket**: you spend 99% of your time on basics (domains, hosting) and customers can't afford the ascension.
- **A hazy avatar in your head**: without a written profile and a photo, decisions drift.

## Worked Example
**Makeup brushes niched to PCOS (Dean and Robin Holland, UK):** for two years they sold cosmetic brushes to women in general and made about $34K. Robin then realized her dream customer was a woman like her, suffering from PCOS. They rewrote the landing pages and funnel copy to speak only to that person and rebuilt the ads as bait for her. The product stayed the same. They made over $100K in the next 60 days and sold out a year's inventory, which forced them to pause the ads.

**Brunson's own shift:** he moved away from selling to beginners and launched an offer only his avatar would value: "DotCom Secrets Labs: 108 Proven Split Test Winners." Beginners don't know what a split test is. Julie and Mike do. Thousands of dream clients signed up within days. Six years later, 100 people who had each paid $50K sat in his room, and almost all of them recognized themselves when he read out the avatar descriptions.

## Key Takeaways
1. Answer the four Secret Formula questions in writing before you build a funnel.
2. Write a named avatar (two if needed), list their traits, and hang up a real photo.
3. List 10 or more congregations where the avatar already gathers: sites, groups, influencers, podcasts, newsletters, keywords.
4. Build bait that only your dream customer would want, so it repels everyone else.
5. Define the pinnacle result you would deliver at unlimited price. That becomes the top of your Value Ladder.
6. If your product stalls, re-niche the avatar and rewrite the copy before you change the product.

## Connects To
b1-ch02 (Hook, Story, Offer: the bait), b1-ch03 (Value Ladder: the unique result), b1-ch04 (Attractive Character), b3-ch01 (dream customer), b3-ch02 (where they congregate), b3-ch03 (Hook, Story, Offer for traffic), b2-ch01 (movement / new opportunity).
