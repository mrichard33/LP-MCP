# Expert Secrets — Secret 8: The Hero's Two Journeys

## Core Idea
Brunson traces story structure from Joseph Campbell (17-stage Hero's Adventure) to Christopher Vogler (12-stage Hero's Journey for film) to Michael Hauge (the *second*, inner journey), and compresses it into a simple four-phase framework for sales. Every good story is **character + desire + conflict**. The hero pursues an external goal (the journey of achievement), but the audience's real payoff is who the hero becomes (the journey of transformation).

## Frameworks Introduced
**Plot = Character + Desire + Conflict** (Hauge): every good story is a captivating character pursuing a compelling desire against seemingly insurmountable obstacles. (Little Red Riding Hood: character = the girl. Desire = take cookies to grandma. Conflict = the big bad wolf.) The same core can be told in 60 seconds or 60 minutes.

**The Hero's Two Journeys (Brunson's simplified framework)**:
1. **Separation from the ordinary world** (first ~25% of the story). Get the audience to care:
   - *Build rapport* by giving the hero **at least two** of: victim of an outside force (we root for them) · in jeopardy (we worry) · likeable (we want to be with them) · funny (we connect) · powerful (we want to be like them).
   - *Introduce the desire* with one of the **four core desires**. Toward pleasure: **to win** (love, fame, money, competition, which is really status) or **to retrieve**. Away from pain: **to escape** or **to stop**.
2. **The journey, conflict, and villain**: the visible goal with a finish line the audience can see. Conflict creates emotional connection, and the main tool is a **villain**. A worse villain means a stronger bond with the hero. In sales stories, the villain is often a **false belief system** you vilify and defeat.
3. **The mentor, expert, or guide** (Yoda, Mickey, Gandalf, Maui): gives the epiphany and frameworks the hero uses to beat the villain. The guide can be a person or divine inspiration.
4. **The achievement**: the hero may or may not reach the goal (Rocky loses to Apollo Creed. Lightning McQueen gives up the Piston Cup), but they **transform**. The old identity dies and a new one is born. This invisible second journey is the real one.
- When to use: structuring any story, especially origin and epiphany stories inside funnels.
- Why it works / failure mode: without early rapport, nobody cares what happens next. Without a villain there's no emotion. Without transformation the story is only a report of results.

**Reference frameworks** (for depth):
- *Campbell's Hero's Adventure (17 stages)*: call to adventure, refusal, supernatural aid, first threshold, belly of the whale, road of trials, meeting the goddess, temptation, atonement with the father, apotheosis, ultimate boon, refusal of return, magic flight, rescue from without, return, master of two worlds, freedom to live.
- *Vogler's Hero's Journey (12 stages)*: ordinary world → call to adventure → refusal → meeting the mentor → crossing the first threshold → tests/allies/enemies → approach the inmost cave → ordeal → reward → road back → resurrection → return with the elixir. (Shown for Harry Potter and the Sorcerer's Stone and The Lion King.)

## Key Concepts
- **Journey of achievement**: the external, visible quest (the hero's first journey).
- **Journey of transformation**: the internal change in who the hero becomes, from fear to courage (the second journey). It gives the biggest payoff.
- **Character / Desire / Conflict**: the three plot essentials.
- **Rapport levers**: victim, jeopardy, likeable, funny, powerful. Use two or more.
- **Four core desires**: win, retrieve (toward pleasure). Escape, stop (away from pain).
- **Villain**: the source of conflict. In marketing it's often a false belief system.
- **Guide**: the mentor who hands the hero the plan or epiphany.
- **Death and rebirth of identity**: the transformation climax.

## Mental Models
- Think of your customer as the hero and yourself as the guide. In your origin story, you were the hero with your own guide.
- Use a false belief as the villain when there's no human antagonist.
- Put the transformation last. Achievement satisfies, and transformation is what moves people.
- Think "same skeleton, variable flesh" to fit a story to 60 seconds or 60 minutes.

## Anti-patterns
- **Skipping rapport-building**: the audience has no stake in the hero.
- **No clear desire**: without win/retrieve/escape/stop, the story has no direction.
- **Conflict-free stories**: without a villain there's no emotional connection.
- **Ending at the result**: the transformation payoff is missing.
- **Using Campbell's 17 stages verbatim in sales**: too complex for a Facebook Live or webinar.

## Worked Example
**Cars, through the Two Journeys.** (1) *Separation*: Lightning McQueen is a powerful and likeable (if arrogant) rookie. Desire: **to win** the Piston Cup. (2) *Journey/conflict*: rivals, being stranded in Radiator Springs, and his own ego as the villain. (3) *Guide*: Doc Hudson, the fallen champion who teaches him. (4) *Achievement vs. transformation*: seconds from the finish, he brakes, gives up the Cup, and pushes the wrecked King across the line. He loses the external goal and becomes someone who values people over trophies, which is the death and rebirth of his identity and the story's real payoff.

## Key Takeaways
1. Before telling any story, name its character, desire (win/retrieve/escape/stop), and conflict.
2. Build rapport in the first quarter with at least two levers (victim, jeopardy, likeable, funny, powerful).
3. Make a false belief the villain and defeat it in the story.
4. Put a guide in the story who delivers the epiphany or framework.
5. Always close with who the hero became, not only what they achieved.

## Connects To
b2-ch07 (Epiphany Bridge), b2-ch09 (Epiphany Bridge script built on this framework), b2-ch06 (achievement vs. transformation inside the tribe), b1-ch04 (Attractive Character identities and storylines), b1-ch20 (star story solution), b2-ch11 (Perfect Webinar origin story).
