# DotCom Secret 7: Follow-Up Funnels

## Core Idea
Turn all traffic into traffic you own (your list), then let the Attractive Character move people up the Value Ladder by email. There are two message types. The **Soap Opera Sequence** is a five-email series with open loops that builds a bond fast and sells the current offer. **Seinfeld emails** are daily, entertainment-first broadcasts that each tie back to an offer. The customer is the hero; you are the guide (Yoda to Luke, after Donald Miller's StoryBrand).

## Frameworks Introduced

**Three Types of Traffic**
- **Traffic you own**: your email, messenger, and customer lists. Instant, free, repeatable distribution. This is the only real goal.
- **Traffic you control**: paid traffic (Google, Facebook, solo ads, banners, native ads, affiliates, JVs). Send all of it to a squeeze page that offers one choice: give your email or leave.
- **Traffic you earn**: podcasts, PR, SEO, social, word of mouth. Route it to a **funnel hub**, a site that looks traditional but whose only real exits are opt-in funnels.
- Why it works: owned traffic is pure profit with no new marketing cost. Every other type should be converted to it as fast as possible.

**Soap Opera Sequence (five emails)**
1. **Set the stage**: welcome them, give a quick credibility line, promise something big tomorrow (e.g., your best product free), and name tomorrow's subject line in the PS.
2. **Open with high drama**: start at the peak of the story, then give the **backstory** (take them back to where they are now), reach the **wall** where you got stuck, say you found the answer, and hold it back until tomorrow. Add a soft call to action in the PS.
3. **Epiphany**: reveal the discovery that turned things around. It must tie directly to the product ("that's when I found ___").
4. **Hidden benefits**: benefits they haven't considered (lifestyle, fulfillment, access), with a soft call to action.
5. **Urgency and CTA**: a real deadline (the webinar starts tomorrow, 10 seats left, a limited print run, the video comes down, a 24-hour coupon) and a hard call to action.
- When to use: right after any opt-in or purchase, with one sequence per Value Ladder product.
- Why it works / failure mode: open loops (like soap-opera cliffhangers) pull people from email to email. A boring first email kills the series. Fake urgency destroys credibility.
- After it ends: move the reader to the next rung's Soap Opera Sequence, or to the daily Seinfeld broadcast list if this is your only funnel.

**Seinfeld Emails (daily broadcast)**
- Formulation: about 90% entertainment and 10% content. Each one is a Hook (subject line), a Story (entertaining body), and an Offer (ties back to a funnel).
- Three styles: **Episode** (what happened today, or a controversy in the industry), **Epiphany** (a thought-provoking idea that challenges a belief), **Educational** (checklist, how-to, Q&A, FAQ).
- How: send one every day, unsequenced and tied to the character's real life. Point to whatever is being promoted, or to your best-converting offer if nothing is new. You can dictate them and have them transcribed.
- Rule: every story must tie back to an offer, or you won't make a dime.

## Key Concepts
- **Traffic you own / control / earn**: the three traffic types; convert everything to owned.
- **Squeeze page**: a one-option page that trades an offer for an email. It evolved from pop-ups after browsers started blocking them.
- **Funnel hub**: a website whose exits all lead into funnels.
- **$1 per name per month**: the benchmark for monthly revenue from a list with a good relationship.
- **Open loop**: an unresolved story thread that is only closed in the next email.
- **Start at high drama**: open mid-story, then backfill the backstory (Daegan Smith).
- **Broadcast vs. sequence**: Seinfeld emails go to everyone on the day they're sent. Soap Opera emails are timed from signup.
- **Lead funnels**: front-end, email-for-value funnels: Lead Squeeze, Survey, and Summit.

## Mental Models
- Think of the list as your own distribution channel. Building it every day is how you give yourself a raise.
- Frequency rule: not emailing daily means losing money daily. The more often you email, the more you earn, as long as the emails entertain.
- Think of each Seinfeld email as a daily hook test across segments of your market.
- Use a Soap Opera Sequence for bonding and the first sale. Use Seinfeld emails for ongoing ascension and re-engagement.

## Anti-patterns
- **Sending paid traffic straight to a sales page or home page**: you pay again every time you want that person back.
- **Content-heavy emails that take days to write**: lower opens and sales than entertainment.
- **Emailing monthly**: response rates are horrible.
- **Long paragraphs**: keep to one or two sentences per line with plenty of white space.
- **Fake urgency**: you lose credibility.
- **Entertaining emails with no offer**: no revenue.

## Worked Example
**Five-email "Expert" Soap Opera Sequence (subjects "Expert, chapter N of 5"):**
1. Welcome: "I started with potato-gun DVDs, and this newsletter reports my tests." Promise: tomorrow, my best product free, if you open. PS names the subject "The day my education failed me."
2. High drama: graduation day, May 2005, in a room full of smiling graduates headed for $30K to $40K jobs and student debt. Backstory: he had already made $250K in his senior year. The answer is held back. PS: free book plus shipping.
3. Epiphany: a professor earns about $25 an hour, while a how-to author selling 100 copies a day at $50 earns about $1.8M a year from a book written once. So sell knowledge like the author. Link to the video.
4. Hidden benefits: meeting Tony Robbins and Richard Branson, and the fulfillment of changing lives. Free book (normally $19.95).
5. Last call: the free offer ends today.

**Seinfeld emails that each made more than $100K:** "He flushed $20 million down the toilet today" (a golf marketer who hung up on a coach, leading to an inner circle application). And "Jiu-jitsu is like wrestling for old fat guys" (cutting 7 lbs before a tournament while the business did six figures that week without him, leading to an application for two coaching slots).

**List math (Mark Joyner's and Mike Filsaime's rule):** 200 subscribers brought in about $200 a month, 1,000 about $1,000 a month, and 5,000 about $5,000 a month. The list reached 100K in a year and more than 1M in five years.

## Key Takeaways
1. Send every paid click to a squeeze page and every earned visit to a funnel hub. Build the list daily.
2. Write a five-email Soap Opera Sequence for each Value Ladder product: stage, drama and backstory and wall, epiphany, hidden benefits, urgency.
3. End every email with an open loop and name tomorrow's subject line.
4. After the sequence, move readers to the next rung's sequence or to the daily Seinfeld list.
5. Email every day in an entertaining way, and tie every story to an offer.
6. Use only real urgency.

## Connects To
b1-ch04 (Attractive Character voice and storylines), b1-ch06 (phases 3 and 6), b1-ch08 through b1-ch10 (lead funnels feed the list), b2-ch07 (Epiphany Bridge in email 3), b2-ch06 (story structure), b3-ch07 (traffic you own/control/earn), b3-ch10 (follow-up funnels in Traffic Secrets).
