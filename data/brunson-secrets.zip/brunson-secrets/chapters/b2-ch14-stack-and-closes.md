# Expert Secrets — Secret 14: The Stack and the Closes

## Core Idea
Prospects remember only the last thing you showed them. So instead of pitching a core offer and then listing bonuses, present each element with its story, then re-show a growing stack slide. The final thing they see before the price is the whole offer and its total value. This one technique (learned from Armand Morin) earned Brunson his first table rush and first six-figure day.

## Frameworks Introduced
**The Stack**: introduce element 1 with a learned/earned/created story → show the stack slide with element 1 and its value → introduce element 2 plus its story → re-show the stack with 1 and 2 and the new total → repeat → show the full "big stack" → reveal the price.
- When to use: every offer, every medium.
- Why it works / failure mode: the price gets anchored to the entire offer, not the last bonus. The failure mode is showing bonuses as a list after the core offer, so value is judged by the last (smallest) item.

**The "Let me ask you a question" transition (Armand Morin)**: recap the three secrets as one chain ("If you did Secret 1, then 2, then 3, do you think you could succeed?"), then ask "How many are excited? Overwhelmed?", use the fire-hose image, then ask permission: "Is it okay if I spend 10 minutes on a special offer to help you implement __?" Wait for yes. If there's silence, say "It's fine, I can leave," then ask again.
- When to use: the moment you move from content to pitch. Nodding heads tell you who will buy.

**If-All Statements (Dave Woodward)**: "I'm not going to charge you $X, but if all this did was [Secret 1 result], would it be worth $X?" Repeat for Secret 2 and Secret 3, pausing each time. That gives three mental yeses at full value, so the actual price feels like about a 90% discount.

**Price justification**: (a) full-price comparison ("on my site it's $X; for this webinar only...") or (b) apples vs. oranges ("hiring a pro costs $X; you pay $Y").

**Stack-and-close slide sequence (slides 16–43)**:
16 Transition (the chained-secrets question) · 17 Question slide/permission · 18 What you're going to get (core product image + creation story) · 19 "You'll be able to / get rid of" · 20 Problem this product solved for you · 21 Time/money it saves them · 22 Break product-related false beliefs · 23 Stack slide #1 (with value) · 24 Element #2, the framework course/event + story · 25 High-level deliverables recap (~30 sec, week 1..6) · 26 Case studies · 27 Who this works for (all-inclusive) · 28 Destroy the #1 reason people don't start · 29 Stack slide #2 · 30 Repeat per element (each bonus kills a remaining false belief) · 31 Big stack slide (value ≥10x price) · 32 If-all statements (x3) · 33 "I had two choices" (cheap vs. fully stacked) · 34 What would the end result be worth? · 35 Price drop · 36 Price reveal + first CTA (every slide after this shows the CTA) · 37 Price justification · 38 "You've got two choices" (do nothing or test it) · 39 Guarantee (e.g. 30-day money-back) · 40 "The real question is..." (even half the results pay for it) · 41 Last stack slide, line by line · 42 Urgency/scarcity bonus (live-only, limited number or time) · 43 Closing CTA / Q&A slide (offer recap, 30-min countdown, price, CTA) that stays up through Q&A, with a CTA after every answer.

## Key Concepts
- **Stack slide**: a cumulative list of every offer element and its value, with a running total.
- **Big stack slide**: the complete list, totaling at least 10x the price.
- **Table rush**: the audience moving to buy mid-pitch. It's evidence the stack is working.
- **Permission close**: asking to present the offer so selling feels invited, not pushed.
- **If-all statement**: getting agreement that one slice of the offer alone is worth full value.
- **Bonus-as-belief-breaker**: every bonus should remove a specific remaining false belief (e.g. a traffic bonus for traffic fear).
- **Urgency/scarcity bonus**: a live-only upgrade. People who leave almost never come back to buy.

## Mental Models
- Think of the pitch as a scoreboard: the last number on screen before the price is the one that sticks.
- Use each offer element as a targeted objection-killer, not filler value.
- Treat the price reveal as the midpoint of the close. Most selling happens after it (justification, choices, guarantee, restack, urgency, Q&A).

## Anti-patterns
- **Ending on the price slide**: people get sticker shock with nothing to soften it.
- **Deep module walkthroughs**: these overwhelm. Keep the curriculum recap to about 30 seconds.
- **Stack value under 10x price**: add something more valuable.
- **Nervous, apologetic transition**: use the question and permission instead.
- **No deadline**: without live-only urgency, buyers defer and vanish.

## Worked Example
Transition line: "If you found a working funnel (Secret 1), cloned it in 10 minutes in ClickFunnels (Secret 2), and bought traffic where competitors buy it (Secret 3), could you succeed?" → permission for 10 minutes → stack builds from core product to framework course to bonuses → big stack about $11,552 → three if-all statements ("If all this did was get you a proven funnel to model, would it be worth $11,552?") → end-result worth question → price drop → price reveal → justification → two choices → 30-day guarantee → last stack → live-only bonus → Q&A with a CTA after each answer. Armand closed about 50% of 1,000 people on a $1,000 course this way.

## Key Takeaways
1. Present each element with its origin story, then restack. Never list bonuses after the core.
2. Transition with the chained three-secrets question and ask permission for 10 minutes.
3. Make the big stack worth at least 10x the price, then run three if-all statements tied to the three secrets.
4. Put a CTA on every slide after the price reveal. Keep justifying, add the guarantee and the "real question".
5. Always finish with a live-only urgency/scarcity bonus and a Q&A slide with a countdown.

## Connects To
b2-ch05 (offer creation, stack slide), b2-ch13 (three secrets feed the if-alls), b2-ch15 (trial closes and 16 closes woven in), b1-ch22 (Perfect Webinar script), b1-ch15 (webinar funnel), b2-ch16 (live testing refines the Q&A and objections).
