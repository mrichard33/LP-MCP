# Expert Secrets — Secret 13: The Three Secrets

## Core Idea
Once the origin story shifts the main belief, new objections come up, especially for expensive offers. The content section breaks the three core false beliefs holding up the Big Domino (vehicle, internal, external) with epiphany bridge stories, framework strategy (never tactics), case studies, and rapid-fire supporting stories.

## Frameworks Introduced
**Three Secrets build process (3 steps)**:
1. Identify the three core false beliefs from your story inventory (b2-ch10): vehicle ("won't work for me"), internal ("I can't do it"), external ("outside force X will stop me: time, money, economy, traffic").
2. Write one epiphany bridge story per core belief (how you overcame it). Keep the others as supporting stories.
3. Rewrite each belief plus its story as a curiosity-driven "how to" secret title that hints your framework is the key.
- Why it works / failure mode: removing the three props makes the domino fall on its own. The failure mode is switching into teacher mode and giving tactics, which feels generous but leaves beliefs unchanged and produces no purchase and no change.

**Per-secret slide sequence (repeat for Secrets 1, 2, 3)**: state the secret → introduce the framework's proprietary name ("get out a pen") → learned/earned epiphany bridge story → teach the strategy (named steps, the *what*) → case studies of others → supporting epiphany bridge stories.

**Origin story vs. vehicle story**: the origin story (intro) explains how you discovered the new opportunity. The vehicle story (Secret 1) explains how you developed the specific framework.

**"You're probably thinking X, right? Well, actually..." (Jason Fladlien objection busting)**: 30–60-second mini-stories that name and break one false belief each.
- When to use: after the case studies in each secret, or in an extended session at the end.
- How: list every objection, and for each one name it, give the truth, and add a one-line story.

**Content-section slides 7–15**: 7 transition ("here's what we'll cover in the next ~45 min" + three titles), 8 state Secret 1, 9 introduce framework, 10 learned/earned story, 11 strategy slides, 12 case studies, 13 supporting stories, 14 Secret 2 (internal) same sequence, 15 Secret 3 (external) same sequence.

## Key Concepts
- **Core false belief**: the one belief per category that would keep the domino standing.
- **Supporting stories**: extra epiphany bridge stories for secondary objections.
- **Strategy vs. tactics**: strategy is the named steps (what); tactics are the how (criteria, clicks, where to find). Tactics are reserved for buyers.
- **Curiosity secret title**: a "how to" headline that teases the framework without explaining it.
- **Milk before meat**: change belief first, then deliver the substance (1 Corinthians 3:2).
- **Buying creates commitment**: people who pay take action; free guests next to $50K payers had near-zero success.

## Mental Models
- Think of the three secrets as three props under one domino, not three new ideas to sell.
- Teach at the level where someone can repeat your steps but still needs your product to execute them.
- Use buying as the service: the purchase creates the commitment that produces results.

## Anti-patterns
- **Teaching tactics before the sale**: the surest way to kill sales, and the audience doesn't change either.
- **Skipping the learned/earned story**: without it the framework has no perceived value.
- **Leaving secondary objections unaddressed**: in one-to-many selling you can't ask follow-up questions, so bust as many as possible in advance.

## Worked Example
Funnel Hacks (Big Domino: funnels are the only way to 10X growth):
- Vehicle belief "won't work for me" → Secret 1 *Funnel Hacking*: "How to ethically steal $1M+ in funnel hacks from competitors for under $100." Story: Tony Robbins' modeling lesson, then a supplement company that 10X'd overnight by modeling a competitor. Framework: (1) find a funnel to model, (2) funnel hack it (buy, see structure), (3) blueprint, (4) build in ClickFunnels.
- Internal belief "I'm not technical" → Secret 2 *Funnel Cloning*: "Clone a proven funnel inside ClickFunnels in under 10 minutes." Story: costly tech team, then Todd built ClickFunnels. Steps: pick template, drag-and-drop, add copy/images, check mobile, launch.
- External belief "I can't get traffic" → Secret 3 *Traffic Hack*: "Get your competitors' customers to come to your funnel." Steps: find a competitor with your dream customers, find the sites they buy ads on, model their banners, buy the same placements.
Fladlien's extra 90 minutes of "you're probably thinking..." (about 50 objections) sold 3x more than the first 90 minutes. Inner-circle members who copied it more than doubled webinar sales.

## Key Takeaways
1. Choose one core false belief per category from your story inventory.
2. Pair each with a learned/earned epiphany bridge story and a named framework.
3. Teach named steps and proof only; leave the how for the product.
4. Give each secret a curiosity "how to" title and preview all three at the transition slide.
5. End each secret with rapid "you're probably thinking X, right?" objection busts.

## Connects To
b2-ch09 (epiphany bridge script), b2-ch10 (four core stories, story inventory), b2-ch11 (framework), b2-ch12 (Big Domino), b2-ch14 (stack uses bonuses to kill remaining beliefs), b2-ch16 (indoctrination videos pre-sell each secret), b1-ch22 (Perfect Webinar script).
