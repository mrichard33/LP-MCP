# Dotcom Secrets Secret 28: Funnel Audibles

## Core Idea
Most funnels flop on first launch—and that's the point: the launch is the first match that reveals where you're weak. Keep funnels simple (3–5 pages plus one soap opera sequence), test with the revenue of one full-funnel customer, let the market vote with credit cards, and compare **CPA** vs. **ACV**. When a step underperforms, the fix is always the **hook, story, or offer**; split-test against the control and "give yourself a raise" every day. The chapter's range also includes the book's conclusion: a 12-step Dotcom Secrets process.

## Frameworks Introduced

**One-Customer Test Budget**: spend on ads what you'd earn if one person bought everything in the funnel.
- When to use: First traffic test of any new funnel, and each iteration after.
- How: Sum all offer prices in the funnel (e.g., book $0 + bump $37 + OTO1 $97 + OTO2 $197 = $331; or a $1,000 webinar course = $1,000). Spend that on Facebook/Google/etc. Wait a few days to a week for traffic to flow through pages and emails. Goal: break even (one sale). If not, write it off as market research, adjust, retest. Expect 3–4 test rounds before a winner.
- Why it works: Caps downside while producing per-page data the market—not your opinion—generates.
- Failure mode: Asking experts (or yourself) whether a funnel will work instead of testing.

**Marketing Math (CPA vs. ACV)**:
- **CPA** = ad spend ÷ customers acquired ($1,000 → 100 books = $10; → 10 buyers = $100).
- **ACV** = total funnel revenue ÷ customers ($2,500 ÷ 100 = $25).
- Rule: CPA < ACV → working; scale spend. CPA > ACV → broken; call audibles. Judge each ad by its own CPA: kill high-CPA ads, run low-CPA ads until they fatigue.
- Diagnostic sheet: record CPA; for each page write offer price × conversion rate = contribution to ACV; sum to total ACV; subtract CPA for your score.
- Why it works: Simple arbitrage—if a dollar in returns more than a dollar, spend as much as possible.

**Conversion Benchmarks** (below these, call an audible; above, keep testing):
- Lead funnel opt-in > 20%
- Two-step order form opt-in > 10–15%; book/cart sales conversion > 1–5%; order bump > 20%; OTO/downsell > 3–15%
- VSL conversion > 1–3%; webinar registration > 20%; live webinar show-up > 10–20%; automated webinar show-up > 50–80%; live webinar buy rate hot traffic > 10%, cold > 1–5%; auto-webinar buy rate > 3–8%; product launch registration > 20%
- Phone funnels: cost per application < $100

**Hook, Story, Offer Audit**: for each below-benchmark page (or ad), ask: What's the hook—how could it be better? Does the story build perceived value of the offer? How could the offer be sexier? Brainstorm dozens of tests; clone the page in ClickFunnels, change one element (headline, video), split traffic with the slider, run days to weeks; winner becomes the new **control**.

**CPA Audibles (ad creative volume)**: high CPA is more often the ad than the page. Ads fatigue in weeks online (vs. ~18 months for TV infomercials), so produce lots of creative; cut losers fast and scale winners until CPA approaches ACV, then replace.

**12-Step Dotcom Secrets Process (conclusion)**: (1) define dream customer; (2) find where they congregate; (3) craft hooks and stories; (4) build relationship via attractive character to ascend the value ladder; (5) pick a ladder tier and funnel type; (6) plug scripts into pages; (7) launch with one customer's worth of ad spend and find non-converting hooks/stories/offers; (8) split-test controls until ACV > CPA; (9) keep making ads to hold CPA down while raising ACV, until Two Comma Club; (10) build the next funnel, email existing customers, stack it; (11) repeat 6–8 for it; (12) pick the next funnel.

## Key Concepts
- **Funnel audible** — a data-driven change to an underperforming step.
- **Break-even funnel** — ad spend recovered; leads acquired free.
- **CPA / ACV** — cost to acquire a customer / average spend per customer.
- **Control** — the current winning page version.
- **Give yourself a raise** — daily split tests that compound revenue.
- **Ad fatigue** — rising CPA as audiences tire of a creative.
- **Money follows speed** — (Joe Vitale) simple funnels ship fast.
- **One funnel away** — one properly exploited funnel can change everything.

## Mental Models
- Think of launch as scouting footage, not the championship match.
- Use complexity only if you can still diagnose it—usually you can't.
- Think "the market never lies"; your opinion is wrong most of the time.
- Use "if it's not working, it's the hook, story, or offer" as the universal diagnostic.

## Anti-patterns
- **50-page funnel maps with dozens of branches**: impossible to diagnose; often a consultant flexing.
- **Scrapping a funnel type after one test**: audible the weak step first.
- **Trusting your own opinion or a guru's review**: only credit-card votes count.
- **Running one ad forever**: fatigue raises CPA; keep producing creative.
- **Headlines that give away the answer**: kill curiosity and registrations.

## Worked Example
Mike Schmidt and AJ Rivera's webinar: registrations cost $24.85 and only 22.4% showed up. The headline revealed the topic (a method for more real five-star reviews). Audible: headline only—say what the webinar is *not* about to create curiosity. Result: cost per registration fell to $5.84 and show-up rose to 31.7%. Raise math: a page converting at 3% earning $1,000/week, lifted to 4%, adds about $17,362/year from one test. Ad volume: Dean Graziosi outsold Russell's book 4:1 by filming ~4x as many phone-shot ads and rotating out fatigued ones.

## Key Takeaways
1. Keep funnels to 3–5 pages and one soap opera sequence so problems are obvious.
2. Test with one full-funnel customer's worth of ad spend; aim to break even.
3. Track CPA and ACV per ad and per page; scale when ACV > CPA.
4. Compare each step to the benchmarks; fix the hook, story, or offer on laggards.
5. Always run a split test against the control.
6. Produce ad creative continuously to outrun fatigue.
7. Hit the Two Comma Club, then build and stack the next funnel.

## Connects To
b1-ch02 (hook, story, offer), b1-ch18 (headline testing), b1-ch26 (split tests in ClickFunnels), b1-ch27 (funnel stacking), b1-ch15 (webinar benchmarks), b1-ch07 (soap opera sequence), b2-ch16 (testing live), b3-ch09 (paid ads), b3-ch01 (dream customer), b3-ch02 (Dream 100), b3-ch19 (cold traffic).
