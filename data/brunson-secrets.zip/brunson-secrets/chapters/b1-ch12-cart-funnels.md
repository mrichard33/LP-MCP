# DotCom Secret 12: Cart Funnels

## Core Idea
Traditional e-commerce stores fail with paid traffic because too many choices confuse people, and a confused mind says no, so average cart value can't pay for ads. A cart funnel replaces the store with one irresistible front-end offer built from your best-selling SKU, a demo-led sales page, a two-step order form with a quantity selector and bump, upsells that sell more of the same at a discount, then related SKUs, and an offer-wall thank-you page. Its structure matches the book funnel; the strategy differs.

## Frameworks Introduced

**Front-End Offer Selection for E-commerce**
- How: (1) Review every SKU in the Shopify or Amazon store. (2) Pick the sexiest, best-selling item; ask staff if you don't know. (3) Bundle the bestseller and give lesser-known SKUs away free so the headline can say "free" (twice, if possible).
- Why it works / failure mode: it turns a commodity into an offer. A great video hook and story still fail if the offer is just "buy our product."

**Cart Funnel pages**
1. **Sales page**: a **product demo video** that works as hook, story, and offer (the Billy Mays model). The headline states the offer plainly rather than relying on curiosity. Use a two-step order form (shipping address, then card).
2. **Order form levers** (step 2): a **product/quantity selector** to raise units per order, and an **order form bump** (rush shipping, a complementary item).
3. **Upsell 1**: **more of the same at a buyer's discount** (for themselves or as gifts). A simple page with no video; state the one-time offer. Put a loss-framed no-thanks link next to the button.
4. **Additional upsells** (optional): the next logical SKUs, ordered by best-seller rank (hot dogs, then buns, ketchup, mustard). Three or four post-purchase offers don't seem to hurt lifetime value here, because shoppers are used to Amazon-style choice.
5. **Thank-you page / offer wall**: confirm the order, set shipping and support expectations, and show a grid of other offers ("tell me more" buttons) that lead into other funnels.
- When to use: physical products, e-commerce, Amazon sellers moving to paid traffic.

**OTO Rule for Physical Products (contrast with b1-ch11)**
- Info products: never sell more of the same; sell the next need.
- Physical products: do sell more of the same, at a discount, first. Then sell complementary SKUs.

## Key Concepts
- **Cart funnel**: an unboxing funnel for physical products.
- **Confused mind says no**: multi-product catalog pages kill conversion.
- **SKU**: a stock-keeping unit. Choose the best seller for the front end.
- **Bundle with free add-ons**: buy X of the bestseller and get lesser SKUs free.
- **Product demo**: the most effective way to sell physical goods.
- **Quantity selector**: an order-form lever for more units.
- **Offer wall**: a thank-you page that lists more offers and funnels.
- **Buyer's discount upsell**: a cheaper price per unit after the first purchase.

## Mental Models
- Think of the front end as your single best-selling SKU dressed up as an irresistible offer, not a catalog.
- Use headline clarity for physical goods and curiosity for info goods.
- Think of the upsell sequence as a guided Amazon cart: more of this, then what goes with it.

## Anti-patterns
- **Sending paid traffic to a standard store or catalog page**: confusion leads to low conversion and low average cart value.
- **A great video with a weak offer**: the hook and story are wasted.
- **Needlessly re-explaining a "more of the same" upsell with a video**: a simple statement is enough.
- **Applying the info-product upsell rule to physical goods**: you leave the easiest upsell on the table.

## Worked Example
**FiberFix (repair wrap), with the Harmon Brothers:** their viral video drove traffic, but the Amazon-style store didn't convert. The new offer: buy three 1-inch wraps, get two 2-inch wraps free and one 4-inch wrap free, so "free" appears twice in the headline. Page 1 is the demo video, the offer headline, and a two-step form. Upsell 1 adds one or two more starter kits at $19.99 each (vs. $24.97 on page 1). Upsell 2 is the heat wrap (their number two Amazon seller). The last offer is the "Manly Man Kit" at $49.95. It was a trade: the funnel for FiberFix in exchange for a ClickFunnels video script.

**Camping World (Marcus Lemonis):** about a dozen employees named dissolving toilet paper as the best seller, so the front end became a free four-pack.

**Trey Lewellen's flashlight funnel:** the thank-you page offer wall shows bottle targets, gun-cleaning oil, and silhouette targets, free via "tell me more" buttons.

## Key Takeaways
1. Replace your store front with a single best-seller bundle and put "free" in the headline.
2. Lead with a product demo video and a plain offer headline.
3. Use a two-step order form with a quantity selector and a simple bump (rush shipping, a complementary item).
4. Make the first upsell more of the same at a buyer's discount, then add complementary SKUs by sales rank.
5. Three or four post-purchase offers are acceptable in e-commerce.
6. End on an offer wall that feeds your other funnels.

## Connects To
b1-ch11 (Book Funnels: shared structure, bump, CPA/ACV), b1-ch02 (commodity to offer), b1-ch06 (qualify buyers and hyperactive buyers), b1-ch13 (Challenge Funnels), b1-ch14 (Video Sales Letter Funnels), b1-ch21 (OTO script), b3-ch09 (paid ads economics).
