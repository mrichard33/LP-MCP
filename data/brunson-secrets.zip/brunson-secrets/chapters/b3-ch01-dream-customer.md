# Traffic Secrets — Secret #1: Who Is Your Dream Customer?

## Core Idea
Traffic is not created; it already exists in congregations of your Dream Customers. Before touching any ad platform, get so clear on who your Dream Customer is (core desire, direction of movement, the conversation in their head) that finding where they gather becomes obvious.

## Frameworks Introduced
**Dream Customer Avatar (customer-centric filter)**: a fictional, fully detailed persona (Sally Beauty Supply's "Alexis": photos, bio, kids, income, home) that every decision is run through.
- When to use: before building offers, ads, funnels, or choosing traffic sources; as a veto test for any creative/product decision.
- How: (1) write a bio (age, family, income, home, daily routine); (2) list their pains and desires; (3) run every product, ad, color, page and promo past it: "Would they love this?" Yes = go; no = kill.
- Why it works / failure mode: product-obsessed companies lose to customer-obsessed ones (Brunson credits ClickFunnels beating better-funded rivals to this). Failure mode: a vague avatar makes it impossible to find where they congregate (Secret #2).

**"Your Mess Is Your Message" (Nicholas Bayley)**: most businesses come from a problem the founder solved; your former self is the Dream Customer.
- When to use: when you can't articulate the customer's inner dialogue.
- How: go back to when you had the problem; recall and write what you felt and said to yourself. Example: Stacey and Paul Martino turned a failing marriage into a program where one spouse changes the relationship. Brunson reports about a 1% divorce rate among students.

**Three Core Markets / Desires**: health, wealth, relationships. Every purchase is made to get a result in one of the three.
- When to use: first layer of getting inside the customer's head; also used to expand a Dream 100 list (see b3-ch02).
- How: pick ONE desire per message. If a product fits several, build a separate ad and funnel for each desire. Asking prospects to believe two things at once cuts conversions in half or worse (often 90%+). Products that "fit none" still fit one through their marketing (a Gillette razor ad sells relationships).

**Away From Pain / Toward Pleasure**: at the moment of a decision, every prospect is moving in one of two directions.
- When to use: when writing hooks, choosing keywords, and mapping the phrases that point to congregations.
- How: for your desire, write at least 12 phrases for each direction. Examples: health-pain "I hate what I see in the mirror"; health-pleasure "I want to run a marathon." Sources: (1) phrases you used to say to yourself; (2) forums, message boards, groups; (3) empathetic role-play. Keep adding phrases every day; each new phrase can open a new traffic stream.

**Entering the Conversation Already Taking Place in the Customer's Mind (Robert Collier)**: don't invent a clever campaign. Plug into the internal dialogue the prospect already has.

**The Searcher vs. the Scroller**: two traffic types.
- Search (Yellow Pages → Google): the buyer comes to you with a need. Pro: hot, ready-to-buy traffic. Con: they're comparison shopping, so you get pushed toward competing on price.
- Interruption (first TV ad in 1941, then Facebook ads in 2007): you interrupt a captive audience and create desire. Pro: you target by interest and sell on perceived value, not price. Con: you must be good at Hook Story Offer.
- Why it works: interruption plus a presentation turns a $199 commodity into a high-value sale. Trevor Chapman's door-to-door alarm reps closed monitoring contracts worth about $2,999 over five years, versus the ~$199 alarm a searcher buys on Amazon.

## Key Concepts
- **Dream Customer**: the specific person you most want to serve; the starting point of all traffic work.
- **Customer avatar**: a documented fictional persona used as the decision filter.
- **Customer-centric vs. product-centric**: organizing decisions around the customer instead of the product.
- **Three core desires**: health, wealth, relationships.
- **Away from pain / toward pleasure**: the two directions of motivation; the same desire can come with opposite internal reasons.
- **Search-based traffic**: people actively looking for a solution to an existing need.
- **Interruption-based traffic**: people targeted by interests and interrupted with a hook that creates desire.
- **Perceived value**: value created by the story or presentation. It lets you sell above commodity price.

## Mental Models
- Think of your business as being about the customer, not you or your product.
- Use search traffic when demand already exists and you can win on offer; use interruption when you'd rather sell on perceived value than price.
- Use "one desire, one message, one funnel" whenever a product can serve multiple desires.
- Think of the phrase list as a map: each phrase points to a congregation (Secret #2).

## Anti-patterns
- **Build it and wait**: assuming a great product attracts customers. Discovery is the #1 reason new businesses fail.
- **Being "above" traffic**: refusing to buy ads or put in sweat equity because the product is "so good."
- **Two desires in one message**: splits belief and slashes conversion.
- **Competing on price in search**: searchers compare, and being cheapest is never a strategy. Win with funnels and offers instead.
- **Forgetting your past pain**: you lose the customer's inner language.

## Worked Example
Dr. Wolner, a chiropractor, had eight years of schooling, a loan and a remodeled office, but no patients and no cash. His fix: identify the Dream Customer, build a client-acquisition funnel, and learn Facebook and Google ads. Result: new patients now come in 24/7.
Phrase-mapping template (wealth):
- Pain: "I hate my job and want to fire my boss" / "I have no savings" / "everyone around me earns more."
- Pleasure: "I want my dream house" / "grow my company for more impact" / "learn leadership to grow my team."

## Key Takeaways
1. Write a detailed Dream Customer avatar and use it as a yes/no filter on every decision.
2. Pick ONE core desire (health, wealth or relationships) per ad and funnel. Split multi-desire products into separate funnels.
3. Write 12+ away-from-pain and 12+ toward-pleasure phrases, and keep adding to the list daily.
4. Mine your own past struggle ("mess") for the customer's exact language.
5. Decide per campaign whether you're catching searchers (be ready to compete on offer) or interrupting scrollers (invest in Hook Story Offer).

## Connects To
b3-ch02 (Dream 100: where they congregate), b3-ch03 (Hook Story Offer for interruption traffic), b3-ch12 (Google/search), b3-ch11 (Facebook/interruption), b2 Expert Secrets (three core markets, epiphany bridge), b1-ch04 (attractive character), b1-ch02 (hook-story-offer).
