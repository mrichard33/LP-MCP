# Expert Secrets — Secret 12: The Big Domino

## Core Idea
Find the one belief which, once accepted, knocks down or makes irrelevant every other objection. Then open the presentation by stating it and making the first attempt to topple it with your origin story. Perry Belcher's analysis showed that asking for more than one belief cut conversions roughly in half.

## Frameworks Introduced
**The Big Domino Statement**: "If I can make people believe that [new opportunity] is the key to [what they desire most] and is attainable only through [my specific vehicle], then all other objections and concerns become irrelevant and they have to give me money."
- When to use: before writing any sales message, and as a validity check on your offer.
- How: fill in the three blanks. Check the result as a modus ponens argument (if A then B; A; therefore B). If the statement feels false or weak, you probably have an improvement offer instead of a new opportunity.
- Why it works / failure mode: it reduces the sale to a single belief. It fails when the "opportunity" is mainstream (cutting calories + exercise), because buyers can get it from many vendors. The ketosis version works because it is a blue ocean.

**Who/What Statement**: "I'm going to teach [sub-market] how to [result] through [your niche/new opportunity]."
- When to use: first step, to define the audience and the hook.

**Opportunity-Switch Title**: "How to [result they desire most] without [thing they fear most]."
- When to use: title slide and registration-page headline.

**Blair Warren rapport opener (intro slides)**: cover all five persuasion levers at the start: justify their failures, allay their fears, throw rocks at their enemies, confirm their suspicions, encourage their dreams.

**Big Domino slide sequence (first 15 min / 1/6)**:
1. Title slide (opportunity-switch headline + "Welcome, I'm __, today I'll show you how to __ without __").
2. Intro/rapport slides (Blair Warren's five levers).
3. The Ruler slide: state your goals so people judge you by your measuring stick. Include the "two types of people" line (beginners get X, advanced get Y; or retail vs. online).
4. Big Domino slide: "In the next 90 minutes my goal is to get you to believe [new opportunity] is the key to [desire]; I'll show you my proprietary frameworks."
5. Qualify yourself: one or two highlight-reel items, then "but it wasn't always that way... I was just like you."
6. Epiphany bridge origin story slides: about one slide per step of the epiphany bridge script. This is the first attempt at the domino.

## Key Concepts
- **Big Domino**: the single belief that removes all other resistance.
- **Modus ponens**: the logic form (if A then B; A; therefore B) behind a valid domino argument.
- **Improvement offer test**: if you can't write a valid domino statement, you haven't created a new opportunity or blue ocean.
- **The Ruler**: stated goals that set how the audience will evaluate the presentation.
- **Inclusion**: telling multiple sub-groups up front what each will get, so no one wonders "is this for me?"
- **Qualify yourself**: establish credibility briefly without breaking rapport by bragging.
- **Origin story**: the epiphany bridge story of how you discovered the new opportunity.

## Mental Models
- Think like Tim Ferriss: find the one thing that makes all other tasks fall or become irrelevant.
- Use the domino statement as a diagnostic. If it won't hold logically, fix the offer, not the copy.
- Think of the first 15 minutes as winning rapport plus one full swing at the domino. Some people will buy on the origin story alone.

## Anti-patterns
- **Multiple core beliefs**: each extra ask roughly halves conversion (Perry Belcher's data).
- **Mainstream "opportunity"**: red-ocean claims create no urgency to buy from *you*.
- **Leading with your resume**: long self-praise breaks rapport. Pivot quickly to the "I was like you" backstory.
- **Not stating your goals**: people judge you against their own goals and leave unsatisfied.

## Worked Example
ClickFunnels domino: "If I can make people believe funnels are the key to online business success and are attainable only through ClickFunnels, all other objections become irrelevant."
Title: "How to create a seven-figure funnel in under 30 minutes without hiring (or being held hostage by) a tech guy."
Other titles: flip your first house on eBay for $10K this weekend without a bank loan; reconnect with your wife without painful counseling; lose weight via ketosis without giving up your favorite carbs.

## Key Takeaways
1. Write and logic-check your Big Domino statement. Rework the offer if it fails.
2. Draft a who/what statement, then a "How to X without Y" title.
3. Open with Blair Warren's five levers to build instant rapport.
4. Use the Ruler plus inclusion lines so every segment knows it's in the right place.
5. Keep qualification short, then move into the epiphany bridge origin story as the first domino attack.

## Connects To
b2-ch04 (new opportunity, blue ocean), b2-ch09 (epiphany bridge script), b2-ch11 (framework overview), b2-ch13 (three secrets), b1-ch02 (hook-story-offer), b1-ch22 (Perfect Webinar script), b2-ch16 (registration headline uses the same title formula).
