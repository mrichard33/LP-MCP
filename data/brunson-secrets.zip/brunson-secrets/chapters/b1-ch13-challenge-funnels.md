# DotCom Secret 13: Challenge Funnels

## Core Idea
Sell a paid, time-boxed challenge (for example, $47 for 21 days) that gets the dream customer a quick, tangible result. That result makes the challenge the doorway to the rest of the Value Ladder. Challengers show up and buy at the end-of-challenge presentation at far higher rates than cold webinar traffic. This chapter was guest-written by Natasha Hazlett.

## Frameworks Introduced

**Why a challenge sits at the Value Ladder doorway (four benefits)**
1. Customers get a result quickly.
2. Everyone learns a shared vocabulary and foundation, so later rungs deliver faster.
3. It trains customers in how you work.
4. It warms up dream customers and repels poor fits.
- ClickFunnels built the "One Funnel Away" (OFA) Challenge, ran more than 5,000 people through the first round, and then wove it into every upsell flow, follow-up sequence, and onboarding call.

**Challenge Design**
- **Length**: 14 to 30 days. Under 14 is too short to build trust and a tribe; over 30 and people lose interest. (Unstoppable Influence runs 21 days; OFA runs 30.)
- **Location**: a closed Facebook group, archived after each round, with a new group for the next. Or put the content in a members area on autopilot and use the group for support and accountability.
- **Format**: live video is best. It creates urgency to show up, drives action and results, and builds community. Pre-recorded content streamed as "live" (OneStream, Live Pigeon) saves time. Text or email alone won't build connection.
- **Ascension**: near the end, run a Perfect Webinar for the next offer, or make a limited-time discount offer with no webinar.

**Challenge Funnel pages**
1. **Sales page**: a clear hook promising X result in Y days. Keep the story short, to bond with the Attractive Character and show you've walked the path. Show the **path** (topics and transformation), **prizes** (seed the end-of-challenge offer), a **stack** that separates price from transformational value, and testimonials (screenshots from social).
   - **Order bump**: something they believe they need to succeed in the challenge, not random extra training. Examples: audiobook, templates, workbooks, supplements, swag.
2. **Upsells (one or two)**: tools that help them finish the challenge, not more content to consume. Examples: a private accountability coach, a physical journal and printed workbook.
3. **Thank-you page**: how to access the materials and when any physical items will ship.
- **Success criteria (three things decide whether a challenge works)**: (1) clarity of the promise, (2) the challenger's belief that they can reach the result, (3) the expert's credibility.
- Why it works / failure mode: challengers get results together, so they trust the character and attend the pitch. A vague or unbelievable promise flops.

## Key Concepts
- **Challenge funnel**: an unboxing funnel that sells a paid group challenge.
- **Clear hook**: a simple, believable "X in Y days" result.
- **The path**: the transformation journey laid out on the sales page.
- **Prizes**: incentives that seed the next offer.
- **Price vs. value**: price is the tag; value is the transformational effect (a $47 entry framed as $2,100 of training value).
- **Completion-focused upsells**: tools that help them finish, not more work.
- **Webinar fatigue**: falling cold show rates and conversions that challenges can revive.
- **Customer lifetime value**: what a buyer is worth across the whole ladder. A $47 challenger was worth more than $420.

## Mental Models
- Think of a challenge as a results-first onboarding that sells the next rung by proving the first.
- Use a challenge in place of a free-plus-shipping front end when the free book economics don't work.
- Think of every bump and upsell as a question: does this help them finish?

## Anti-patterns
- **Challenges shorter than 14 days or longer than 30**: too short to build trust, too long to hold interest.
- **Written-only delivery**: little connection or community.
- **Bumps or upsells that add more content to consume**: they lower completion and results.
- **Vague or unbelievable promises**: these are the main reason challenges flop.

## Worked Example
**Unstoppable Influence (Natasha and Rich Hazlett):** the free-plus-shipping book model didn't pencil out, so they sold a $47 21-day challenge with the book included and a Perfect Webinar bolted on at the end. Cold Facebook traffic went straight to the sales page. The first round drew 450 challengers in two weeks and forced a rush to warehousing and fulfillment. Compared with advertising the webinar directly (18% show rate, 4% conversion on a $997 three-month coaching offer), challengers registered at 70 to 75%, showed up at 50% or more, and converted at 20%. The first challenge made $105K, and they reached the Two Comma Club 10 months later. The audiobook bump converts at more than 30%. Upsells are an accountability coach and a mailed journal and workbook. Challenger lifetime value is above $420.

**Christie Koldred-Nickel (weight loss):** the hook is "lose 10 pounds in 30 days." There is no webinar; near the end she makes a limited-time discount offer on a $997 custom nutrition and coaching package, and about 10% of challengers buy. Ads return 3 to 4x.

## Key Takeaways
1. Promise one clear, believable result in 14 to 30 days, and make sure the expert's credibility supports it.
2. Run it in a closed group with live (or streamed-as-live) video.
3. Build the sales page from hook, short story, path, prizes, stack (price vs. value), and testimonials.
4. Make the bump and upsells completion tools (audiobook, workbook, accountability coach).
5. End with a Perfect Webinar or a limited-time offer for the next rung.
6. Consider sending book buyers into the challenge as the Value Ladder doorway.

## Connects To
b1-ch11 (Book Funnels and unboxing mechanics), b1-ch15 (Webinar Funnels, the end-of-challenge pitch), b1-ch22 (Perfect Webinar script), b1-ch02 (stack and offer), b1-ch04 (Attractive Character bonding), b2-ch09 through b2-ch11 (Perfect Webinar and stack), b3-ch05 (community and content).
