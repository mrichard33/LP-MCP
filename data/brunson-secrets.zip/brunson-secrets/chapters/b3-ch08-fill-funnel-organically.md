# Traffic Secrets — Secret #8: Fill Your Funnel Organically (Working Your Way In)

## Core Idea
Social networking isn't about making money; it's about making friends. Treat each platform as a party where you entertain, serve and connect. Treat your own profile as your house, where you invite guests into your funnels. Operate as a producer of social media, never a consumer.

## Frameworks Introduced
**The Party and the House (Perry Belcher)**: the core model for organic social traffic.
- When to use: any organic social activity (groups, comments, others' posts, your feed).
- How:
  1. **The party** (groups, others' posts, feeds): talk about your life and family, tell stories, entertain, ask questions, and introduce people to other interesting guests. Never pitch. Walking around a party saying "I sell stuff, want to buy?" makes you the jerk everyone avoids.
  2. **The house** (your personal profile): your archive of thoughts, photos, videos and interests. People who liked you at the party drop by. Give them "chips and dip" (free content).
  3. **The invitation** (from your house): invite them to take action. Register for the webinar, come to the event, read the book, join the newsletter. Selling belongs at the house, not at the party.
- Why it works / failure mode: value at the party creates curiosity and trust, so people come to your house and flow into your funnels. Failure mode: spamming links and promos on social. You get short-term results at best, engagement dies, and you conclude "social doesn't work" (Brunson's early Twitter experience).

**Producer, Not Consumer (Social Media Reset)**: use social as a business tool.
- How: (1) unfriend or unfollow almost everyone on your traffic platforms; (2) follow only your Dream 100 there, to model what works and dig your well through comments and DMs; (3) cap consumption at about **10 minutes per day** (anything beyond is wasted); (4) find the *biggest parties* (the largest groups, podcasts, blogs, videos and fan pages) and become the life of the party there.
- Why it works: cutting consumption frees up production time, and a feed of only Dream 100 accounts doubles as market research.

## Key Concepts
- **Working Your Way In (organic)**: earning attention from Dream 100 audiences through service, not ads.
- **The party**: public social spaces where you add value without selling.
- **The house**: your personal profile, where the calls to action live.
- **Chips and dip**: free content that makes visiting your house worthwhile.
- **Life of the party**: the consistently helpful, entertaining presence people seek out.
- **Social media reset**: pruning your follows down to your Dream 100.
- **Largest party in town**: prioritizing the biggest communities for exposure.

## Mental Models
- Think "would I say this in person at a party?" before you post.
- Use public spaces for friendship and your profile for offers.
- Think of every minute on social as production time, not consumption time.
- Use a long-game lens: planted seeds become a steady stream into your funnels, while spam gives spikes that fade.

## Anti-patterns
- **Pitching on social feeds / dropping funnel links in groups**: kills engagement and reads as spam.
- **Consuming more than ~10 minutes a day**: time lost that serves neither you nor your audience.
- **Following friends and noise**: distracts you from Dream 100 signals.
- **Choosing small parties**: too little exposure for the effort.
- **Judging social by short-term sales**: it's a relationship channel first.

## Worked Example
Perry Belcher on Twitter posted no ads and no product promotion, just conversation and entertainment. He built 100,000+ followers in a few months, then invited them to a webinar: 20,000+ registrants and $1M+ in sales from that one webinar. Brunson's fix after learning the model: delete every sales post, then serve, interact and entertain. His follower growth came from that change. (This chapter is short in the source; the platform-specific publishing plans are in b3-ch10 to b3-ch13.)

## Key Takeaways
1. Do a social media reset: unfollow everyone except your Dream 100 on each traffic platform.
2. Cap social consumption at about 10 minutes per day; spend the rest producing.
3. At "parties," only serve, entertain, ask questions and connect people.
4. Turn your profile into a "house" with free value and clear invitations to your funnels.
5. Find the biggest groups and communities in your niche and become a consistent, valued participant.

## Connects To
b3-ch04 (Work Your Way In, Dig Your Well), b3-ch07 (Fill Your Funnel Framework, your own show), b3-ch09 (the paid counterpart), b3-ch10 (Instagram), b3-ch11 (Facebook groups and profile), b3-ch05 (converting to owned traffic), b1-ch04 (Attractive Character).
