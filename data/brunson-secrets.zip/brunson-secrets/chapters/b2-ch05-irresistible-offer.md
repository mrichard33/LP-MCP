# Expert Secrets — Secret 5: More Money for the Same Framework

## Core Idea
People pay more for the *same* content in a different package: *Think and Grow Rich* cost $9.97 as a paperback and $97 on CD. Your product may only be an improvement offer, but wrapping it in your proprietary frameworks turns it into a new opportunity. You then raise value by changing the consumption experience and the fulfillment level, turning framework steps into tools, and bundling everything into a Stack Slide worth at least 10x the price.

## Frameworks Introduced
**Two Types of Expert Business**: (1) *selling information products*, where frameworks become books, courses, and coaching. Brunson calls this "the greatest startup in the world." (2) *Information products as fuel* for a physical-product, service, or software company. They build desire, acquire customers for free through break-even funnels, and bundle with the core product (for example, 10,000+ people paid $1,000 for a funnel course that bundled a ClickFunnels trial).

**Step 1: Increase the value of your frameworks**
- *Change the experience*: written → audio → video → live.
- *Change the fulfillment*: **Do-It-Yourself → Do-It-With-You → Do-It-For-You**, rising up the value ladder.
- **Eight packaging tiers** (same framework, rising price): pre-funnel content (free: ad hooks, posts, videos, episodes) · lead magnet (free, 2–20 min video) · book (free + shipping. Hardest to make and lowest price, but top positioning) · membership site ($10–100/mo, drip) · online course ($100–1,000, finite) · seminar/workshop ($500–5,000) · mastermind ($10K–100K, implementation) · one-on-one ($10K+, no leverage).

**Step 2: Turn frameworks into tools** (Sam Brannan's gold-rush model: framework "there's gold in the river → you need picks, shovels, pans → only my store sells them").
- Rule: *how much money you make is directly tied to how simple you make the process for customers.*
- Tool types: **software** (highest perceived value. Start small, e.g., a $120 build), **supplements** (the ultimate easy button), **physical products** (build a result framework around the product, e.g., a survival flashlight inside a disaster-survival framework, or journals and workbooks), **byproducts** (scripts, contracts, templates, cheat sheets, checklists you already made for yourself), and **information products/services** (events and coaching as implementation tools).

**Step 3: The Stack Slide** (turn frameworks into an offer)
- When to use: every offer at every step of the value ladder. The stack slide feeds every story-selling script later in the book.
- How:
  1. Item 1 = **core product**. Item 2 = **opportunity switch / opportunity stack core framework**, delivered in the modality that matches the price. (Example: ClickFunnels software + Funnel Builder Secrets course, which could be priced as a $9,997 two-day event, a $1,997 course, or a $97 audio program.)
  2. Brainstorm on a whiteboard. Left side: information products (written, audio, video, live). Keep only one or two, since too much content feels like work. Right side: **tools**, which carry higher perceived value, so lean the stack toward them.
  3. Add one bonus per false belief: **vehicle** ("this isn't the right vehicle for me" → case-study booklet or videos), **internal** ("I can't do it" → e.g., a copywriting course plus templates and swipe files), **external** ("outside force stops me" → e.g., a traffic course).
  4. Assign a value to every item. **The total must be at least 10x the price** ($97 → at least $997. $997 → at least $9,970). If it isn't, repackage or build more tools.
- Why it works / failure mode: offers de-commoditize, since the bundle is unique to you. When perceived value exceeds price, the purchase becomes easy. Failure mode: stacking lots of courses, which lowers perceived value because it looks like work.

## Key Concepts
- **Same framework, new package**: price follows format and experience, not new content.
- **DIY / Done-With-You / Done-For-You**: fulfillment levels that climb the value ladder.
- **Framework wrap**: surrounding a commodity product with your frameworks so it becomes a new opportunity.
- **Tools**: software, supplements, physical products, or byproducts that simplify a framework step.
- **Byproducts**: assets you built while running your own frameworks (scripts, contracts, training), resold as high-value bonuses.
- **Stack Slide**: an itemized, valued list of everything in the offer.
- **10x value rule**: the stack's total value is at least ten times the price.
- **Three false beliefs**: vehicle, internal, external. Each gets a stack item.

## Mental Models
- Think of your product as one step in your framework. The framework is the new opportunity.
- Use "what can simplify this step?" on each framework step to generate tool ideas.
- Think of your value ladder as one framework delivered at increasing depth and involvement.
- Use the 10x check as a go/no-go gate before you write any sales copy.

## Anti-patterns
- **Selling the bare product**: you're a commodity with price resistance.
- **Creating new content for each ladder rung**: unnecessary. Change the package instead.
- **Info-heavy stacks**: perceived value drops.
- **Launching with stack value under 10x the price**: go back to the whiteboard.
- **Ignoring byproducts**: they are free to include and often the most valued items.

## Worked Example
**High Ticket Secrets offer from byproducts.** When selling high-ticket products by phone, Brunson's team had to create sales scripts, sales-team training videos, and lawyer-drafted employee and customer contracts. When they later sold a High Ticket Secrets coaching program, the stack was: core frameworks/training + the actual scripts + the internal sales-rep training + the contracts. These byproducts cost nothing extra and became some of the most valued parts of the offer. Liz Benny did the same by bundling her social-media-manager contracts into her masterclass.

## Key Takeaways
1. Name the framework that makes your product a new opportunity and put it second on the stack.
2. Map your value ladder as one framework moving from DIY to done-with-you to done-for-you and from written to live.
3. For every framework step, ask which software, supplement, physical product, or byproduct could simplify it.
4. Add one stack item each for the vehicle, internal, and external false beliefs.
5. Keep only one or two info products in a stack and weight it toward tools.
6. Price so stack value is at least 10x the price. Redo the stack slide for every offer on the ladder.

## Connects To
b2-ch04 (opportunity switch / stack), b2-ch10 (vehicle, internal, and external false beliefs), b2-ch14 (the stack and closes), b2-ch11 (Perfect Webinar), b1-ch02 (hook-story-offer, offer creation), b1-ch03 (value ladder).
