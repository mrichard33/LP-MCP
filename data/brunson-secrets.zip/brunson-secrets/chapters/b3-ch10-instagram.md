# Traffic Secrets — Secret #10: Instagram Traffic Secrets

## Core Idea
Instagram (especially Stories) is the strongest tool for building a relationship between your audience and you as the Attractive Character. Split the app in two. **Content hooks** (profile gallery, IGTV) earn follows and never sell. **Your house** (Stories, Live) is where you pitch and push people into funnels. Run the six-step Fill Your Funnel Framework on it: grow with Dream 100 co-labs (Work Your Way In) and paid shout-outs (Buy Your Way In), and convert everything into owned traffic. Much of the method comes from Jenna Kutcher.

## Frameworks Introduced
**Fill Your Funnel Framework applied to Instagram**:
1. *History/goal*: launched Oct 2010 (100K users in week 1, 1B by June 2019); bought by Facebook for $1B in 2012. After Snapchat turned down a $3B offer, Instagram cloned its features and launched Stories (Aug 2016). The platform's goal is more attention and more ad placements. Win organically by creating content that keeps users coming back; win on paid by showing ads to Dream 100 followers.
2. *Dream 100 routine*: follow only Dream 100 accounts. Each day spend **3–5 min on posts** (like them; comment on **at least 10**) and **5 min on Stories** (DM replies to **at least 10**; swipe up on their ads to funnel hack them).
3–6. Publishing plan, Work Your Way In, Buy Your Way In, Fill Your Funnel (below).

**JK5 Method (Jenna Kutcher)**: pick 5 passion categories and rotate profile posts through them so your brand goes beyond what you sell.
- When to use: planning your profile grid.
- How: choose 5 categories (Jenna: marriage, body positivity, photography, fashion, travel; Brunson: family, funnels, faith, entrepreneurship, personal development). Make a phone album for each and sort your camera roll into them (often months of ready content). Never put two posts from the same category next to each other. Post strategically, never in real time (real time is for Stories).
- Why it works / failure mode: people follow for one category, then come to know, like and trust you. Visitors decide whether to follow in about 10 seconds. Failure mode: a random, product-only grid with low engagement.

**ABCDQ Test (before posting)**: **A**esthetics (fits the brand's personality?), **B**rand (aligned with the Dream Customer?), **C**onsistent (color and quality match the feed?), **D**iversity (different from the last post, with recognition beyond what you sell?), **Q**uality (would it stand alone as on-brand?).

**Profile Post = Hook Story Offer**:
- *Hook*: the picture.
- *Goal*: choose one per post: inspire, educate or entertain.
- *Story (caption types)*: (1) tell a relatable story; (2) ask a question (at least weekly); (3) make a list ("3 things you don't know about me").
- *Hashtags*: up to 30. They work like keywords/folders. Overt hashtags go in the caption; covert ones in the first comment. Research them from your Dream 100.
- *Offer*: every post needs a CTA, from small (double tap, emoji, comment) to big (tag 3 friends, share, link in bio). Reply to comments, since engagement signals tell the algorithm to show you more.
- Cadence: **up to 2 profile posts per day.**

**IGTV (produced video)**: turn questions your audience keeps asking in Stories and comments into produced answers. The sweet spot is **3–5 minutes** (up to 60). The first 60 seconds must hook viewers into continuing to IGTV.

**Stories = Your Reality Show (your house)**: 15-second clips that disappear after 24 hours, freestyle, documenting your day (gym, kids, commute, work in progress, e.g., sketches from writing this book). Post **10–30 stories per day**, including one that sends people to today's profile post and one swipe-up CTA (funnel, podcast, YouTube). Make **at least 1 pitch per day**. Swipe-up unlocks at **10,000 followers**; before that, use the link in your bio. **Highlights**: one per JK5 category.

**Highlights Mini-Webinar Hack**: about once a month, spend a full day on 15–50 scripted stories selling one product, then save it as a Highlight so it keeps selling.
- Script: (1) three yes/no poll questions, covering the vehicle, the internal struggle and the external fear (from the Perfect Webinar); (2) Feel-Felt-Found stories; (3) introduce the special offer; (4) **5–20 proof stories** (testimonials, screenshots); (5) recap the offer; (6) urgency and scarcity.
- Why it works: it's a permanent, evergreen pre-sell that new visitors see first when they check your Highlights.

**Instagram Live**: mirror Facebook Live (second phone, or laptop for FB and phone for IG). IG Lives disappear in 24 hours while FB Lives persist and can be boosted, so if you can only do one, go live on Facebook.

## Key Concepts
- **Content hooks vs. house**: profile and IGTV attract followers; Stories and Live sell.
- **Bio**: 150 characters to show the Attractive Character, plus one link to a funnel.
- **JK5**: five rotating brand categories.
- **ABCDQ**: the on-brand checklist.
- **Overt vs. covert hashtags**: hashtags in the caption vs. in the first comment.
- **Swipe up**: a Story link, unlocked at 10K followers.
- **Co-lab**: jointly produced content cross-posted with a Dream 100 member.
- **Shout-out**: a paid or earned tagged mention from a Dream 100 account.

## Mental Models
- Think of the grid as a curated magazine and Stories as a live reality show.
- Use Stories to document work in progress. Followers who watch the process pre-commit to buying.
- Use engagement CTAs as algorithm fuel, not just vanity metrics.
- Think "model, don't copy." Your personality is the difference that creates true fans.

## Anti-patterns
- **Selling in profile posts / IGTV**: those are for follows.
- **Real-time posting to the grid**: that's for Stories.
- **Random, product-only grid**: fails the 10-second follow decision.
- **Following interesting people for fun**: distraction. Follow only your Dream 100.
- **Copying Dream 100 posts**: unethical and ineffective.
- **Posting without a CTA or ignoring comments**: starves the algorithm.
- **Relying on IG Live alone**: the content vanishes after 24 hours.

## Worked Example
- **Stories vs. Snapchat test (Aug 2016)**: identical posts on both. Brunson's IG audience was about 30% the size of his Snapchat audience but drew **4× the views per story** because of early-adopter reach, so he abandoned Snapchat.
- **Co-lab**: a follower's question answered by both Brunson and Steve J. Larsen, cut into one IGTV video, cross-posted and cross-tagged. Thousands of new followers almost overnight. Variants: question swaps; photos at events tagged on both profiles.
- **Paid shout-out**: @PRBossBabe (82K+ followers) was sent the *30 Days* book and paid to post a photo, the story and a tag, plus Stories with swipe-ups to the book funnel. Result: 4,978 likes and hundreds of new followers. Shout-out agencies can handle sourcing.
- Daily plan (< 1 hour): 1–2 JK5 profile posts (ABCDQ, goal, caption type, 30 hashtags, CTA); 10–30 Stories with 1 pitch and 1 swipe-up; 3–5 min Dream 100 posts and 5 min Stories (10 comments, 10 DMs); IGTV answers as questions pile up; a monthly Highlights mini-webinar.

## Key Takeaways
1. Write a 150-character Attractive Character bio with one funnel link, modeled on your Dream 100's bios.
2. Set up JK5 albums and post up to 2 ABCDQ-approved grid posts per day, each with a goal, caption type, hashtags and CTA.
3. Post 10–30 Stories per day documenting your journey, with at least 1 pitch and 1 swipe-up or link.
4. Run a monthly Highlights mini-webinar (15–50 stories) and pin it.
5. Spend about 10 min per day on the Dream 100: 10 post comments and 10 story DMs.
6. Grow with co-labs (Work Your Way In) and paid shout-outs (Buy Your Way In), then add prospecting and retargeting ads (b3-ch09).

## Connects To
b3-ch07 (Fill Your Funnel Framework, Document Don't Create), b3-ch08 (party/house, producer not consumer), b3-ch09 (prospecting and retargeting ads), b3-ch11 (Facebook Live, ads), b3-ch15 (Conversation Domination), b3-ch03 (Hook Story Offer), b1-ch04 (Attractive Character), b2-ch11 (Perfect Webinar questions), b2-ch14 (stack and closes).
