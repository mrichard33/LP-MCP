# Traffic Secrets — Secret 11: Facebook Traffic Secrets

## Core Idea
Facebook is the biggest ongoing "social party" where your dream customers already hang out; run the six-step Fill Your Funnel framework on it by mastering four distinct areas (personal profile, fan page, group, Messenger), each with its own job, so earned and bought attention becomes traffic you own.

## Frameworks Introduced

**Fill Your Funnel framework (applied to Facebook)**: (1) Understand the history and the goal; (2) Find your Dream 100 on this platform; (3) Identify the publishing strategy and create your publishing plan; (4) Work your way in; (5) Buy your way in; (6) Fill your funnel.
- When to use: entering Facebook, or re-entering after an algorithm change.
- How: ask the three platform questions first: What is the platform's goal? What strategy helps it reach that goal? What tactics is it rewarding right now? Facebook's goal is to keep users on-platform so it can show ads. Tactics change daily, so read them from what your Dream 100 are doing that gets engagement in your feed.
- Why it works / failure mode: platforms reward whatever behavior they are pushing at the moment. Viral shares worked until the post-IPO change, then paid "forced viral" boosting, then free reach for Facebook Live until it beat Periscope. If you learn one tactic instead of the platform's goal, the next "Zuck snap" wipes you out.

**The Four Areas of Facebook (Home / Show / Hangout / Distribution)**
1. **Personal profile = your home** (work your way in). Turn on followers: you are capped at 5,000 friends, but followers are unlimited. Customize the cover photo (brand, no CTA), the intro section (your business card), and a featured image that links to a post carrying your offers (Brunson's links to his three books). Post at least one daily update in hook, story, offer form, rotating through the **JK5** categories. Put funnel links in the comments, not in the post, because link posts get suppressed. Reply to comments.
2. **Fan page = your show** (buy your way in). Treat it as your Facebook website and the first impression paid-ad viewers see. **$10–$20 test**: if you would not spend $10–$20 boosting a piece of content, don't post it. Post four types: produced value videos (hook and story, no CTA, built for shares); live value videos (Facebook favored live at the time); live Perfect Webinars (the "right hooks" that sell, including the Perfect Webinar hack and Jamie Cross's 5-minute Perfect Webinar); and reruns (native reposts of high-performing content from other platforms). Aim for 3–4 value pieces per hard CTA (Gary Vaynerchuk's *Jab, Jab, Jab, Right Hook*). Boost everything $10–$20. Keep a funnel-driving live running as long as it at least breaks even.
3. **Group = your hangout.** Host your own party, because whoever hosts the party holds the influence. Run a weekly unstructured hangout: tell a story, take open questions, and end with a CTA (for Brunson, the free trial).
4. **Messenger = your distribution channel** (rented, not owned). Send no more than about one message a week, and make it a *conversation* (question, then button choices) rather than a broadcast. Grow the list three ways: a pop-up on the fan page, an opt-in checkbox on landing pages, and a comment-keyword lead magnet delivered during a live. Send people to on-platform content such as a fan-page live and do the selling off Messenger.
- Why it works: each area matches a different temperature and job. The profile earns attention, the page amplifies it with money, the group deepens the relationship, and Messenger reactivates people.

**Group networking routine (work your way in)**
- How: join groups until their combined membership passes about 1M. Each day, post one value-only piece (no pitch, no link) per group and answer at least 3 questions per group. Cap it at about 30 minutes a day total. People click through to your profile, where the JK5 posts convert them.

**Dream 100 ecosystem target**
- How: follow influencers' fan pages and personal profiles, and join their groups, until the total audience you are plugged into is at least 1M (e.g. 20 influencers × 30K = 600K, so keep going). Local businesses can set a smaller number. Prune your feed so it becomes a market-research tool.

## Key Concepts
- **Social party**: a platform viewed as an ongoing gathering. You don't create traffic, you find existing streams.
- **Forced viral video**: a paid-boosted video that earns 2–3 free views per paid view once enough people share it.
- **JK5 method**: Jenna Kutcher's rule of five rotating brand categories. Brunson's are family, funnels, faith, entrepreneurship, and personal development. Rotating also keeps a personal profile from looking like a business.
- **Fan page**: the paid-ads home. Only curated, boost-worthy content goes there.
- **Unpublished posts**: ad-only posts used to test many hooks without cluttering the page feed.
- **Rented vs. owned**: a Messenger list belongs to Facebook and can be shut off, so treat it gently.
- **Reruns**: native reposts of proven content from other platforms.

## Mental Models
- Think of the profile as your home, the fan page as your TV show, the group as your hangout, and Messenger as your delivery truck.
- Use the personal profile and Instagram as a free test lab for hooks, and promote only the winners to produced, boosted fan-page content.
- Treat every Facebook tactic as a snapshot: the goal (keep users on the platform) outlives the feature set.

## Anti-patterns
- **Profile used as a storefront** (CTA on the cover, all-business posts): Facebook penalizes or restricts personal pages run like businesses.
- **Dropping links in other people's groups**: gets you kicked out and ruins your reputation.
- **Posting to the fan page what you wouldn't pay to boost**: low engagement drags down reach across the whole page.
- **Messenger blasts and hard pitches**: complaints get the channel shut down.
- **Paid-only strategy**: fast for testing, but fragile long-term without a content foundation.

## Worked Example
**Brunson's ClickFunnels group** (about 2020): 223K+ members, 1,200+ new members a week organically, 317 posts a day, about 9,400 comments and reactions a day, and top posts reaching 30K–50K impressions. More than 1,000 people a month join ClickFunnels directly from the group, backed by a weekly hangout that ends in a trial CTA. **Alison Prince's lead-magnet live**: she teaches a "10 tips / 7 tools" live, shows a printed PDF, and has viewers comment a keyword to get it via Messenger, adding hundreds of subscribers per live.

## Key Takeaways
1. Follow and join until your Dream 100 ecosystem reaches about 1M people, then use the feed as market research.
2. Post one hook-story-offer update a day on your profile, rotating JK5 categories, with links in the comments.
3. Put only boost-worthy content on the fan page and spend $10–$20 boosting each post. Run 3–4 value pieces per pitch.
4. Start a group and hold a weekly hangout that ends in a CTA.
5. Send about one conversational Messenger touch a week and sell off-channel.
6. Network in groups for 30 minutes a day: one value post and three answers per group, no links.
7. Layer paid boosting to Dream 100 followers once the publishing base exists. Tactics date quickly (the book is from 2020), so re-check them against your Dream 100.

## Connects To
b3-ch02 (Dream 100), b3-ch04 (work/buy your way in), b3-ch05 (traffic you own), b3-ch08 (organic publishing), b3-ch09 (paid ads, retargeting buckets), b3-ch10 (Instagram, JK5), b3-ch14 (framework reuse), b3-ch15 (Conversation Domination), b1-ch02 (Hook, Story, Offer), b2 Perfect Webinar.
