# Expert Secrets — Secret 6: The Future-Based Cause

## Core Idea
The last element of a mass movement is a **Future-Based Cause**: a vision of a better future your tribe can put its faith in. As with Bannister's four-minute mile, once someone shows a result is possible, others believe they can reach it too. You build the cause with four moves: run on a platform (slogan), give members an identity shift, create milestone awards that pull them forward, and unite them around a social mission so they transform, not just achieve.

## Frameworks Introduced
**Future-Based Cause (4 steps)**
1. **Launch your platform, as if you were running for president of your movement.** Brunson's study of winning US presidential campaigns found that winners cast a vision of the future and offered a new opportunity, while losers ran improvement offers focused on the present (e.g., Reagan's "Let's make America great again" vs. Carter's incumbent-trust message).
   - How: write a campaign slogan that captures where your people want to go. Leave it open so each member can finish the sentence themselves ("You're just one funnel away…"). Repeat it everywhere: sign-offs, emails, and event themes.
2. **Give them an Identity Shift.** Customers succeed when being a member becomes who they *are*, not what they *want to do* ("I am a drummer" vs. "I want to learn drums"). You must keep selling to them to "take them off the market," or they drift back to old habits or another expert's opportunity.
   - **Tribe identity**: name the tribe after the members, not after you (Funnel Hackers, Lady Bosses). Kaelin Poulin's original brand, built around her own name, sold, but it didn't create a movement. After she rebranded to LadyBoss, churn dropped by about 10% within three months.
   - **Personal identity / "I am" statement**: something wearable ("I'm a funnel hacker," "I'm a lady boss"). T-shirts work like capes. One member kept paying for an account he never used because he loved his #FunnelHacker shirt.
   - **Title of Liberty / manifesto**: a rallying document that attracts fits, repels non-fits, and reminds members who they're becoming. Distribute it as posters and phone wallpapers.
3. **Milestone awards (journey of achievement)**: "A soldier will fight long and hard for a bit of colored ribbon." Create tiered awards for tangible milestones: Two Comma Club ($1M in a funnel), Two Comma Club X ($10M), Two Comma Club C ($100M). The first milestone should be one *you* have already hit, so it's credible. Awards shift the focus from the expert to the tribe. People come for the expert and stay for the community.
4. **Unite with a social mission (journey of transformation)**: achievement alone doesn't hold people, and they leave once they get the result. Give them a cause bigger than themselves. ClickFunnels donates per funnel to Village Impact (schools in Kenya) and funds Operation Underground Railroad, framed as **"Liberate and Educate"**. It mirrors the business mission (liberate entrepreneurs from tech, educate them) and has its own award for giving.
- Why it works / failure mode: fear of the future makes people cling to the present, while faith in the future makes them open to change (Eric Hoffer). Failure mode: a movement centered on the leader's name, or one that promises only achievement, loses members after the result.

## Key Concepts
- **Future-Based Cause**: a shared vision of a better future that unites a tribe.
- **Four-minute mile**: a result believed impossible until someone does it, after which many do.
- **Platform / campaign slogan**: the rallying line you "run for office" on.
- **Identity shift**: members adopt "I am X," which makes the required behaviors natural.
- **Taking them off the market**: continued selling that keeps members from drifting.
- **Title of Liberty / manifesto**: a written creed for the tribe.
- **Colored ribbon / milestone award**: a tangible marker that pulls people through the journey.
- **Journey of achievement vs. transformation**: external result vs. who they become.

## Mental Models
- Think of your role as a candidate. Winners sell a future (new opportunity), and losers sell a better present.
- Use "I am a ___" over "I want to ___" whenever you design onboarding.
- Think of awards as manufactured four-minute miles for your tribe.
- Use an open-ended slogan when your members' goals vary widely.

## Anti-patterns
- **Naming the movement after yourself**: members can't identify with it.
- **Over-specifying the slogan** ("one funnel away from being rich"): it reaches only part of the tribe.
- **Achievement-only communities**: members leave after they win.
- **Cutting identity swag on ROI grounds alone**: the intangible retention value was larger.
- **Awards you haven't earned yourself**: no credibility or hope.

## Worked Example
**"One Funnel Away" slogan.** Starting point: Gary Halbert's "you're only one sales letter away" from striking it rich. Draft 1, "…one funnel away from being rich," felt wrong because most members care about changing lives, not only money. Drafts 2–N ("…quitting your job," "…financial freedom," "…sharing your message") each fit only a segment. Final: delete the ending and use just **"You're just one funnel away."** Each member fills in their own future. Delivery: at FHL, Brunson told stories of being saved by a funnel twice at the brink of bankruptcy, then made the line the sign-off on videos, every email, and event themes. It also became the final line of the Funnel Hacker manifesto.

## Key Takeaways
1. Write a campaign slogan for "president of your movement." Test it on segments and trim it until everyone can finish it.
2. Name your tribe for the members and give them an "I am ___" statement they can wear.
3. Write a manifesto and hand it out as posters and phone wallpapers.
4. Create a tiered milestone award starting at a result you've already achieved. Celebrate winners on stage.
5. Attach a social mission that mirrors your business mission so members transform, not just achieve.
6. Keep selling to members so they stay off the market.

## Connects To
b2-ch01 (movement formula), b2-ch04 (new opportunity), b2-ch08 (Hero's Two Journeys: achievement vs. transformation), b1-ch04 (Attractive Character), b1-ch03 (value ladder retention), b2-ch13 (three secrets, belief shifts).
