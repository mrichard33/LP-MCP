# Expert Secrets — Secret 2: Teaching Your Frameworks

## Core Idea
A framework is a map that saves you when you lose your place: "your framework is your savior" (Brendon Burchard). How you teach it decides whether people value it. Brunson's "framework for teaching frameworks" pre-frames value with a learned-or-earned story before giving strategy and tactics, and closes with proof that the framework works for other people.

## Frameworks Introduced
**The Framework for Teaching Frameworks** (introduce + four steps):
- **Introduce**: say the framework's name and its description: "my [N]-step framework for [result]." Example: the Perfect Webinar is a five-step framework for a webinar that sells any product to a cold audience in under 90 minutes.
1. **Share how you learned it or earned it**: tell the story of the pain, money, time, and testing behind it, and credit the "giants" you learned pieces from. This is the value pre-frame.
2. **Share the strategy (the *what*)**: give the outline or table of contents of the steps, doodled if possible. Strategy is the overall plan and is slow to change.
3. **Teach the tactics (the *how*)**: the step-by-step actions. Use the "Day 1–30 reset" lens: *If I lost [the result], kept only my frameworks, and started from zero with no advantages, what would I do from day 1 to day 30 to get it back?*
4. **Show how it works for others**: case studies, testimonials, and examples from people like them.
- When to use: every piece of teaching content, including posts, videos, podcasts, webinars, chapters, workshops, and courses.
- Why it works / failure mode: if you open with tactics, people treat your "pearl" as worthless ("pearls before swine"). Knowing the cost of earning it lets them see they are saving that pain themselves. Showing results for others defeats the objection that "it only worked because you're special."

**Embedded frameworks (scalable depth)**: any step can contain its own framework. You can rerun steps 1–4 inside each step, which is how the same framework fits a 2-minute YouTube video, a 2-hour webinar, or a 2-day event. For example, Section 1 (become expert → new opportunity → future-based cause) contains Finding Your Voice, which contains framework-building.

**Strategy vs. Tactics** (Farnam Street distinction): strategy is the overarching plan and is hard to turn, like an aircraft carrier. Tactics are the specific actions that carry out the strategy.

## Key Concepts
- **Framework as savior**: when you're interrupted or lose your place, go back to the map.
- **Learned it or earned it**: knowledge you acquired (learned) or experience you paid for (earned). Either one pre-frames value.
- **Pre-frame**: context set before the content that sets how much it's worth.
- **Crediting the giants**: naming your sources raises your status and builds relationships instead of lowering either.
- **Day 1–30 lens**: a way to strip tactics down to what a beginner can actually follow.
- **Embedded framework**: a framework nested inside a step of a bigger framework.
- **Framework packaging**: the same framework can be a post, video, episode, lead magnet, chapter, course, membership, coaching, or mastermind (developed in b2-ch05).

## Mental Models
- Think of the framework as the table of contents and the tactics as the chapters.
- Use the learned/earned story whenever the audience is likely to underrate what you're about to give.
- Use embedded frameworks to expand or compress to fit the time available without changing the core.
- Think of proof from others as removing your "unfair advantage" from their view.

## Anti-patterns
- **Jumping straight to tactics**: glazed eyes and a pearl handed back. Nobody values what they didn't see you pay for.
- **Hiding your sources**: looks like idea theft and costs you mentor relationships.
- **Teaching only your own results**: prospects conclude you have special talents they lack.
- **Different content for each format**: wasted effort. Use one framework at different depths.

## Worked Example
**Perfect Webinar taught with the framework.** Introduce: "The Perfect Webinar — my five-step framework for a webinar that sells any product to a cold audience in under 90 minutes." (1) Earned story: years of stage presentations tested, tweaked, and refined. (2) Strategy outline: grab attention and build rapport → origin story of how you learned or earned the new opportunity → break and rebuild false belief patterns with three core stories (vehicle, internal, external) → the stack to position the offer → closing techniques to raise close rates. (3) Tactics: the details of each step, each of which may be its own framework. (4) Others: case studies of students' webinars.

A related anecdote: Brunson handed over a "pearl," got a shrug, spent about 15 minutes telling how he earned it, then re-explained the identical concept, and this time the room got it.

## Key Takeaways
1. Open every teaching unit with the framework's name and "my N-step system for [result]" description.
2. Before any strategy, tell the learned-or-earned story and credit your sources.
3. Show the strategy as a simple outline or doodle, then teach the tactics step by step.
4. Write the tactics through the "lost everything, 30 days to rebuild" lens so a beginner can follow them.
5. Start collecting case studies from the first person you apply the framework to, and end each teaching with them.
6. Build embedded frameworks so you can scale from 2 minutes to 2 days.

## Connects To
b2-ch01 (framework building and the free-service phase that produces proof), b2-ch05 (packaging frameworks into offers), b2-ch07 (Epiphany Bridge / learned-or-earned stories), b2-ch10 (vehicle framework story), b2-ch11 (Perfect Webinar framework), b1-ch22 (perfect webinar script).
