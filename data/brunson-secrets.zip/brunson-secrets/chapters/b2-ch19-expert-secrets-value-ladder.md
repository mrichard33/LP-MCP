# Expert Secrets — Secret 19: Plugging Expert Secrets into Your Value Ladder

## Core Idea
The customer is the hero and you are the guide. Your stories, frameworks, and Perfect Webinar variants plug into every rung of the value ladder and every funnel type from Dotcom Secrets: hooks in ads, epiphany bridge stories in lead magnets, five-minute webinars in unboxing funnels, full webinars in VSL, auto-webinar and application funnels, and a "sideways" Perfect Webinar in product launches and email.

## Frameworks Introduced
**Hook Sources List**: pull ad hooks from your epiphany bridge stories, frameworks, the red oceans you throw rocks at, your new opportunity, your future-based cause, platform, identity shifts, manifesto, milestone awards, offers, and presentations.

**Three Favorite Ad Types**:
1. *Epiphany bridge story ads*: backstory → journey → new opportunity → framework (the thing offered) → achievement → CTA to get the framework.
2. *Five-minute perfect webinar ads*: build one for every product, and use it as the ad and the landing-page video.
3. *Perfect webinar shortcut ads*: launch new products, then keep buying ads while profitable.

**Epiphany Email Follow-Up (Perfect Webinar as a Soap Opera Sequence)**: split the four core stories plus the stack across emails (text or video links). Each email ends with a hook into the next.
- How: emails 1–5 are emotion (presentation; the stack lands in email 5), then 2–4 emails of logic and then fear to close the campaign.
- Why it works / failure mode: the story structure matters more than the medium, so you can sell without anyone attending a presentation. It fails if the emails don't cliffhang, because people drop out between "episodes."

**Funnel-by-funnel placement (low to high on the value ladder)**:
- *Lead funnels*: the epiphany bridge story told in the ad or on the page (backstory, journey, new opportunity, framework offered as the lead magnet, achievement).
- *Unboxing funnels* (free book + shipping, $39 items): the five-minute perfect webinar as ad and sales video.
- *VSL funnels*: a recorded Perfect Webinar on a sales page, either the full 90-minute recording or a 30-minute shortcut.
- *Live and automated webinar funnels*: the full Perfect Webinar. Auto versions put the recording on a funnel page instead of GoToWebinar/Zoom.
- *Phone/application funnels* (top of ladder): a basic Perfect Webinar whose CTA goes to an application form instead of an order form, followed by the Dotcom Secrets phone scripts.
- *Product launch funnels* (Jeff Walker's "sideways sales letter" = a sideways Perfect Webinar): video 1 = origin story + Secret 1; video 2 = Secret 2; video 3 = Secret 3; video 4 = stack and closes.

## Key Concepts
- **Guide vs. hero**: you are Yoda, the customer is Luke. The presentation is your story; the funnel is their journey.
- **Calling**: the first offer (lead magnet) where the prospect commits to the journey. The commitment matters more than the deliverable.
- **Soap Opera Sequence (SOS)**: onboarding emails that each end on a hook (Andre Chaperon's concept).
- **Sideways Perfect Webinar**: the Perfect Webinar split across a video series.
- **Emotion → logic → fear**: the Dotcom/Traffic email arc. The Perfect Webinar fills the emotion phase.
- **Application CTA**: high-ticket webinars end with "apply" instead of "buy."

## Mental Models
- Use presentation length ∝ price: 5 min for low-ticket, 30 min for VSL/mid, 90 min for webinar/high-ticket/application.
- Think of every piece of marketing as one fragment of the Perfect Webinar (story, secret, or stack) delivered in a different container.
- Think of Dotcom Secrets as the framework, Expert Secrets as the fire, and Traffic Secrets as the fuel.

## Anti-patterns
- **Full 90-minute pitch for a free-plus-shipping or $39 offer**: it's overkill and people won't watch.
- **Emails without cliffhangers**: they break the soap-opera pull.
- **Treating ads as separate from your story**: your best hooks already exist in your stories and frameworks.

## Worked Example
Perfect Webinar email sequence: Email 1 origin story (Big Domino) → Email 2 Secret 1 vehicle story → Email 3 Secret 2 internal story → Email 4 Secret 3 external story → Email 5 the stack (last emotional email) → Emails 6–9 logic (value, price justification), then fear (deadline, cart closing). Each ends by teasing the next email. The same four pieces become a four-video product launch.

Book close (end of range): Acknowledgements credit Perry Belcher (new opportunities, status), Dan Kennedy, Michael Hauge (story structure), Blair Warren (persuasion), Jason Fladlien (breaking and rebuilding false beliefs), and Armand Morin (the stack). The conclusion (Liz Benny's story) frames the guide role as the reward.

## Key Takeaways
1. Mine your stories, frameworks, and cause for ad hooks. Run epiphany-story, five-minute, and shortcut ads.
2. Match format to rung: story (lead), 5-min (unboxing), 30/90-min (VSL/webinar), webinar → application (high-ticket).
3. Turn your Perfect Webinar into a 5-email emotional soap-opera sequence plus 2–4 logic/fear emails.
4. Run product launches as a sideways Perfect Webinar: 3 content videos (origin + 3 secrets) and a stack video.
5. Keep yourself in the guide role. Every funnel is the customer's hero journey.

## Connects To
b1-ch03 (value ladder), b1-ch15 (webinar funnels), b1-ch22 (Perfect Webinar script), b1 (soap opera sequence, lead/unboxing/VSL/application/product launch funnels, phone scripts), b2-ch10 (four core stories), b2-ch15 (guide role intro), b2-ch16 (live webinar funnel), b2-ch17 (shortcut), b2-ch18 (five-minute version), b3 (hooks, dream customer, ads, Dream 100).
