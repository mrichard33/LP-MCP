# Traffic Secrets — Secret 14: After the Slaps and the Snaps

## Core Idea
Platforms will die, get regulated, or change overnight (the "Google Slap" or the "Zuck snap"). The durable skill is running the same six-step Fill Your Funnel framework on any new platform. Brunson shows this by applying it to podcasting (Apple Podcasts).

## Frameworks Introduced

**Fill Your Funnel framework as a universal new-platform blueprint**
1. Understand the history and the goal.
2. Find your Dream 100 on this platform.
3. Identify the publishing strategy and create your publishing plan.
4. Work your way in.
5. Buy your way in.
6. Fill your funnel.
- When to use: any new or emerging platform (the book names Twitter, Snapchat, LinkedIn, Twitch, TikTok, and Pinterest as candidates), or after a slap destroys your current channel.
- Why it works / failure mode: tactics are "fish" and the framework is "learning to fish." Brunson deliberately covered only Facebook, Instagram, Google, and YouTube so readers would copy the pattern rather than a snapshot of tactics.

**Podcast application of the framework**
- Goal and history: podcasting is the hardest place to grow subscribers but produces the most valuable ones. You get their sole attention (driving, gym, bed) and can tell stories and break false beliefs. Push new list members to subscribe to your podcast early.
- Dream 100: search Apple Podcasts, which lists nearly every show and shows the top 200 per category. Also search keywords to find legacy shows with big audiences that no longer rank. Turn peer podcasters into a "strategic board" and swap what's working.
- **Apple ranking factors (as of 2020)**: #1 new subscribers, which outweighs the rest, then downloads, then new reviews/comments. Run contests and giveaways and ask for subscriptions in every episode.
- Publishing: choose a format you can sustain (Brunson's original show came from his 10-minute daily drive, 3 episodes a week, recorded on a phone; interview hosts need a home studio). Publish on the same days every week.
- Work your way in: be a guest on the Dream 100 shows. When the host asks "how can people learn more about you?", send them to subscribe to your show, or to your funnel.
- Buy your way in: buy ads, and whole promotional episodes, on shows your dream customers listen to.
- Fill your funnel: for a book, webinar, or funnel launch, "hit the podcast circuit" with a funnel URL, and buy recurring ads on the shows that converted best.

## Key Concepts
- **Slaps and snaps**: sudden platform algorithm changes (Google slap; Facebook "Zuck snap").
- **Compounding back catalog**: each new podcast listener binges old episodes, so each show promotes the ones before it.
- **Six-show ceiling**: the average listener subscribes to about six shows and adds new ones mainly through a friend's or another podcast's recommendation.
- **The magic question**: a host's "where can people learn more?", your built-in CTA slot.
- **Podcast media kit / ad agencies**: shows sell ads in-house (with demographics and downloads) or through agencies that represent many shows.
- **Strategic board**: peer creators on the same platform who share algorithm observations.

## Mental Models
- Think of any platform as a temporary container for a permanent process. Learn the process.
- Use the listener's "six-show ceiling" to explain why growth comes from other podcasts rather than from the directory. Recruit where podcast listeners already are.
- Treat your first platform's playbook as a template to re-derive on the next platform, not to copy blindly.

## Anti-patterns
- **Learning tactics without the framework**: you are stranded when the platform changes.
- **Waiting for organic podcast discovery**: listeners rarely browse the directory, which is why most podcasters quit.
- **Choosing a format you can't sustain**: consistency drives the compounding effect.

## Worked Example
**Jordan Harbinger rebuild**: he lost *The Art of Charm* (4M+ monthly downloads) in a partner dispute. He then toured the guest circuit (including Andrew Warner's Mixergy) and at each "how to follow you" moment pointed listeners to *The Jordan Harbinger Show*, which passed 3M+ downloads within months. He also bought a promo episode on *Business Wars*, which played highlights of his show and asked listeners to subscribe. **Brunson's ad buys**: test ads on John Lee Dumas's *Entrepreneur on Fire* converted well enough that he bought a full year, and he re-bought on the shows where his interviews had driven the most sales.

## Key Takeaways
1. When any platform appears or changes, run the six steps in order before you spend.
2. In podcasting, optimize for new subscribers above all, and ask for the subscription every episode.
3. Grow a show by guesting on your Dream 100 podcasts and using the "learn more" moment as your CTA.
4. Buy ads or promo swaps on shows your dream customers listen to. Test first, then buy long-term.
5. For every launch, book a podcast circuit that points to a funnel URL.

## Connects To
b3-ch02 (Dream 100), b3-ch04 (work/buy your way in), b3-ch05 (traffic you own), b3-ch07 (the "show" from Secret 7, infiltrating the Dream 100), b3-ch09 (the framework's origin in the paid/organic section), b3-ch11–b3-ch13 (the framework applied to each platform), b3-ch15 (Conversation Domination), b3-ch17 (other people's distribution).
