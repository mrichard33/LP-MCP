# Expert Secrets — Secret 11: The Perfect Webinar Framework

## Core Idea
Teaching great content does not sell; identifying, breaking, and rebuilding false belief patterns does. The Perfect Webinar is a battle-tested sales presentation (stage, webinar, VSL, email, Facebook Live) built on three phases: the Big Domino, the Three Secrets, and the Stack and Closes.

## Frameworks Introduced
**The Perfect Webinar (three phases)**: (1) Big Domino + origin story, (2) Three Secrets (vehicle, internal, external false beliefs), (3) Stack and Closes.
- When to use: any one-to-many sales presentation for an offer that needs belief change.
- How: Build the Big Domino statement first; write one epiphany bridge origin story; pick the core false belief in each of the three categories and give each a secret with story + strategy + case study; finish with the stack slide and specific closes.
- Why it works: every part attacks a single belief from a different angle, so the buyer needs to accept only one thing. Failure mode: "teacher mode", where handing over the how satisfies curiosity and removes the reason to buy.

**The Time Ratio (1/6 : 1/6 : 1/6 : 1/6 : 2/6)**: 90-minute version = 15 min intro/Big Domino/origin story; 15 min Secret 1 (vehicle); 15 min Secret 2 (internal); 15 min Secret 3 (external); 30 min stack and close. 30-minute version = 5/5/5/5/10.
- When to use: when planning any presentation length.
- How: keep the ratios and scale story length. If you have extra time, add more short epiphany bridge stories that break more false beliefs.

**Sell vs. Teach content rule**: A course goes story, strategy, tactics, social proof. A sales presentation goes story, strategy, case study, with **no tactics**. Teach the *what*, not the *how*.
- How: for each secret, give the framework's named steps (strategy) and proof. Save the step-level mechanics for the paid product.

## Key Concepts
- **Big Domino**: the single belief that, once accepted, makes every other objection irrelevant.
- **Three Secrets**: the content section. It adds no new beliefs; it tears down the three false beliefs propping up the Big Domino.
- **Vehicle false belief**: doubt that the new opportunity/framework works (or works for them).
- **Internal false belief**: doubt in their own ability to execute.
- **External false belief**: doubt caused by outside forces (time, money, economy, traffic).
- **The Stack**: the offer presented element by element on a cumulative value slide.
- **Closes**: scripted persuasion moves woven into the stack section.
- **Teacher mode**: the most common failure, where the presenter over-delivers tactics and gets no sales.

## Mental Models
- Think of the presentation as one domino attacked from four angles (origin story + three secrets), not a list of claims.
- Use the audience's desire for the *how* as the thing they pay for.
- Treat the script as channel-agnostic: the same belief sequence works on stage, webinar, VSL, email, or live video.

## Anti-patterns
- **Out-teaching everyone**: packing in content makes people feel "complete" and they don't buy (Brunson's first talk sold nothing).
- **Asking for multiple beliefs**: each extra belief reduces conversion.
- **Learning from good speakers instead of good sellers**: stage polish is not selling skill.
- **Teaching tactics in the content section**: this kills sales and doesn't create change either.

## Worked Example
90-minute Funnel Hacks timeline: 0–15 min welcome, title, Big Domino ("funnels are the key, only through ClickFunnels"), potato-gun origin story → 15–30 Secret 1 Funnel Hacking (vehicle) → 30–45 Secret 2 Funnel Cloning (internal: "I'm not technical") → 45–60 Secret 3 Traffic Hack (external: "I can't get traffic") → 60–90 stack, closes, Q&A. Stage results that inspired it: about $60K and $100K+ in about 90 minutes from peers, and later $250K+ per 90-minute talk for Brunson.

## Key Takeaways
1. Write your Big Domino statement before building any slide.
2. Lock in the 1/6-per-section, 2/6-for-close ratio and scale stories to fit the time.
3. For each secret, deliver story, strategy, and case study. Never tactics.
4. Pick exactly one core false belief per category (vehicle, internal, external).
5. Test the script live repeatedly and tweak based on where buyers move or stall.

## Connects To
b1-ch22 (Perfect Webinar script), b1-ch15 (webinar funnels), b2-ch04 (new opportunity), b2-ch05 (offer/stack slide), b2-ch09 (epiphany bridge script), b2-ch10 (four core stories/story inventory), b2-ch12, b2-ch13, b2-ch14, b2-ch15 (each phase in depth), b2-ch16 (testing live).
