# Expert Secrets — Secret 15: Trial Closes

## Core Idea
If the first yes you ask for is the request for money, you won't get a table rush. Ted Thomas ("the Pied Piper of Selling") gets hundreds of small yeses throughout a talk so that the buying yes is just one more. Adding recorded trial closes to an existing automated webinar raised earnings from $9.45 to $16.50 per registrant. The chapter also gives 16 mini-closes to weave into the stack, and shows how to turn your own epiphany bridge stories into closes.

## Frameworks Introduced
**Trial Closes**: short questions whose only possible answer is yes, used constantly ("Is this making sense?", "Are you getting this?", "Can you imagine this happening to you?", "Isn't that cool?", "Am I right?", "Can you see yourself doing this?", "Would you like to be our next case study?", "You've noticed this too, right?").
- When to use: throughout, and most of all right after every case study or success story. Pause and drop about half a dozen.
- How: keep cue cards at your desk, and retrofit them into existing recordings.
- Why it works / failure mode: repeated agreement creates momentum, so the buy decision feels consistent with everything they've already said yes to. The failure mode is moving straight from a story to the next point, which wastes the emotional peak.

**The 16 Closes** (many from Jason Fladlien's Webinar Pitch Secrets 2.0). Pick a handful that fit and use one to three before introducing each new stack element:
1. **Money Is Good**: money is only a tool for exchange; if the results are worth more than the money, buy now (and the guarantee covers doubt).
2. **Disposable Income**: they already spend leftover income on short-lived pleasures; redirect it to growth.
3. **Money Replenishes**: money comes back every paycheck, but time doesn't. Justifies dipping into savings or credit.
4. **Break Old Habits**: leave now and by tomorrow you'll be back in your routine; lasting change needs repeated exposure.
5. **Information Alone**: information isn't enough; they need coaching and accountability ("DIY success ≈ 0%, with me ≈ X%").
6. **Money or Excuses**: people are good at one or the other; choose now.
7. **Your Two Choices (pricing)**: cheap and thin, or priced higher and fully stacked for their success.
8. **Two Choices (action)**: do nothing and get nothing, or take a risk-free leap backed by the guarantee.
9. **Us vs. Them**: doers vs. dabblers.
10. **The Handhold**: walk through the checkout step by step (open browser, go to URL, click, fill form, support link).
11. **Say Goodbye**: list the pains that disappear after buying.
12. **Now and Later**: your before (struggle) vs. after, then "imagine that for you."
13. **Only Excuses**: name the top two or three objections and defuse each by pointing to the module that solves it. If price is the objection, make it an investment decision.
14. **Reluctant Hero**: "I'm no one special; I struggled with X too."
15. **If You Only Got**: "If you only got X it would be worth it, but you also get Y, Z..."
16. **Close Close**: the final push repeated during Q&A: "If you're on the fence, go to [URL] now; 100% money-back guarantee."

**Custom Closes from Your Story Inventory**: the purest close is an epiphany bridge story that breaks a false belief about buying.
- How: take an unused story from your inventory and run it through backstory → journey → new opportunity → framework (the lesson) → achievement.

## Key Concepts
- **Trial close**: a small yes-question that builds agreement momentum.
- **Nodding test**: live, a room of nodding heads (waves in the ocean) predicts a table rush.
- **Mini-close**: a short scripted argument that addresses one reason not to buy.
- **Investing vs. buying**: people may lack money to *buy* but have money to *invest* in something that returns more.
- **Close cadence**: two or three closes between stack elements, chosen to flow naturally.
- **Guide role (Section Four preview)**: the customer is the hero and you are the guide (Yoda to their Luke). Funnels are *their* journey; the presentation is *your* story.

## Mental Models
- Think of yes as a habit you train over 60+ minutes, not a single request at the end.
- Use trial closes as the pause after every story. Let the proof sink in before moving on.
- Treat every close as a tiny epiphany bridge story aimed at a buying objection.

## Anti-patterns
- **First yes = money yes**: the audience has built no momentum and stays seated.
- **Using all 16 closes**: this feels scripted. Choose the few that support your argument.
- **Rushing past case studies**: you lose the emotional peak where trial closes work best.

## Worked Example
Custom close "Investing vs. Buying": *Backstory*: first week of college wrestling. *Journey*: Olympic champion and UFC 9 winner Mark Schultz knocks on the dorm door. *New opportunity*: he hands over his highlight tape and asks for Russell's wallet, then empties it. *Framework*: if he'd given the tape for free Russell would never watch it; because he paid, he will. *Achievement*: Russell watched it repeatedly and became a better wrestler. Use it before any investment ask. Trial-close run after a case study: "Did you hear that? Isn't that amazing? Can you imagine your life if that happened to you? Are you getting this?"

## Key Takeaways
1. Get small yeses continuously. Put cue cards where you present.
2. Pause after every case study and stack four to six trial closes.
3. Retrofit trial closes into existing recorded webinars. It's a cheap EPR lift (+75% in Brunson's test).
4. Pick three to six of the 16 closes and place one to three before each new stack element.
5. Build signature closes from unused epiphany bridge stories that target buying objections.

## Connects To
b2-ch09 (epiphany bridge script), b2-ch10 (story inventory), b2-ch14 (stack and close slides), b2-ch16 (Q&A close-close, live testing), b1-ch22 (Perfect Webinar script), b2-ch19 (guide role across the value ladder), b3 (dream customer and hooks: Section Four points to Traffic Secrets).
