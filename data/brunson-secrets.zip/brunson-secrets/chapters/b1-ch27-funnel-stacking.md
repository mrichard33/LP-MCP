# Dotcom Secrets Secret 27: Funnel Stacking

## Core Idea
Master fundamentals, not flash: build one funnel per value-ladder step and connect them so the end of each funnel is the entrance to the next. About 95% of Russell's revenue comes from three funnels (book, webinar, high-ticket). Stacking lets fast movers ascend immediately and slow movers re-engage later—raising revenue per customer so you can outspend competitors. But don't wait for the full stack: get funnel one to $1M (Two Comma Club) before building funnel two.

## Frameworks Introduced

**Funnel Stacking**: place the first step of your next funnel on the last page (thank-you, offer wall, special offer) of the previous funnel, and promote it through follow-up funnels.
- When to use: Once you have a working funnel and have built the next one on your value ladder.
- How:
  1. Choose one funnel per value-ladder step (not all 10 core funnels).
  2. Identify each funnel's final page (thank-you, results page, special-offer page, offer wall, or a post-challenge group post).
  3. Insert the next funnel's entry step there.
  4. Also email existing customers of funnel one about funnel two.
  5. Order doesn't have to be fixed; people can skip steps.
- Why it works: Every funnel deepens the relationship; buyers are hottest right after buying. Without a next offer, fast movers find a solution elsewhere.
- Failure mode: Building the entire stack before launching anything—money and customers are available now.

**Stacking Pairings (examples by funnel type)**:
- **Front-end lead funnels**: lead squeeze → challenge (Marketing Secrets Blackbook → One Funnel Away Challenge); survey → unboxing (ClickFunnels homepage survey → 14-day trial); summit → challenge (30 Days summit → One Funnel Away).
- **Unboxing funnels**: book → webinar (Expert Secrets book → Funnel Builder Secrets webinar); cart → book (Perfect Webinar Secrets → Dotcom Secrets book); challenge → webinar (One Funnel Away completers → "next mission" webinar in the Facebook group).
- **Presentation funnels**: VSL → application (10X Secrets → Inner Circle); webinar → application (webinar thank-you → CF Certified); product launch → application (Funnel Hacking workshop → Inner Circle).

**Two Comma Club Gate**: build the next funnel only after the current one has done $1M.
- How: Webinar hits $1M → create high-ticket coaching, promote to webinar registrants, add to thank-you page. Or: book sells 1,000–5,000 copies → create webinar, promote to buyers, stack at end of book funnel.

## Key Concepts
- **Funnel stacking** — linking funnels so customers ascend the value ladder.
- **Fundamentals over flash** — few, simple funnels beat many complex ones.
- **Ascension point** — the final page of a funnel where the next begins.
- **Fast movers vs. slow movers** — some buy $25,000 within a week of a book; some wait 3–4 years.
- **Outspend competitors** — higher value per customer funds more ad spend.
- **Two Comma Club** — $1M in a single funnel.
- **Follow-up stacking** — promoting the next funnel via email, not just pages.

## Mental Models
- Think of each thank-you page as the front door of the next funnel.
- Use one funnel per ladder step; three funnels can carry 95% of revenue.
- Think "launch one, perfect it, then stack" rather than "build all, then launch."

## Anti-patterns
- **Building all 10 funnels**: dilutes focus; most complex funnel businesses make no money.
- **Dead-end thank-you pages**: loses fast movers to competitors.
- **Waiting for a complete stack to launch**: delays revenue and service.
- **Forcing a rigid path**: customers move at their own speed.

## Worked Example
Russell's stack: lead squeeze (free Marketing Secrets Blackbook) → thank-you page pitches the One Funnel Away Challenge (challenge funnel) → challenge graduates invited in the Facebook group to a webinar selling the current offer → webinar thank-you page pushes an application funnel for high-ticket coaching. Parallel: free-plus-shipping Expert Secrets book → thank-you page → Funnel Builder Secrets webinar.

## Key Takeaways
1. Build one funnel per value-ladder step; favor book, webinar, and high-ticket.
2. Put the next funnel's entry on the previous funnel's last page and in follow-up emails.
3. Offer fast movers the next step immediately; keep slow movers in follow-up.
4. Scale a funnel to $1M before building the next.
5. Launch now—add stacks as each new funnel comes online.

## Connects To
b1-ch03 (value ladder), b1-ch07 (follow-up funnels), b1-ch08 through b1-ch17 (the funnel types), b1-ch26 (ClickFunnels build), b1-ch28 (funnel audibles; 12-step process), b2-ch19 (Expert Secrets value ladder), b3-ch05 (traffic you own), b3-ch06 (follow-up funnels).
