# Expert Secrets — Secret 1: Finding Your Voice

## Core Idea
Every mass movement has three elements: a leader, a new opportunity, and a future-based cause. Secret 1 builds the first. You grow from Attractive Character into expert/guide by moving through five phases: spark, research, framework-building, free service, then leading. After that you find your voice by publishing consistently, testing your material, and persuading from a polarizing position.

## Frameworks Introduced
**The Movement Formula (Section 1 thesis)**: "The expert offers someone a new opportunity and then guides them to a result with a future-based cause." The three pieces are Charismatic Leader (Attractive Character raised to expert/guide), New Opportunity, and Future-Based Cause.
- When to use: to audit any business or offer for movement potential. Check whether each of the three elements is present.
- How: work through Secret 1 (become the expert), then Secret 4 (new opportunity), then Secret 6 (future-based cause), and weave all three into your funnels and value ladder.
- Why it works / failure mode: products are tools, and the movement is what changes people. Sell only the product and you compete as a commodity. You can find this pattern in both positive movements (Apple, religions) and negative ones (cults, Nazism), so it is a pattern and not a moral guarantee.

**The Five Phases to Becoming an Expert**:
1. **The Dreamer (spark)**: experiment widely, notice what sparks interest, engage deeply. When interest turns into fascination, pursue mastery. Fascination plus mastery equals passion. Look for your superpower in what comes easily to you, since you will tend to undervalue it.
2. **The Reporter**: keep your *teachability index* high. Learn from many sources and points of view, then form your own view (Howard Berg's approach: read a dozen books on one topic). Three vehicles: live events (hear speakers, network, collect unmet struggles), your own show or podcast (interview experts a few chapters ahead of you), and summit funnels.
3. **Building Your Own Frameworks** (three steps): (1) *Framework hypothesis*: coach "past you" by brain-dumping every topic you would teach your beginner self, then order it into a table-of-contents outline. (2) *Human guinea pig*: test it on yourself and fix the holes. (3) *Proprietary name + description* in the form: "[Name]: my [N]-step [framework/system/process] for [result]."
4. **Work for Free (serve future dream clients)**: prove the framework on other people through a beta group or free service, and collect the testimonial. This is the phase people most often skip.
5. **Becoming the Expert**: your results are your certification. You only need to be one chapter ahead of the people you help.
- Why it works / failure mode: the shift from growth to contribution drives continued growth, because teaching forces you to see the pattern. The failure is jumping from phase 2 to selling without proof, or waiting for credentials.

**Product → Framework reframe**: ask what framework someone must follow to get the result your product delivers. Your product then becomes one step inside it. Dentist example: daily brushing, toothpaste, whitening strips, tongue scraper, supplements, twice-yearly checkups. Cleaning is one piece, and the framework sets you apart from other dentists.

**Finding-Your-Voice Steps (leadership)**:
1. **Publish daily for at least a year** on the platform that suits you (blog/vlog/podcast). Aim to "endure long enough to get noticed" and don't watch your stats early on.
2. **Document, don't create** (Gary Vaynerchuk): share the journey toward the big result you're obsessed with. Frame your show around one big question.
3. **Test your materials**: this is the comedian's 10-jokes method. Keep what lands and replace what bombs, week after week.
4. **Be prolific**, meaning abundantly inventive, and place your message in the **Prolific Zone** on the prolific index: between the Mainstream (free, boring, no money) and the Crazy Zone (can't move the masses). Polarity attracts true fans and will upset some people.
5. **Master persuasion** with Blair Warren's One-Sentence Persuasion: people will do anything for those who *encourage their dreams, justify their failures, allay their fears, confirm their suspicions, and help them throw rocks at their enemies*.
6. **Care, a lot**: charge for your help. Those who pay pay attention, and barriers protect your time so you can serve more people.

## Key Concepts
- **Attractive Character → Expert/Guide**: the Attractive Character draws people in at the front of the value ladder, and the expert leads them up it.
- **Teachability index**: how open you are to learning right now. It collapses once people feel they "know" a topic.
- **Framework hypothesis**: your first-draft framework, assembled from other people's frameworks and your own epiphanies.
- **One chapter ahead**: the only qualification needed to guide someone.
- **Prolific index / Prolific Zone**: the spectrum of Mainstream, Prolific Zone, and Crazy Zone. Money sits in the polar-but-plausible middle band.
- **Polarity**: taking positions that create true fans and a few loud detractors.
- **Document, don't create**: publish the process instead of inventing an authoritative persona.
- **Those who pay, pay attention**: price drives commitment and results.

## Mental Models
- Think of your framework as the map and your product as one tool at one stop on it.
- Use the "coach your past self" lens when you're drafting any curriculum or table of contents.
- Use the Prolific Zone test when a message feels either "obvious" (mainstream) or "fringe" (crazy).
- Think of your early episodes as rehearsal while nobody is watching yet. Your voice shows up around episode 40–50.

## Anti-patterns
- **Waiting for certification**: delays service indefinitely. Results are the credential.
- **Regurgitating others' ideas**: without guinea-pig testing, you have nothing proprietary.
- **Skipping free beta service**: you launch with no proof that the framework transfers to other people.
- **Checking download stats early**: kills consistency before the audience can find you.
- **Staying neutral / mainstream**: you'll be ignored. Going full crazy-zone: you can't be monetized at scale.
- **Being endlessly accessible for free**: you end up serving fewer people, less well.

## Worked Example
**Inner Circle launch via free service.** Brunson wanted to sell a $50K/yr coaching program without a coaching track record. (1) He picked a dream client (Drew Canole, FitLife.tv). (2) He offered a free day of help "to see if I can help," with no catch. (3) He spent about a month fixing their unprofitable funnels and building the Organifi launch funnel, which went on to earn tens of millions per year. (4) Drew recorded an unsolicited transformation video. (5) That video went into a funnel, and the program filled its cap of 100 members with a waiting list. The lesson is to lead with "how can I serve" and collect third-party proof before selling.

## Key Takeaways
1. Write your framework hypothesis by brain-dumping everything "beginner you" needed, then order it into a TOC.
2. Test it on yourself first, then on a free beta group, and capture testimonials.
3. Name it: "[Name]: my N-step system for [result]."
4. Pick one platform and publish daily for 12 months. Document your pursuit of one big question.
5. Place your message in the Prolific Zone. Accept the haters as the cost of true fans.
6. Build messaging on the five persuasion levers, especially justifying failures and throwing rocks at a common enemy.
7. Charge for your help. Price is a commitment device and a sign of care.

## Connects To
b1-ch04 (Attractive Character), b1-ch03 (value ladder), b2-ch02 (teaching frameworks), b2-ch04 (new opportunity), b2-ch06 (future-based cause), b2-ch07 (Epiphany Bridge / learned-or-earned stories), b3 (Traffic Secrets: publishing your show, Dream 100 interviews).
