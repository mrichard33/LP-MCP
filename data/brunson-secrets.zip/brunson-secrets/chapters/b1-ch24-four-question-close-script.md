# Dotcom Secrets Secret 24: Four Question Close Script

## Core Idea
When the expert personally takes the sales call for a $2,000–$8,000+ offer, use four questions (really four phases with follow-ups) that tie back to the application: desired future, obstacles, untapped resources, and "do you want my help?" The prospect describes their goals, admits the gap, imagines the upside, and asks to be helped. Built on the Dan Sullivan Question, refined via Perry Belcher and Greg Sasser.

## Frameworks Introduced

**Four Question Close**:
- When to use: Expert-led calls after an application funnel (b1-ch17), high-ticket offers roughly $2,000–$8,000 and beyond. An assistant books a 30-minute call.
- How:
  0. **Frame the call** — skip small talk. "Here's how this works: I'll ask four questions; depending on your answers and how we get along, we'll decide whether to move forward. Fair?" Get the micro-yes; no yes, end the call.
  1. **Question 1 — Desired future (Dan Sullivan Question)**: imagine we start today and meet in a coffee shop a year from now—what must have happened personally and professionally for you to be happy and feel this was your best decision? Get external goals, then dig with "why?" until an internal driver appears: **respect, inclusion, or purpose**. If they can't articulate a goal, don't take them.
  2. **Question 2 — Obstacles**: "You clearly know what you want—why don't you have it yet?" Listen for *I*-statements ("I don't know how") = coachable. Blaming spouse, past programs, or circumstances = don't accept.
  3. **Question 3 — Resources**: what talents, connections, skills, or resources aren't being fully used? Keep asking "what else?" until they run dry. Then **review**: you want [goal] because [reason]; blocked by [obstacles]; you have [resources]. Ask how much more they'd make/lose/gain if obstacles were removed and resources leveraged—let them state the upside.
  4. **Question 4 — The ask**: "Do you want me to help you achieve your goals?" Then stay silent until they answer. On yes: state fee and what's included; offer to transfer to an assistant for payment.
- Why it works: The prospect articulates goal, gap, and upside in their own words, so the offer is their conclusion, not your claim.
- Failure mode: Letting the prospect run the call with small talk; or accepting a blamer who will never be satisfied.

**Money objection handling**: at step 4 the usual remaining objection is money—help them find it or offer a payment plan.

## Key Concepts
- **Micro-commitment** — the first small yes that sets ground rules.
- **External vs. internal desires** — surface goals vs. the values underneath.
- **Respect, inclusion, purpose** — the three universal internal desires; stop digging when you hear one.
- **"I" language** — signal of personal responsibility and coachability.
- **Blame language** — disqualifier.
- **Review/summary** — restating goal, obstacles, resources before the ask.
- **Silence after the ask** — the next person to speak is the prospect.

## Mental Models
- Think of the call as a qualification interview you control, not a pitch.
- Use "why?" repeatedly until you hit respect, inclusion, or purpose.
- Think "responsibility-takers are clients; blamers are refunds."

## Anti-patterns
- **Opening with small talk**: invites rambling and cedes control.
- **Taking clients who can't define success**: they'll never be happy.
- **Accepting blamers**: they won't own the work.
- **Talking after the final question**: undermines the close.

## Worked Example (fill-in template)
- Frame: "Thanks for jumping on. I'll ask four questions; based on your answers and fit, we'll decide if we move forward. Fair enough?"
- Q1: "If we started today and met a year from now, what would have to have happened for you to feel thrilled?" → "Why is [goal] important?" → "Why does that matter?" (until respect/inclusion/purpose).
- Q2: "Why don't you have that already? What's held you back?"
- Q3: "What skills, contacts, or resources aren't you fully using?" → "What else?"
- Review: "So you want [goal] because [reason]; [obstacle A/B] have held you back; and you have [resources]. If we removed those obstacles and used those resources, what would that be worth?"
- Q4: "Do you want me to help you get there?" (silence) → "Great. The investment is [fee]; that includes [deliverables]. I'll pass you to [assistant] to handle details—sound good?"

Example of digging: "$10,000 a month" → "why?" → to prove to family they're a good provider (respect). "Better school district" → childless couple hoping to keep hope of a family alive (purpose).

## Key Takeaways
1. Pre-qualify with an application and book a 30-minute call via an assistant.
2. Open by stating the four-question format and getting agreement.
3. Dig past surface goals until you hear respect, inclusion, or purpose.
4. Screen out blamers; accept "I don't know how."
5. Summarize, let them quantify the upside, ask once, and stay silent.

## Connects To
b1-ch17 (application funnels), b1-ch25 (Setter and Closer for teams), b1-ch16 (changing the selling environment), b2-ch15 (trial closes), b2-ch03 (three core markets/desires), b3-ch01 (dream customer).
