# DotCom Secret 3: The Value Ladder

## Core Idea
A business is a Value Ladder: a sequence of offers that rise in value and price. Customers who got value at one rung naturally want the next. The Value Ladder is your business plan. The sales funnel is how people move up it. Sketch every rung, but build and scale one funnel at a time.

## Frameworks Introduced

**Value Ladder**
- Formulation: plot value on the vertical axis and price on the horizontal. Each rung is a separate offer that serves the same mission. Bait or free at the bottom, then low-ticket, then mid-ticket, then high-ticket and continuity.
- When to use: when you start a company or take on a client (map it first), when a business "only sells a product," and when ads stop being profitable.
- How: (1) Write your VLMS (below). (2) Define the pinnacle offer, meaning what you would do if price were no object. (3) Add front-end bait that attracts the dream customer. (4) Fill the middle rungs (courses, events, programs). (5) Add continuity where you can. (6) Most businesses have only one or two rungs, so look for the missing front end and back end.
- Why it works / failure mode: people seek more value from sources that have already given them value (dating, then marriage). A cold pitch for the top rung fails because you haven't given value yet. The failure mode is spending months building every rung and never selling anything.

**Value Ladder Mission Statement (VLMS)**
- Template: "We help [who] to [result they want] through [your new opportunity]."
- Examples: ClickFunnels, "We help visionary entrepreneurs to grow their companies through sales funnels." A dentist, "We help families in our community to increase their confidence through creating a beautiful smile they are proud to share."
- Every rung must fulfill the same VLMS in a different way. The Martinos call the ladder their customer's "yellow brick road" to their goal.

**Funnel type by Value Ladder tier**
| Tier | Price | Funnel family |
|---|---|---|
| Bait / free | $0 | Lead funnels |
| Low-ticket | $1 to $100 | Unboxing funnels |
| Mid-ticket | $100 to $2,000 | Presentation funnels |
| High-ticket | $2,000+ | Phone / application funnels |

**One Funnel Focus rule**
- How: sketch the full ladder, then pick one rung, usually middle or back end (a presentation or phone funnel), because that price covers ad costs with profit. Work only that funnel until it reaches the Two Comma Club ($1M gross). Once customer demand builds, open the back end. When ads fatigue on the core offer, build a new front end to feed it.

## Key Concepts
- **Bait**: the first rung. A free or cheap offer that attracts the dream customer.
- **Ascension**: moving a customer to higher-value, higher-price rungs.
- **Continuity**: recurring weekly, monthly, or yearly billing until they cancel (the dentist rebooking your six-month cleaning).
- **Front end / back end**: entry offers that bring people in, and premium offers where most of the profit sits.
- **"$5,000 buyer lead"**: a customer who just bought your top offer is a lead for something higher.
- **Sales funnel**: the visual form of the ladder. The cloud of prospects enters at the bait, and a smaller percentage buys at each deeper step until the dream clients reach the bottom.
- **Two Comma Club**: $1M gross through a single funnel.
- **Kennedy's rule**: the business that can spend the most to acquire a customer wins.

## Mental Models
- Think of the Value Ladder as the business plan and the funnel as the delivery system for it.
- Use a deeper funnel (more rungs, upsells) when ad costs rise. Higher customer value means you can pay more to acquire each one.
- There is no top to the ladder. A percentage of buyers will always pay a premium for more access, so keep designing higher rungs.
- If a front end is boring (like a chiropractic adjustment), make it attractive, or the whole ladder starves.

## Anti-patterns
- **Pitching the top rung to strangers**: a $1M offer from someone who hasn't given value gets laughed off. The same offer to 1,000 warm event attendees got more than 50 hands.
- **Building every rung before selling**: you stall for months or years.
- **A dead end after one sale**: relationships end and willing buyers have nowhere to go (FitLife TV's real problem was not traffic or conversion).
- **Single-product, $1-in/$2-out thinking**: it breaks as competition and ad costs rise.

## Worked Example
**The dentist:** a free cleaning postcard (bait) led to "your teeth look yellow" and a whitening tray offer, then "your teeth are shifting" and a retainer. He walked out having spent more than $2K in under an hour, and he was booked for a six-month cleaning (continuity). The top rung, cosmetic work, runs $10K or more.

**Stacey and Paul Martino (relationships):** lead funnels feed a free podcast, then a 14-day Boost challenge at $47 (challenge/unboxing funnel), then a Quick Start home study at $997 (webinar/presentation funnel), then a three-day Breakthrough Retreat at $1,997 (live event), then Relationship U, a year of coaching at $14,997 (application funnel).

**Chiropractor (Dr. Chad Woolner):** the business was $50 ten-minute adjustments and nothing else. He built a back end of $5K+ wellness programs using the nutrition and healing skills he already had. He made the front end attractive with a free massage, supplements, and a meditation CD when patients booked a first visit. The clinic filled to capacity and a share of patients ascended.

**Liz Benny:** her only 90-day focus was a webinar funnel for a $1,000 course, and she wasn't allowed to build the next rung until it passed $1M (1,000 sales). She hit it within a year, then launched high-ticket coaching by email and filled it within days.

## Key Takeaways
1. Write your VLMS: "We help [who] to [result] through [new opportunity]."
2. Map the full ladder, then look for the missing front end (attractive bait) and back end (premium service, events, masterminds).
3. Match each rung to its funnel type: lead ($0), unboxing ($1 to $100), presentation ($100 to $2K), phone ($2K+).
4. Launch one funnel, ideally a mid or high rung, and scale it to $1M before building the next.
5. Open higher rungs when buyers ask for more. Add new front ends when ads on the core offer fatigue.
6. Add immediate upsells and follow-up funnels so every buyer can ascend.

## Connects To
b1-ch01 (step 4: unique result), b1-ch02 (a new offer at each rung), b1-ch06 (Seven Phases), b1-ch07 (Follow-Up Funnels), b1-ch08 through b1-ch17 (the funnel types by tier), b2-ch02 (Expert Secrets offer and Value Ladder), b3-ch01.
