# DotCom Secret 8: Lead Squeeze Funnels

## Core Idea
The simplest lead funnel has two pages: a squeeze page that trades a lead magnet for an email address, and a thank-you page that delivers it and points to the next funnel. It sits at the $0 front of the Value Ladder, and its only job is to turn traffic into owned traffic so the Soap Opera Sequence can start. This is a short chapter.

## Frameworks Introduced

**Lead Squeeze Funnel (two pages)**
1. **Squeeze / landing page**
   - **Offer**: a **lead magnet** that your dream customer loves and non-ideal customers ignore. Any format works (ebook, coupon, contest, video, membership, a few paragraphs). What matters is real value, not the delivery method.
   - **Hook**: a headline packed with curiosity (see the Curiosity-Based Headline scripts, b1-ch18).
   - **Story**: a very short subheadline, so it doesn't distract from the offer.
2. **Thank-you page**: thank them, deliver the lead magnet, and start the Soap Opera Sequence. Once you have a next funnel, add a link to it here.
- When to use: at the front of every Value Ladder, and for all paid traffic you control.
- Diagnostic: a low opt-in rate means either the lead magnet isn't good enough or the headline lacks curiosity.
- Why it works / failure mode: fewer people see your "site," but you make more money because you can follow up. The failure mode is a lead magnet with no real value. Then people don't remember you, don't open your emails, and don't ascend.

**Reverse Squeeze Page (variant)**
- Formulation: a video replaces the image and tells the story before asking for the opt-in.
- When to use: when the offer needs explaining.
- Trade-off: lower conversion rate, but more qualified leads. Script the video with Who, What, Why, How (b1-ch19).

**Front-End (Lead) Funnel family** (from the Section 2 opener)
- The squeeze page began as a pop-up promoted to the first page people see. After browsers blocked pop-ups, the offer became the gateway to the site.
- The three highest-producing lead funnels are Lead Squeeze, Survey (b1-ch09), and Summit (b1-ch10).
- For each Value Ladder step, answer four questions: What is the goal of this step? Which funnel achieves it? What offer plugs in? Which script goes on each page?

## Key Concepts
- **Lead funnel**: a funnel whose goal is an email address, not a sale.
- **Squeeze page**: a one-option page that "squeezes" out the email address.
- **Lead magnet**: the free offer that attracts the dream customer and repels others.
- **Headline = hook**: on a squeeze page, curiosity drives conversion.
- **Subheadline = story**: one line of proof or intrigue.
- **Thank-you page**: delivers the lead magnet and bridges to the next funnel.
- **Reverse squeeze page**: a squeeze page led by a video.

## Mental Models
- Think of the squeeze page as the doorway to owned traffic. Every paid click should hit one.
- Use a short story when the offer is simple. Use a reverse squeeze page when it needs explaining.
- Think of a lead magnet as a small, real win that earns the next email open.

## Anti-patterns
- **Long stories on a standard squeeze page**: they distract from the offer.
- **A generic lead magnet**: it attracts everyone, or no one.
- **A dead-end thank-you page once you have other funnels**: always link to the next rung.

## Worked Example
**Double Your Dating (Eben Pagan), a business doing $20M a year:**
- Squeeze page headline promising secrets most men never learn about women. Opt in to get "the kiss test."
- Thank-you page delivers the kiss test in a few paragraphs. Touch her hair while she's talking and comment on it. If she leans in and smiles, she's attracted. If she pulls away, stop and move on.
- Then the ascension: "Want to learn more?", leading to the Double Your Dating ebook.
- All the ads promoted this one page. It built a list of more than 1M, which was then sold other products by email.

**Brunson's Marketing Secrets Black Book:** the hook was "99 secrets that will change your business and change your life." The story was how they took ClickFunnels from zero to more than $100M in three years. The offer was a free digital copy.

## Key Takeaways
1. Build a two-page funnel: squeeze page, then thank-you page.
2. Create a lead magnet with real, specific value for the avatar only.
3. Put maximum curiosity in the headline and keep the subheadline to one short line.
4. If conversions are low, fix the lead magnet or the headline first.
5. Use a reverse squeeze page (video, Who-What-Why-How) for complex offers when you want more qualified leads.
6. Start the Soap Opera Sequence on opt-in, and add a link to the next funnel on the thank-you page once one exists.

## Connects To
b1-ch07 (Follow-Up Funnels, traffic you own), b1-ch06 (phase 3: qualify subscribers), b1-ch09 (Survey Funnels), b1-ch10 (Summit Funnels), b1-ch18 (Curiosity-Based Headline scripts), b1-ch19 (Who, What, Why, How script), b3-ch07 (converting traffic into owned traffic).
