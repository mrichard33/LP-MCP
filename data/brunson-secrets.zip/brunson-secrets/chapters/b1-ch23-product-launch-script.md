# Dotcom Secrets Secret 23: Product Launch Script

## Core Idea
The product launch script is the Perfect Webinar broken into four videos (Jeff Walker's "sideways sales letter"): Video 1 = introduction + secret 1, Video 2 = secret 2, Video 3 = secret 3, Video 4 = stack and close. The whole series sells a **new opportunity** (a new vehicle), teaching the *what* in videos 1–3 and selling the *how* in video 4.

## Frameworks Introduced

**Four-Video Product Launch Script**:
- When to use: Product launch funnels (b1-ch16), live or automated, to warm/hot traffic.
- How:
  - **Video 1 — Wow and How** (hook them or they won't return)
    1. *Introduce the new opportunity* — position the offer as a new vehicle, not an improvement on what failed before.
    2. *Kill false beliefs with your origin story* — you once held their doubts; tell how you came to believe.
    3. *Let's look at others* — case studies proving it works beyond you.
    4. *Hook to video 2* — tease it; ask for comments/questions you'll answer next time.
  - **Video 2 — Transformational Education** (they must picture themselves doing it)
    5. *Over the shoulder* — demo or proof they can watch you do the thing.
    6. *Your framework* — walk through your steps (what, not how).
    7. *Framework proof* — one case-study person's journey through each step.
    8. *Hook to video 3* — plus comments/questions.
  - **Video 3 — External Forces**
    9. *Future pace* — what would be different if they had the result?
    10. *What roadblocks?* — name external obstacles (spouse eating junk food; no traffic for a funnel) and tell stories of others who overcame them.
    11. *Hinting to the offer* — the offer supplies the missing how.
    12. *Hook to the offer video.*
  - **Video 4 — The Offer**
    13. *Here's what I've got* — recap the opportunity and the what; introduce the offer as the how; stack each element with a stack slide and running total value (emotional).
    14. *Here's what you'll do with it* — paint ownership: show the order form, the post-purchase page, the first thing you'd do after access.
    15. *Here's what it'll do for you* — re-explain benefits and hidden benefits (logical).
    16. *Here's what you need to do right now* — bold CTA plus real urgency/scarcity (when it closes, whether price rises, whether it's pulled).
- Why it works: Each video removes one belief layer (vehicle → self → external), so by video 4 the only remaining question is how to get it.
- Failure mode: A weak video 1—if it doesn't wow, it's the only video they watch.

**New Opportunity vs. Improvement Offer**: frame the series around a different vehicle, not a better version of what they've already tried and failed with (depth in Expert Secrets).

**Emotional-then-Logical Offer Sequence** (video 4): stack for emotion → ownership experience → benefits/hidden benefits for logic → CTA with urgency.

## Key Concepts
- **Sideways sales letter** — a sales presentation released in episodes.
- **New opportunity / new vehicle** — the different path the series promotes.
- **Over-the-shoulder coaching** — letting viewers watch you do it.
- **Framework proof** — a case study walking through each step.
- **External forces** — obstacles outside their control.
- **Ownership experience** — showing what happens after purchase.
- **Hook to next video** — open loop plus comment prompt.

## Mental Models
- Think of the four videos as intro+secret 1, secret 2, secret 3, stack+close.
- Use video 2 to kill "it works for others but not me."
- Think what in the content, how in the product.

## Anti-patterns
- **Improvement framing**: prospects compare you to things that failed them.
- **Teaching the how in free videos**: removes the reason to buy.
- **Missing hooks between videos**: drop-off grows each release.
- **Timid final CTA**: video 4 is the last shot; be bold and specific about deadlines.

## Worked Example
Assembled from the chapter's scattered ClickFunnels references (the author gives no single end-to-end example): Video 1 introduces funnels as the new vehicle and his origin story plus member case studies; Video 2 demos building a funnel in ClickFunnels so viewers see it's simple; Video 3 tackles "but I don't know how to get traffic" with stories of members who solved it; Video 4 recaps, stacks the offer with a total value, walks through the order form and members area, lists hidden benefits, and states when the offer ends.

## Key Takeaways
1. Map your Perfect Webinar onto four videos; don't write a new pitch.
2. Sell a new opportunity, reinforced in every video.
3. Close each content video with a hook and a comment prompt.
4. Use over-the-shoulder demos plus one framework case study in video 2.
5. In video 4 go emotional (stack) then logical (benefits), then a bold, deadline-backed CTA.

## Connects To
b1-ch16 (product launch funnels), b1-ch22 (Perfect Webinar), b2-ch04 (new opportunity), b2-ch13 (three secrets), b2-ch14 (stack and closes), b2-ch10 (four core stories), b3-ch18 (affiliate launches).
