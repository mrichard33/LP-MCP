# Expert Secrets — Secret 17: The Perfect Webinar Shortcut

## Core Idea
When speed matters more than polish, you can build a Perfect Webinar in about 15 minutes by answering eight questions on a whiteboard, then deliver it immediately on Facebook Live or Periscope. There are no slides and no registration funnel. Brunson's 26-minute improvised version reached 100K+ viewers, did $250K+ in sales, and won a $50K affiliate contest.

## Frameworks Introduced
**The Perfect Webinar Cheat Sheet (8 questions)**:
1. What new opportunity am I offering?
2. What special offer (stack) can I create for buyers?
3. What is the one Big Domino for this offer? (Turn it into a title.)
4. What epiphany bridge origin story attempts to knock it down?
5. Vehicle: which framework, which false belief, what truth, which story → Secret 1 title.
6. Internal: framework / false belief / truth / story → Secret 2 title.
7. External: framework / false belief / truth / story → Secret 3 title.
8. How will I structure the stack and closes to increase conversions?
- When to use: fast launches, affiliate promos, testing a new offer, or quick structuring of any perfect webinar.
- How: write the stack and the three secrets on a whiteboard or paper, go live, tell the stories, then stack and close from the board.
- Why it works / failure mode: the script carries the persuasion, so production value is optional. It fails when the presenter hasn't practiced the script; live comments can be brutal.

**Framework / False Belief / Truth / Story grid**: for each secret, fill in four cells, e.g. False belief "webinars don't work for me" → Truth "you just need the right script" → Story (how the framework was developed).

**Shortcut → ad loop**: if the recorded live converts, run it as an ad for as long as it stays profitable.

## Key Concepts
- **Perfect Webinar Shortcut**: a slide-free, whiteboard-driven Perfect Webinar delivered live on social.
- **Whiteboard stack**: the offer list with values written by hand and shown on camera.
- **Funnel leakage avoided**: a traditional webinar loses people at each step (≈40% register, ≈20% show). A shortcut is seen by 100% of viewers.
- **Improvement offer trap**: automated webinar software was nothing new, so the new opportunity became the *weekly webinar model*.
- **Three failure causes**: a bad market, an improvement offer, or teaching tactics before selling strategy.

## Mental Models
- Think of the Perfect Webinar as a set of questions, not a slide deck. Answer them and you have the pitch.
- Use the shortcut to test offers quickly, then invest in slides only for winners.
- If the script fails, check market, then offer, then tactics creep, in that order, before blaming the script.

## Anti-patterns
- **Going live on social before mastering the script**: practice in a private webinar first.
- **Selling a commodity as-is**: reframe it as a new opportunity (the model, not the software).
- **Waiting for polish**: a missed window costs more than imperfect titles.

## Worked Example
Affiliate promo for a friend's automated-webinar software:
- New opportunity: increase webinar sales with the weekly webinar model.
- Stack: Perfect Webinar Script $497 · Perfect Webinar Training $997 · videos of live closes $2,997 · Perfect Webinar Funnel $997 · "my webinar funnel" (priceless) → total $14,988.
- Big Domino/title: webinars done through this model are the only way to seven figures in 12 months ("How to make at least seven figures next year with this webinar model").
- Origin story: bombing the first event, then Armand Morin teaching the stack.
- Secret 1 (vehicle): Perfect Webinar framework. False belief "doesn't work for me," truth "it's the script." Title "It's all about the script."
- Secret 2 (internal): weekly webinar model. False belief "I did one and it bombed," truth "do it weekly for a year." Title "Understanding the model."
- Secret 3 (external): auto-webinar transition. False belief "I'll be stuck doing live forever," truth "automate once perfected." Title "You have to do this live until..."
- Result: 26 min 32 sec live on Facebook + Periscope, 100K+ views over 3 days, $250K+ sales. Kaelin and Brandon Poland copied it the same day with $100K+ on the first try and later $650K+ from a single Facebook Live.

## Key Takeaways
1. Keep the 8-question cheat sheet for every new offer.
2. Fill the framework/false-belief/truth/story grid for all three secrets before going live.
3. Put the stack on a whiteboard and go live where your following already is.
4. Promote the recording as an ad while it converts.
5. Rehearse in a private webinar before going live on social.

## Connects To
b2-ch04 (new opportunity vs. improvement), b2-ch11 (framework), b2-ch12 (Big Domino), b2-ch13 (three secrets), b2-ch14 (stack), b2-ch16 (weekly live model, the Secret 2 content here), b2-ch19 (shortcut as a launch ad/VSL), b1-ch22 (Perfect Webinar script).
