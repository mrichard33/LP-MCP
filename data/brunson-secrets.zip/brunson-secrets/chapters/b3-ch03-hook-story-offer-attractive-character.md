# Traffic Secrets — Secret #3: Hook, Story, Offer, and the Attractive Character

## Core Idea
Once you know where your Dream Customers congregate, you pull them out with Hook Story Offer: a hook to stop the scroll, a story to build desire and connection, and an offer to get the action. Every ad, post, email, page and funnel either works or fails because of one of those three parts.

## Frameworks Introduced
**Hook Story Offer**: the core pattern for selling anything online, and also the diagnostic for any underperforming asset.
- When to use: when creating any ad, post, email, video, landing page or funnel step; and whenever a metric is low (CTR, opt-in rate, webinar attendance, close rate, upsell take rate, open rate).
- How: (1) **Hook**: whatever grabs attention for a moment (headline, image, subject line, thumbnail, the first 3 seconds of a video, a background, something odd). (2) **Story**: builds perceived value and creates desire, and connects the prospect to you as the Attractive Character (use Epiphany Bridge stories). (3) **Offer**: the call to action, which can be a purchase or a micro-offer ("comment/subscribe/join my list and get X").
- Why it works / failure mode: it turns vague "the ad isn't working" into three levers you can test. Failure mode: blaming the platform or traffic source when the problem is the hook, story or offer.

**Hook design by scene**: picture your Dream Customer alone with their phone (on the couch, in bed, on the toilet) scrolling a feed.
- How: study your own scrolling. Ask what made you stop, why you clicked play, what the hook said and how it made you feel. Then write hooks for that moment and throw them into your Dream 100 congregations.

**Story's two jobs**: (1) raise the perceived value of the offer and create urgency to buy now; (2) build a relationship with the **Attractive Character**, so someone who doesn't buy today becomes a follower, then a customer, then a raving fan who shares your content.

**Offer lever (the trash-can principle)**: when people don't act, the fastest fix is usually a better offer. Take out the trash for $1? No. For $10? Maybe. For $1,000? Everyone says yes.
- How: add bonuses, increase what's delivered, make it more appealing, or tell a better story to raise perceived value.

## Key Concepts
- **Hook**: anything that captures attention long enough to tell a story.
- **Story**: the bridge that creates desire and connection (Epiphany Bridge, from Expert Secrets).
- **Offer**: what they get for taking the desired action. Not always a sale.
- **Attractive Character**: the personality behind the brand. It is increasingly central to traffic results and drives repeat buying.
- **Perceived value**: value the prospect assigns after the story. Stories raise it.
- **Irresistible offer**: an offer so strong that saying no feels wrong.
- **Micro-offer**: a small exchange (like, comment, subscribe, opt-in) for a gift.

## Mental Models
- When any metric underperforms, think "it's always the hook, the story or the offer," then isolate and test one.
- Think of every piece of content as a small HSO unit: the image/headline is the hook, the body is the story, the link is the offer.
- When people won't act, raise the offer before rebuilding everything.
- Think relationship over transaction: anyone can sell once, but the Attractive Character sells again and again.

## Anti-patterns
- **Pure transaction ads**: you might sell once, but you won't build fans or repeat buyers.
- **Weak offers blamed on traffic**: prospects who were hooked but didn't buy usually saw too little value.
- **Hooks without a story**: attention with no desire or connection behind it.
- **Treating the hook as only words**: images, video backgrounds and the first 3 seconds count too.

## Worked Example
Natalie Hodson's "Abs, Core & Pelvic Floor" ad:
- **Hook**: a photo of a mom in gray workout shorts with a visible wet spot, captioned "the time I peed my pants during a workout." It stops a tired mom scrolling at 9:27 pm, who remembers leaking on a trampoline with her kids.
- **Story**: the click goes to Natalie's video. She's a fitness blogger and mom of two 10-lb babies who leaked on camera, met a specialist doctor, got fixed, and built a home program with that doctor.
- **Offer**: an e-book with bonus nutrition tips, exercises and training plans for $47, the doctor's advice without a visit.
- Result: 120,000+ buyers in about 3 years.

Note: this chapter is short in the source. The deeper story and offer mechanics are in Expert Secrets.

## Key Takeaways
1. Build every asset with an explicit hook, story and offer. Label each part before you ship it.
2. When something underperforms, fix one lever at a time: new hooks first for low CTR, the story for low desire, the offer for low conversion.
3. Collect hooks that stop *you* while scrolling and note why they worked.
4. Use stories that raise perceived value AND show your Attractive Character.
5. Improve weak offers with bonuses and more deliverables before blaming traffic.

## Connects To
b1-ch02 (Hook Story Offer), b1-ch04 (Attractive Character), b2 Expert Secrets (Epiphany Bridge, irresistible offers), b3-ch01 (interruption traffic needs HSO), b3-ch02 (where to throw hooks), b3-ch09 (paid ad structure), b3-ch11 (Facebook ads), b3-ch13 (YouTube hooks).
