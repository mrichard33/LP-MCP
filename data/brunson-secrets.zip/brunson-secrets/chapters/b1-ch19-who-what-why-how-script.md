# Dotcom Secrets Secret 19: Who, What, Why, How Script

## Core Idea
A short, memorable script that answers four questions—who are you, what do you have, why do they need it, how do they get it—then calls to action. Use it daily for video and text ads, lead-magnet and webinar-registration pages, thank-you pages, and book/cart funnels selling low-ticket offers to cold traffic. A thin but highly reusable chapter: one core script plus four amplifiers.

## Frameworks Introduced

**Who, What, Why, How Script**:
- When to use: Front of the value ladder, colder traffic, first-impression videos (ads, squeeze pages, webinar thank-you pages, free-trial or free-plus-shipping offers, free reports, free consultations).
- How:
  1. **Who** — one-line intro: name + credibility.
  2. **What** — hook plus the offer in one breath (include proof of scale if you have it).
  3. **Why** — run PAS inside it: **Problem** (in their words), **Agitate** (twist the knife), **Solve** (your offer is the fix).
  4. **How** — exact action: click the link / go to the URL.
- Why it works: Answers the four questions every cold prospect silently asks, in under a minute, with no wasted story.
- Failure mode: Skipping "Why"—without a felt problem the free offer looks like noise.

**Four Amplifiers** (add after the core to lift conversions):
- **The Catch** — say why the deal is so good (or that there's no catch) before they wonder.
- **Urgency and Scarcity** — a real, time-bound bonus (e.g., templates if they join before Friday midnight).
- **Guarantee** — reverse risk (cancel anytime with one click, no calls).
- **Recap** — restate what they get, the bonus, and the deadline.

**PAS (Problem–Agitate–Solve)**: classic copy formula nested in the "Why" step.

## Key Concepts
- **Who** — credibility intro for someone meeting you for the first time.
- **What** — the offer, stated with a hook.
- **Why** — the reason they need it now (PAS).
- **How** — the single action to take.
- **The catch** — preemptive answer to "what's the trick?"
- **Real urgency** — a genuine expiring bonus, not a fake timer.
- **Risk reversal** — guarantee that removes fear of committing.

## Mental Models
- Use Who/What/Why/How whenever a stranger will see you for the first time.
- Think of PAS as the engine inside "Why."
- Use the catch to turn suspicion into a reason to believe (e.g., "you'll never want to leave").

## Anti-patterns
- **Long origin story in a cold ad**: save the Epiphany Bridge for later touches.
- **Vague CTA**: tell them exactly where to click.
- **Fake urgency**: use real, expiring bonuses.
- **Avoiding the catch**: prospects assume one exists; name it.

## Worked Example (fill-in template)
- **Who**: "Hi, I'm [Name], [credential/role]."
- **What**: "In the past [time], [number] [audience] have [switched to/achieved X]—and I want to give you [free offer] today so you can [first result]."
- **Why — Problem**: "I know your [current tool/approach] isn't [producing desired result]."
- **Why — Agitate**: "Most people spend [money/time] on [approach] and end up with [disappointing outcome]."
- **Why — Solve**: "That's why I'm giving you [offer] so you can [result] without [pain]."
- **How**: "Click the link below or go to [URL] to start now."
- **Catch**: "Why free? Because once you [experience result], you'll [stay/buy more]."
- **Urgency**: "Sign up before [deadline] and also get [bonus]."
- **Guarantee**: "If you don't love it, [simple cancel/refund]."
- **Recap**: "So go to [URL] for [offer], and before [deadline] you'll also get [bonus]."

Russell's own version: co-founder of ClickFunnels → 100,000+ entrepreneurs ditched websites for funnels → your website is a brochure that doesn't generate leads or sales → free 14-day trial → catch: you'll never want to leave → 10 lead-funnel templates if you join before Friday midnight → cancel with one click.

## Key Takeaways
1. Default to this script for any cold-traffic ad or first-touch landing video.
2. Keep "Who" to one line; spend your words on "Why" using PAS in the prospect's language.
3. End with one concrete action.
4. Add catch, real urgency, guarantee, and recap to lift conversions.
5. Reuse the same skeleton for free trials, free reports, free consults, and webinar registrations.

## Connects To
b1-ch15 (webinar thank-you video), b1-ch16 (workshop page), b1-ch08 (lead squeeze), b1-ch11 (book funnels), b1-ch12 (cart funnels), b1-ch18 (headlines), b1-ch20 (longer Star Story Solution), b3-ch09 (paid ads), b3-ch19 (cold traffic).
