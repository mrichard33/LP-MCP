# Dotcom Secrets Secret 25: The Setter and Closer Scripts

## Core Idea
When the expert won't take the calls, split high-ticket selling ($2,000–$100,000) across two people: a **setter** who uncovers emotion, pain, goals, finances, and commitments, then hands off; and a **closer** (often titled "director") who re-confirms, magnifies the pain, runs yes/no commitments, and lets the prospect sell themselves into the program. Takeaway selling at its highest level, and the model for scaling a sales team. This chapter's range also opens Section 4 (Building Your Funnels): moving from strategist to technician.

## Frameworks Introduced

**Setter Script**:
- When to use: First call to an applicant when a sales team handles high-ticket offers.
- How:
  1. **Introduction** — low-key, natural; learn where they are now and how they feel about it.
  2. **Questions** — where they want to be, and the deep *why* (quit job, stay home with kids, buy parents a house). Keep asking follow-ups (kids' names, ages, how it would feel) to hook emotion; buyers decide emotionally and justify with logic.
  3. **What's holding you back?** — reframe "no time" or "no money" as "don't know how" (build in 5 hours a week; use other people's money). Ask: "If you knew how to [do it in 5 hours/week], would you?" Do not advance until emotional hot buttons are known and they admit they need help.
  4. **Blast (a taste)** — explain you're weeding out who isn't ready; briefly describe what you do.
  5. **Self-sell question** — "If you worked one-on-one with [Expert] or someone like him, do you think you'd succeed? How come?" Then be silent; repeat their reasons back. Then: "Why would you be a good candidate?"
  6. **Posture** — "I'm not the expert; my job is to find qualified people for our director. First I need a short profile—OK if I ask a few questions?" (permission to ask anything)
  7. **Probe (finances)** — quick demographics (age, marital status, education); any spouse/partner involved? If yes, get them on the call now. Credit rating; total debt; credit-card debt; total credit extended (available credit = extended − debt; want more than program cost); savings, investments, home ownership, retirement accounts.
  8. **Goals** — 6-month and 12-month targets; how long they've tried; "working with [Expert], could you hit these? How come?"
  9. **Four commitments** — (a) minimum [X] hours/week; (b) coachable—why?; (c) can start today/quick decision maker; (d) open to OPM (credit as short-term leverage). Then: two program levels—how much are you comfortable investing today, and why?
  10. **Handoff** — give the director's name; warn the program isn't for everyone; assign homework: write 6- and 12-month financial goals plus three non-money wants.
- Why it works: Prospects say the reasons they'll succeed themselves, so they believe them; commitments made aloud are hard to reverse.
- Failure mode: Proceeding without all decision-makers or without surfacing the emotional why.

**Closer Script**:
- When to use: The callback after the setter briefs the closer.
- How:
  1. **Re-run the vision** in new words — why serious now, how long thinking about it, biggest blocker, 6-month, 12-month, 5-year lifestyle; "How would working with [Expert] change your life? Anything else?"
  2. **Four yes/no commitments** — only take people who'll succeed: **Time** ([X] hrs/week?), **Decision making** (anything stopping a decision today?), **Resources** (write down [price]; if it meets your goals, any reason you couldn't invest today?), **Knowledge/teachability** (are you teachable? how come? if shown how, would you succeed?). Any "no" → backtrack or end the call.
  3. **What's included** — list deliverables plainly.
  4. **Close** — "Why do you feel you're a good candidate?" Then take payment; they are asking you to let them buy.

## Key Concepts
- **Setter** — gathers info, emotion, pain, goals; qualifies.
- **Closer / director** — authority figure who magnifies pain and finalizes.
- **Takeaway selling** — "not for everyone" posture that makes prospects pursue you.
- **Hot buttons** — the emotional reasons they'll buy.
- **Available credit** — total credit extended minus debt; must exceed program cost.
- **OPM** — other people's money (credit as leverage).
- **Four commitments** — time, coachability/knowledge, decisiveness, resources.
- **Section 4 shift** — strategist → technician who can build funnels (an 11-year-old funnel builder took equity over $10k–$25k fees).

## Mental Models
- Think "if I say it, it's a claim; if they say it, it's true."
- Use the setter for emotion and data, the closer for authority and commitment.
- Think of price objections as a setup failure earlier in the call.

## Anti-patterns
- **Pitching features early**: the setter only gives a taste.
- **Missing decision-makers**: stop and get the spouse/partner on now.
- **Moving past a "no" commitment**: backtrack or end.
- **Asking for the sale**: let them explain why they should be accepted.

## Worked Example
Setter flow for a "build an online business in 5 hours a week" coaching program: prospect wants $100,000/year → why? stay home with kids → blocker: "no time" reframed to "don't know how in 5 hours/week" → "If you knew how, would you?" yes → "If you worked with Russell, would you succeed? How come?" → profile and credit questions → 6/12-month goals → four commitments → "two levels; what are you comfortable investing today?" → handoff to the director with a goals-writing exercise. Closer re-confirms, runs yes/no commitments with the price written down, lists inclusions, asks "Why are you a good candidate?", takes payment.

## Key Takeaways
1. Use two roles once volume outgrows the expert; the setter never closes, the closer rarely discovers.
2. Don't advance until the prospect's emotional why and "I don't know how" are on the table.
3. Qualify finances and decision-makers on the first call.
4. Get four spoken commitments; treat any "no" as a stop sign.
5. End with the prospect selling themselves on why they're a good candidate.

## Connects To
b1-ch17 (application funnels), b1-ch24 (Four Question Close, expert-led), b1-ch16 (back-end phone funnels), b1-ch26 (Section 4 building), b1-ch28 (cost per application < $100), b2-ch15 (trial closes), b3-ch01 (dream customer).
