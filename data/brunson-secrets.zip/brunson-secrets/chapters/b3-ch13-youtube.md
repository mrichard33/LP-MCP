# Traffic Secrets — Secret 13: YouTube Traffic Secrets

## Core Idea
YouTube is part social network and part search engine, so it is the one platform where content keeps gaining views for years instead of decaying. Build keyword-targeted "discoverable" videos to earn subscribers, use video webinars to sell, and buy ads on Dream 100 and keyword-ranked videos in the meantime.

## Frameworks Introduced

**Two Dream 100 lists for YouTube**: (1) the people, brands, and influencers whose channels you can buy pre-roll ads on, "leveraging their name, credibility and content"; (2) the keyword phrases you will make videos for.

**Channel Focus Phrase (Jeremy Vest's "find your channel's 'how to shave'")**
- When to use: a new channel that can't yet rank for broad head terms.
- How: pick one root keyword (Gillette used "how to shave") and make many videos on suffix variants (…your head, …your beard, …your legs). Use the **Dream Keyword A-B-C Hack**: type the root plus " a", then " b", and so on in the YouTube search bar and harvest autosuggestions until you have at least 50 titles.
- Why it works: long-tail variants are winnable, and together they make the channel an authority on the root phrase.

**Discoverable Video Script (Joe Marfolio)**
- How: **Hook** (15 seconds, using the searched keyword, promise the value) → **Trailer** (branded intro of 4–5 seconds maximum, never 30–60) → **Intro** (15–30 seconds on who you are and why listen) → **Story/Content** (7–12 minutes delivering the hook's promise) → **Offer** (like, comment, subscribe, notifications).
- Why it works / failure mode: if a video takes off (100K views), the structure turns viewers into subscribers. Long branded intros lose most viewers before the value starts.

**Video Webinars**: less keyword-driven videos for existing subscribers, where the selling happens. Use the Perfect Webinar, the Perfect Webinar hack, or the 5-minute Perfect Webinar to move earned traffic to owned traffic.

**Upload checklist (six items)**
1. Treat YouTube as a TV station with a fixed schedule (e.g. Thursdays 7 p.m. ET).
2. Pick the target keyword.
3. Write a title that contains the keyword plus a hook that works with the thumbnail.
4. Design a thumbnail that reads when tiny: large faces, bright colors, few words.
5. Write a 150–300 word description with the keyword and CTA in the first two sentences (above the fold), subscribe, funnel, and playlist links, and up to 3 hashtags.
6. Add tightly relevant tags, which matter less than they used to.
Then send traffic you own to the video right away to seed engagement.

**Channel setup**: brand-first channel name (e.g. "Russell Brunson / ClickFunnels"); About page (it is indexed); a simple header that states the value; your face, not your logo, as the profile image; a **channel trailer** for non-subscribers of 60–120 seconds (intro, backstory and authority, value statement, posting schedule, subscribe and notifications CTA). An iPhone is enough.

**Binge-Watching Playlist Hack**: break long 30–60+ minute content into a 5–10 minute series in a playlist that autoplays in order, and launch one playlist a month to traffic you own.

## Key Concepts
- **Evergreen compounding**: YouTube views grow over time, while feed posts decay.
- **CTR benchmarks**: 4% acceptable, 6% good, 9% "throw a party."
- **Minute-one retention**: keep it above 70%.
- **Overall retention**: 35% acceptable, 40% good, 50% "party time."
- **Discoverable video**: a keyword hook video whose offer is the subscription.
- **Collab**: a video swap with another channel, or trading a guest spot on their channel for an appearance on your podcast.
- **Buy-in link placement**: paying the owner of a popular video to add your link to its description.

## Mental Models
- Think of each video as an asset that works for you "even after you're dead." Invest in optimization once.
- Use hot owned traffic to launch a video. Early high retention and engagement signal quality, and the algorithm then adds sidebar and search placement.
- Watch your Dream 100's top videos to learn the current rules for titles, thumbnails, and descriptions. Don't memorize rules.

## Anti-patterns
- **Going after "how to make money online" with a new channel**: you'll be buried by bigger channels.
- **30–60 second branded intros**: kill minute-one retention.
- **Logo as profile image**: lowers engagement.
- **Off-topic tags**: confuse the algorithm.
- **Irregular posting**: YouTube rewards a show schedule.

## Worked Example
**Joe's two affiliate videos**: a 2:47 video he made plus Brunson's sales video, posted for an anti-pornography-addiction course. Within months, Joe was out-selling all of Brunson's own marketing. Years later the videos had 1.2M and 815K views. Six years after posting, one month still produced 10,361 views and 553 funnel clicks, even though the product was no longer sold.
**Buy-in example**: after buying a website, Brunson found a customer's product video getting hundreds of daily views with no link. He paid her to add a description link, and nearly five years later it still sends hundreds of clicks a month.

## Key Takeaways
1. Build two lists, Dream 100 channels and target keywords, and start pre-roll ads on Dream 100 videos now.
2. Choose a focus phrase and harvest at least 50 long-tail titles with the A-B-C hack.
3. Script every discoverable video Hook → 4–5s trailer → Intro → 7–12 min content → subscribe CTA.
4. Hold CTR at 4–9%, minute-one retention above 70%, and overall retention at 35–50%.
5. Publish discoverable videos weekly and one binge playlist monthly, seeded by traffic you own.
6. Buy links in the descriptions of popular videos whose creators aren't monetizing them. Specific YouTube ranking factors may have changed since 2020, so verify against your Dream 100.

## Connects To
b3-ch02, b3-ch04, b3-ch05, b3-ch09 (prospecting and retargeting), b3-ch12 (search logic, Google), b3-ch15 (how-to segments become YouTube videos), b3-ch18 (affiliates driving YouTube traffic), b2 Perfect Webinar, b1-ch02 (Hook, Story, Offer).
