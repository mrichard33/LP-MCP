# DotCom Secret 6: The Seven Phases of a Funnel

## Core Idea
Every visitor passes through seven phases. Phases 1 to 5 happen at the point of sale, within about 5 to 10 minutes; phases 6 and 7 come after. Each step asks for exactly one action, has its own Hook, Story, and Offer, and acts as the pre-frame for the next step. When a business is stuck, one of these phases is broken.

## Frameworks Introduced

**The Pre-Frame Principle**
- Formulation: the state someone is in as they enter a step changes how they experience it. "Not all clicks are created equal" (Mark Joyner). The frame people arrive through often matters more than the page.
- How: control the introduction to every step: ads, bridge pages, emails, stage intros, and prior pages. Optimize each step for the relationship, not only for the immediate conversion.
- Why it works / failure mode: in an MIT study, identical lectures were rated warm or cold depending on one word in the professor's bio. The failure mode is chasing short-term conversions so aggressively that you lose the long-term relationship, which is worth about 10x the first sale.

**The Seven Phases of a Funnel**
1. **Determine traffic temperature**: hot, warm, or cold (below).
2. **Set up the pre-frame bridge**: an ad, video, email, article, or a separate bridge page matched to the temperature.
3. **Qualify subscribers**: an opt-in or squeeze page trades something valuable (a free report or video) for an email address.
4. **Qualify buyers**: immediately after opt-in, not a day later, show a very low-ticket offer (free plus shipping up to about $7 to $10) to find out who will pull out a card.
5. **Identify hyperactive buyers**: upsells and cross-sells right away, for people in pain who want to spend more now.
6. **Age and ascend the relationship**: Follow-Up Funnels with the Attractive Character move them up the Value Ladder.
7. **Change the selling environment**: move high-ticket sales to phone, direct mail, or live events.
- When to use: as the design checklist for every funnel and as a diagnostic when sales stall.
- Why it works: each phase segments people into their own list (subscribers, then buyers, then hyperactive buyers) so you can spend more marketing money on the people worth more. The failure mode is asking for more than one action on a step. A confused mind always says no.

**Traffic Temperature (after Eugene Schwartz's awareness levels)**
| Temp | Who | Awareness | Talk to them | Bridge |
|---|---|---|---|---|
| Hot | Your list, podcast, followers | Product aware | As friends, through the Attractive Character | Very short: an email or post with a link |
| Warm | Dream 100's audiences | Solution aware | Show your solution vs. others | Short: an ad or video that references the host they follow |
| Cold | Has the problem, doesn't know solutions | Problem aware at best | Start from the problem, then crystallize the need | Longest: a separate bridge page that educates |
- Headline rule: product-aware prospects get a headline that starts with the product. Desire-aware prospects get one that starts with the desire. Problem-only prospects get one that starts with the problem and narrows to a specific need.
- You may need three landing pages, one per temperature.

## Key Concepts
- **Pre-frame**: the mental state set up before the next step.
- **Pre-frame bridge / bridge page**: content between the traffic source and the landing page.
- **Subscriber list vs. buyer list vs. hyperactive list**: separate segments that get different treatment and budgets.
- **"A buyer is a buyer is a buyer"** (Dan Kennedy): whoever buys once will keep buying while you keep delivering value.
- **Hyperactive buyer**: someone in acute pain who wants to spend a lot now. The window closes fast.
- **One-action rule**: each step asks for one thing.
- **Changing the selling environment**: high-ticket sales need a live, interactive setting for objection handling.

## Mental Models
- Think of every page as the pre-frame for the next page, not a standalone asset.
- Use the lowest-friction paid offer to turn subscribers into buyers, because buyers justify higher spend (calls, postcards, special offers).
- Think of upsells as a duty. If you believe you have the best solution, let the hyperactive buyer scratch the itch with you, not a competitor.
- Use a cold bridge to expand the market. Translate the problem into terms people already use.

## Anti-patterns
- **Starting funnel design at the landing page**: temperature and bridge come first.
- **One landing page for all temperatures**: the message won't match the traffic.
- **Delaying the buyer offer**: qualify buyers right after opt-in.
- **No upsells**: hyperactive buyers go and spend with competitors.
- **Multiple calls to action per step**: this puts a brick wall in the funnel.
- **Selling $15K to $100K offers with add-to-cart**: change the environment instead.

## Worked Example
**The pre-frame at a live event:** Brunson normally closed about 15% of a room on a $1,997 course. When Armand Morin introduced him deliberately, he closed more than 42% with the same talk, offer, and price. He then made a pre-frame video that every MC had to play before he spoke, and rarely closed below 40% after that.

**Temperature bridges for a neuropathy supplement:** hot (their customer list) reordered after a reminder email. Warm (people who knew they had neuropathy) got social ads announcing the new product. Cold (people with nerve pain who had never heard "neuropathy") got a bridge page: "If you have nerve pain, it's probably caused by neuropathy," with an explanation of the term. After that, the landing page language made sense and the addressable market grew exponentially.

**Subscriber math:** 1,000 visitors a day at a 30% opt-in rate gives 300 warm leads, followed immediately by a $7 to $10 buyer offer.

## Key Takeaways
1. Label every traffic source hot, warm, or cold, and build a matching bridge (and landing page if needed).
2. Script and control your own introduction on stage, in ads, and in affiliate emails.
3. Put a very low-ticket buyer offer right after opt-in, then upsells for hyperactive buyers.
4. Keep subscribers, buyers, and hyperactive buyers on separate lists with separate spend.
5. Give each step one call to action.
6. Move offers over about $2K to phone, events, or mail.
7. Diagnose stalls phase by phase: temperature, bridge, opt-in, buyer, hyperactive, ascension, environment.

## Connects To
b1-ch02 (Hook, Story, Offer per step), b1-ch03 (Value Ladder tiers), b1-ch05 (Funnel Hacking: watch the phases), b1-ch07 (phase 6, Follow-Up Funnels), b1-ch17 (phase 7, Application Funnels), b3-ch04 (Dream 100 = warm traffic), b3-ch06 (traffic temperature and bridges), b2-ch09 (webinar pre-frame).
