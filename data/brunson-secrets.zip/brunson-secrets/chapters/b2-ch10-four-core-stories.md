# Expert Secrets — Secret 10: The Four Core Stories

## Core Idea
Marketing is rewriting the story inside the prospect's head (Craig Clemens). People form beliefs through **experience → story → belief**, and false beliefs protect their status while blocking progress. Map each false belief to the experience and story behind it, then counter it with an epiphany bridge story. In a pitch, four core stories break the three core false beliefs (vehicle, internal, external) after the origin story establishes the new opportunity. Build a **story inventory** so you always have the right story ready.

## Frameworks Introduced
**Belief formation → Rewrite (4 columns)**
- How beliefs form: an experience happens → the mind creates a story about what it meant → the story becomes a belief (protective or false). When you present a new opportunity, the subconscious checks it against existing stories. If it fits, they believe you. If not, you must tell a better story.
- **Chains of False Belief** process:
  1. **False belief**: what would stop them from believing in your new opportunity? (If you're stuck, use the beliefs you held before your own epiphany.)
  2. **Experience**: the likely past event that created it.
  3. **Story**: what they now tell themselves because of that experience.
  4. **New epiphany bridge**: your own story, or someone else's, that shows you once believed the same thing, what changed, and the new belief.
- Why it works / failure mode: if they already had the right story, they would already have the result. Stories deliver the new belief without selling, and prospects sell themselves. Failure mode: telling random entertaining stories with no false belief to target.

**The Four Core Stories** (the order used in the selling framework)
1. **Origin story / new opportunity**: the full Epiphany Bridge Script, told first and longest (backstory, journey, guide, frameworks, your results and others', achievement and transformation). *Breaks*: false beliefs about the old opportunities they're using now. *Goal belief*: "the new opportunity (funnels) is the best way to get my result."
2. **Vehicle framework story (how you learned or earned it)**: the story of how you built the framework, then its strategy (the *what*). Example: how Brunson created the funnel-hacking framework (find proven funnels and model them).
3. **Internal belief story**: *breaks* "it works, but I can't do it" (e.g., "I'm not technical enough to build funnels"). Tell how you found you could do it, plus people just like them who did.
4. **External belief story**: *breaks* "an outside force will stop me" (e.g., "I can't get traffic"). Tell a story showing the outside obstacle is beatable.
- When to use: in any one-to-many pitch (the Perfect Webinar and beyond). The same three false beliefs also drive the stack-slide bonuses.

**Story Inventory (4-step exercise)**: build a table for each category (new opportunity/vehicle, frameworks, internal, external). Columns: false belief → experience → story → new epiphany bridge. List dozens per category, not three. Use other people's stories where you have none of your own, then practice telling each one with the Epiphany Bridge Script.

## Key Concepts
- **Rewriting the story in their head**: the only real goal of marketing.
- **Experience → Story → Belief**: how every belief, true or false, gets formed.
- **False belief**: a protective story that blocks the desired result.
- **Chains of false belief**: the linked false belief, experience, and story you have to reverse.
- **Origin story**: epiphany bridge for the new opportunity.
- **Vehicle / Internal / External beliefs**: "is this the right vehicle?", "can I do it?", "will outside forces stop me?"
- **Story inventory**: a catalog of purpose-built stories, each tied to a false belief.
- **Purposeful stories**: each story exists to break a belief. Brunson told 50+ in 60 minutes.

## Mental Models
- Think of every objection as a false story. Answer it with a better story, not an argument.
- Use your own pre-epiphany beliefs as the first draft of your customers' false beliefs.
- Think of the pitch as a sequence: vehicle belief, then self (internal) belief, then outside-world (external) belief.
- Use other people's stories when you lack a personal one. Belief transfer still works.

## Anti-patterns
- **Random or entertaining stories**: no belief gets broken.
- **Arguing logically with a false belief**: the old story wins.
- **Breaking only the vehicle belief**: prospects still think "not for me" or "outside forces will stop me."
- **Too few stories in inventory**: you get caught with nothing to say when an objection comes up.
- **Ignoring the experience behind a belief**: your counter-story won't resonate.

## Worked Example
**Chains of false belief, two niches.**

| Step | Weight loss | Network marketing |
|---|---|---|
| False belief | If I try to lose weight, I'll be miserable | If I join network marketing, I'll lose my friends |
| Experience | Cut carbs last year and was miserable | Joined an MLM, pitched family, and they got mad |
| Story | I must give up things that make me happy to lose weight | You have to bug friends and family to succeed |
| New epiphany bridge | I thought so too, then learned about ketosis and lost weight by drinking ketones instead of cutting carbs | I feared offending friends too, then realized I can generate leads online from people who want to join |

## Key Takeaways
1. Write down each false belief your prospects hold about the vehicle, themselves (internal), and outside forces (external).
2. For each belief, trace the likely experience and the story they tell themselves.
3. Pair every false belief with an epiphany bridge story, your own or a customer's.
4. In a pitch, tell the origin story first, then the vehicle, internal, and external stories.
5. Build and keep adding to a story inventory of dozens per category, and practice telling each one with the 14-question script.

*(This chapter's range ends with the Section 3 opener, "One-to-Many Selling": Brunson's $3.2M in 90 minutes at Grant Cardone's 10X event. One-to-many selling has to answer everyone's objections in advance because nobody can ask questions. Your funnels, webinars, and social lives are your "virtual stage," and a recorded presentation turns a one-off event into automated revenue. It sets up b2-ch11.)*

## Connects To
b2-ch09 (Epiphany Bridge script), b2-ch05 (stack bonuses mapped to the same three false beliefs), b2-ch04 (new opportunity), b2-ch11 (Perfect Webinar framework, where the stories plug in), b2-ch12 (Big Domino), b2-ch13 (three secrets: vehicle, internal, external), b1-ch22 (perfect webinar script).
