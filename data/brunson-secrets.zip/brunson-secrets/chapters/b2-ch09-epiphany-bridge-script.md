# Expert Secrets — Secret 9: The Epiphany Bridge Script

## Core Idea
The Epiphany Bridge Script adapts the Hero's Two Journeys into **5 phases and 14 questions**. Answer them and you have a story that walks the listener to your epiphany and your new opportunity. Brunson uses it daily across podcasts, Facebook Lives, ads, emails, sales videos, webinars, and stages. It scales from a 30-second five-line version to a two-hour telling. It's the best answer to "what is [your thing]?"

## Frameworks Introduced
**The Epiphany Bridge Script (5 phases / 14 questions)**
- When to use: any story meant to sell a belief, but especially your origin story (the first of the four core stories).
- How: answer each question, then tell the story at whatever depth time allows.

**Phase 1 — The Backstory**
1. *Backstory*: what backstory gives us a vested interest in your journey? Start where the listener is now, and step down from expert status to when you were struggling like them.
2. *Desire*: what result did you want? **External** (drives the achievement journey. People share these readily) and **internal** (drives the transformation journey, from fear to courage). Being vulnerable about internal struggles builds rapport fastest.
3. *Old vehicle*: which vehicles did you try that failed? This is the wall of frustration that justifies trying something new.

**Phase 2 — The Journey / Conflict**
4. *The call*: what event, feeling, or lesson made you decide to try again? The desire moves from "should" to "must."
5. *Villain*: who or what fought against you? Usually a false belief or a harmful belief system in the market, and the thing you'll throw stones at.
6. *What if*: what was at stake if you failed? Name the worst case.

**Phase 3 — The New Opportunity**
7. *Guide*: who (or what inspiration) gave you the epiphany?
8. *Epiphany*: what was the aha, the missing piece? The goal is for the listener to have the same aha.
9. *New opportunity*: what tangible vehicle did you get or create? **This is where the opportunity switch happens.**

**Phase 4 — The Framework**
10. *Strategy*: what plan or framework did you build from the guide's insight?
11. *Your results*: what happened when you, the human guinea pig, applied it?
12. *Others' results*: case studies of other people it worked for.

**Phase 5 — Achievement & Transformation**
13. *Achievement*: which external desire did you accomplish?
14. *Transformation*: who did you become? This resolves the internal struggle: old identity dies, new belief system is born.

- Why it works / failure mode: it mirrors how the listener would experience the journey themselves, so they relate to you and trust you, then reach the aha. Phase 5 rebuilds their belief pattern. Failure modes: starting from expert status (the audience can't relate), skipping the internal desire (no bond), and skipping others' results (they assume you're special).

**30-Second Epiphany Bridge**: when time is short, drop the 14 questions but always hit all five phases in one sentence each. The Perfect Webinar uses one full epiphany bridge followed by many short ones to break the remaining false beliefs.

## Key Concepts
- **Epiphany Bridge Script**: the 5-phase, 14-question story template.
- **Backstory**: the starting point that mirrors the listener's current situation.
- **External vs. internal desire**: the visible goal vs. the emotional need underneath it.
- **Old vehicle**: previously tried methods that failed, the wall of frustration.
- **The call**: the trigger that turns "should" into "must."
- **What if (stakes)**: the consequence of failure that creates tension.
- **Opportunity switch (in story)**: the moment the old vehicle is swapped for the new one.
- **Sub-stories**: follow-on case stories chosen to match the listener (a dentist hears the dentist case).

## Mental Models
- Think of the script as a checklist of 14 slots. The depth of each slot is a dial you set by time.
- Use the five-sentence version for ads, hooks, and conversation. Use the full script for webinars and keynotes.
- Pick sub-stories by audience. Tell the result story closest to the listener's own situation.
- Think of Phase 5 as rebuilding the belief pattern, not just reporting a happy ending.

## Anti-patterns
- **Opening from your current success**: the gap is too big, so no relatability or trust.
- **Only external desire**: the story lacks emotional depth and rapport.
- **No villain or stakes**: nothing to root for.
- **Skipping others' results**: the framework looks non-transferable.
- **Answering "what is X?" with a definition**: tell the story instead.

## Worked Example
**Brunson's funnel origin story (full script).**
- *Backstory*: college wrestler, newly engaged to Collette. NCAA rules barred a job, so she worked two jobs.
- *External desire*: make money to support them. *Internal desire*: let his wife quit and become a stay-at-home mom so they could start a family.
- *Old vehicles*: eBay and computer-parts websites, each deepening the debt.
- *Call*: saw people selling how-to info products and filmed a potato-gun DVD.
- *Villain*: Google raised ad costs from about $10/day to more than $50/day to sell a $37 DVD.
- *What if*: quit wrestling or keep his wife in two jobs.
- *Guide*: Mike Filsaime. *Epiphany*: an upsell ("like fries with a Big Mac") that 1 in 3 buyers take.
- *New opportunity*: funnels. How you sell matters more than what you sell.
- *Framework*: funnel frameworks tested across weight loss, dating, MLM, apps, and supplements.
- *Results*: one funnel generated 1.5M+ leads in 6 weeks. Others took startups to 8 figures.
- *Others*: LadyBoss (Brandon and Kaelin Poulin) and Dr. Nissa Holmes's dental practice.
- *Achievement*: thousands of leads a day, millions per month. *Transformation*: his wife retired, they had five kids, and many other entrepreneurs have been freed too.

**30-second version**: wanted money to support my wife → potato-gun DVD killed by Google → Mike Filsaime told me about upsells, and I discovered funnels → built funnel frameworks → made a ton of money and my wife retired to be a stay-at-home mom.

## Key Takeaways
1. Answer all 14 questions in writing for your origin story before you use it anywhere.
2. Start the backstory where your listener is today, not where you are now.
3. State both an external and an internal desire, and pay off both at the end.
4. Make the villain a false belief or a broken market system you can throw stones at.
5. Write a five-sentence, 30-second version and memorize it as your answer to "what do you do?"
6. Keep a bank of sub-stories (others' results) indexed by audience type.

## Connects To
b2-ch07 (Epiphany Bridge principles), b2-ch08 (Hero's Two Journeys, the parent framework), b2-ch10 (four core stories and story inventory), b2-ch04 (opportunity switch), b2-ch11 (Perfect Webinar origin story), b1-ch20 (star story solution), b1-ch04 (Attractive Character backstory).
