# Expert Secrets — Secret 3: The Three Core Markets (or Desires)

## Core Idea
Pick who you serve before you design an offer. Every sales message sells into one of three core desires (health, wealth, relationships), then a submarket, then a niche. Instead of joining a red-ocean niche, create your own category and become its category king. Find your first buyers by fishing for the *frustrated* customers in the red oceans nearby. Includes Steve J. Larson's market selection framework.

## Frameworks Introduced
**Core Market → Submarket → Niche → Your Category**
- When to use: positioning a new expert business or product, or diagnosing why an offer won't sell.
- How:
  1. Choose **one** of the **Three Core Markets/Desires: health, wealth, relationships**. Aim each message at one desire only, because asking prospects to believe two things cuts conversions sharply. If the product doesn't fit a desire, the sales message must. (Gillette sells razors through relationships.)
  2. List the submarkets inside that desire (health → weight loss, nutrition. Wealth → real estate, online business. Relationships → dating, parenting). Pick one using three tests: (a) Will they be excited by your new opportunity or frameworks? (b) Are they **irrationally passionate**? Look for communities, their own vocabulary, events, and established experts or celebrities. Don't be the first celebrity in a market. (c) Are they **willing AND able** to spend money on information? (Gamers were willing but had no credit cards. Engineers had money but wouldn't pay for coaching.)
  3. List every niche in the submarket (for example health › nutrition › keto, health › weight loss › weight loss for couples).
  4. Don't join a niche. **Create a new category** and become its **category king**. Category kings take roughly 70–80% of a category's profits, and followers fight over the other 20–30%.
- Why it works / failure mode: markets move from blue ocean to red ocean as competitors pile in (from *Blue Ocean Strategy*). A new category is a fresh blue ocean. Failure mode: creating offers before you know the market ("you don't feel your own wallet").

**Market Selection Secrets (Steve J. Larson)**:
- **The market is a location, not a person.** A market is where buyers already go to exchange money. Ask *where* your market is and *who* your dream customer is there, not "who is my target market."
- **Fish in red oceans.** Until you own a market, sell to people already gathered in existing submarkets.
- **Three groups in every marketplace**: **Diehard** (logo tattooed on the forehead. You end up in feature wars, and switching them takes an identity shift, so don't target them), **Satisfied** (content but not fanatical. They price-shop you, and switching them needs a big price or value advantage), **Frustrated** (hate their current product and list complaints unprompted. They have the shortest sales cycle and need only to be found, trusted, and given a small amount of education). **Target only the frustrated.**
- **Competitive vs. Complementary positioning**: *Competitive* throws rocks at the existing market ("It's not soap, it's Dove" / "It's not a website, it's a funnel"). *Complementary* adds to it (Sunkist's orange-juice extractor made OJ part of breakfast). Positioning is how people fit you into what they already know.
- Why it works: with correct positioning, even a C/D-level funnel and sales skills rarely fail. ClickFunnels found its fit on its sixth launch by calling out frustrated website owners.

## Key Concepts
- **Three Core Markets/Desires**: health, wealth, relationships. Every purchase aims at one of them.
- **Submarket**: one way of meeting a core desire (real estate, dating).
- **Niche**: a specific approach inside a submarket (flipping houses on eBay).
- **Blue ocean / red ocean**: uncontested vs. shark-filled competitive space.
- **Category king**: the dominant player in a category. Usually the best marketer, not necessarily the first.
- **Irrationally passionate market**: has communities, vocabulary, events, and gurus.
- **Willing and able**: both the desire and the means to buy information.
- **Diehard / Satisfied / Frustrated**: the three buyer groups in any market. Sell to the frustrated.
- **Market positioning**: anchoring your offer to something people already know, either competitively or complementarily.

## Mental Models
- Think of the market as a village marketplace. Carry your fish to where buyers already gather.
- Use the frustrated-buyer signal (they list what they hate without being asked) to qualify leads.
- Use "It's not X, it's Y" when you position competitively against a known category.
- If you're in a feature war, you're selling to a diehard, so walk away.

## Anti-patterns
- **Designing the offer before knowing the market**: every choice becomes a guess.
- **Splitting a message across two desires**: conversions collapse.
- **Being the first guru in a market**: no event culture or buying habits exist yet.
- **Joining an existing niche**: at best you fight over the scraps.
- **Writing sales copy for diehards**: futile and expensive.
- **Entering a market you haven't studied**: the real-estate client who didn't know the market's top 20 gurus was told to consume 20–30 of them first.

## Worked Example
**ClickFunnels' positioning.** Core desire: wealth. Submarket: online business / growing companies. Existing niches, each with a king: landing-page builders, marketing automation, email, split testing. So they didn't compete on features and created a new category, **sales funnels**. Competitive positioning: "It's not a website, it's a funnel," plus copy about "the death of websites." Target: *frustrated* website owners who'd spent heavily for little return. Result: after five failed launches, the sixth took off, and later rivals were left "fighting over the scraps."

## Key Takeaways
1. Write down the single core desire your message serves.
2. Run your submarket through the three tests: excited by your new opportunity, irrationally passionate, willing and able to pay.
3. List every niche in the submarket, then define a new category you can be king of.
4. Find the red oceans where frustrated buyers already gather and write copy for them, not for diehards.
5. Choose competitive ("It's not X, it's Y") or complementary positioning on purpose.
6. Study 20–30 existing experts in the market before you create anything.

## Connects To
b2-ch04 (new opportunity / opportunity switch), b2-ch06 (identity and tribe), b1-ch02 (hook-story-offer), b3 (dream customer, where they congregate, Dream 100), b2-ch12 (Big Domino).
