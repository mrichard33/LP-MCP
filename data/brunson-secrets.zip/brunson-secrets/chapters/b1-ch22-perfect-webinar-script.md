# Dotcom Secrets Secret 22: The Perfect Webinar Script

## Core Idea
Russell's favorite and most-used script—for live and automated webinars, stage selling, VSLs, product launch sequences, and emails. Three sections: **Introduction**, **Content** (one big idea + three secrets that break false beliefs), and **Stack and Close**. For a 90-minute talk: ~15 min intro, ~45 min content, ~30 min stack and close; the ratios hold when compressed to 60 or even 5 minutes (Jamie Cross's five-minute version). This chapter is the summary; Expert Secrets is the deep dive.

## Frameworks Introduced

**Perfect Webinar Script (3 sections)**:
- When to use: Any presentation-tier sale (webinar, stage, VSL, launch) typically $100–$2,000+.
- How:
  - **Introduction**
    1. *Big promise* — the reason they showed up; also the ruler they'll judge you by ("in the next 60 minutes you'll learn how to [X] without [Y]").
    2. *Hook to the end* — a reason to stay (e.g., a live-only transcript link or giveaway).
    3. *Command attention* — close Facebook, silence phone, grab pen and paper; ask for the commitment.
    4. *Qualify yourself* — why you're credible (your story).
    5. *Future pace* — sensory picture of life after they know the secret.
  - **Content** (teach the *what*, not the *how*)
    6. *The one thing* — the single belief (big domino) that, if accepted, makes buying inevitable; tell your origin story of discovering the vehicle.
    7. *Three secrets* — break and rebuild false beliefs about (1) the **vehicle**, (2) **internal** ability, (3) **external** obstacles, each with a story of how you used to believe the same thing.
  - **Stack and Close**
    8. *Transition* — "Let me ask you a question… is it OK if I take 10 minutes to show you a special offer I created to help you implement [X]?"
    9. *The stack* — reveal each component and restack the full list on every slide; final stack slide recaps all, then total value.
    10. *If-all anchoring* — 3–5 "if all this did was [pleasure/pain outcome], would it be worth it?"
    11. *Reveal the real price* — step down: not the total value, not retail, not what they assumed—today's special price.
    12. *Call to action* — click, call, or walk to the back of the room.
- Why it works: The content destroys the specific beliefs blocking purchase; the stack ensures the price is compared against the full offer, not the last bonus.
- Failure mode: Teaching the how (content becomes the product) or presenting bonuses individually so buyers weigh price against the last item only.

**The Stack (from Armand Morin)**: prospects remember only the last thing shown, so every new stack slide re-lists everything so far ("so that means you get X, and also Y, and also Z"). Raised Russell's stage close rate from 5–10% to a consistent 30–50%+.

**Three Secrets / False Belief Patterns**: vehicle belief, internal belief, external belief—break each with a story that gives them the same epiphany you had.

## Key Concepts
- **Big promise** — the ruler for judging the webinar's value.
- **Vehicle** — your unique system/framework (Russell's = funnels).
- **The one thing / big domino** — the single belief that makes all objections fall.
- **What vs. how** — content teaches strategy; the product delivers step-by-step tactics.
- **Stack slide** — cumulative bulleted list of everything in the offer.
- **Price anchor** — total stated value before the price drop.
- **If-all statements** — emotional value-justification questions.
- **Moral obligation to sell** — framing the pitch as service, which removes nervous transitions.

## Mental Models
- Think 15/45/30 (intro/content/close) at any length.
- Use one belief per presentation; if they believe it, they must buy.
- Think of each secret as a story that transfers your epiphany.

## Anti-patterns
- **No big promise**: they judge you on something outside your control.
- **Too much how**: satisfies curiosity, removes the need to buy.
- **Showing bonuses one at a time without restacking**: buyers compare price to one item.
- **Hesitant transition to the pitch**: use the "let me ask you a question" bridge.

## Worked Example
High Ticket Secrets webinar. Big domino: add high-ticket sales to your funnel without personally talking to anyone on the phone. Secret 1 (vehicle): false—info or e-com is the best model; new—one day of high-ticket sales can beat a month of normal products. Secret 2 (internal): false—I must sell on the phone; new—a two-person mini call center closes for you. Secret 3 (external): false—it costs a fortune in traffic; new—about 100 clicks/day is enough. Close: "I won't charge the $11,185 it's worth, or the $4,997 retail, or even the $1,997 you assumed—today it's just [price]."

## Key Takeaways
1. Open with a big promise that sets the ruler, a hook to the end, and a commitment to focus.
2. Build the whole talk around one belief (the vehicle) told via your origin story.
3. Use three secrets to break vehicle, internal, and external false beliefs with stories.
4. Transition with permission, then restack every component on every slide.
5. Anchor with total value and if-all questions, then step the price down to the real price.

## Connects To
b1-ch15 (webinar funnels), b1-ch16 and b1-ch23 (product launch version), b1-ch20 (stack/if-all in VSLs), b1-ch21 (OTO stacking), b2-ch11 (Perfect Webinar framework), b2-ch12 (big domino), b2-ch13 (three secrets), b2-ch14 (stack and closes), b2-ch18 (five-minute Perfect Webinar), b2-ch04 (new opportunity).
