# DotCom Secret 4: The Attractive Character

## Core Idea
Customers come for a result and stay for a relationship. The Attractive Character is the persona you build on purpose from your real life, with backstory, parables, flaws, and polarity. It is the brand applied to every offer on your Value Ladder, and it runs through ads, pages, scripts, and emails. The chapter is an introduction; Expert Secrets goes deeper.

## Frameworks Introduced

**Attractive Character Elements (four)**
1. **Backstory, shared often**: show that you've been where they are now. Dig past surface answers (a chiropractor's "it pays well, Fridays off") to the real origin story.
2. **Parables**: teach each concept with a short story, not facts. Keep a list of parables you can reuse.
3. **Character flaws**: be vulnerable. Nobody relates to someone perfect (Superman needs Kryptonite; Stan Lee's Marvel heroes start as flawed humans).
4. **Polarity**: take stands on hard issues, which splits the audience into those who agree, the neutral, and those who disagree. Neutral is boring. Polarity turns casual fans into die-hard buyers (Howard Stern).
- When to use: when you design your persona and before writing any ad, email, page, or script.
- Why it works / failure mode: you will tire of your backstory long before the market does, so repeat it. The failure modes are posturing about current success and staying bland so nobody is offended. Then no one hates you, but no one knows you either.

**Attractive Character Identities (pick one)**
- **Leader**: has already got the result, shares the audience's backstory, and leads them along the same path.
- **Adventurer**: curious, doesn't have every answer, goes out and brings back discoveries for the audience.
- **Reporter**: hasn't blazed the trail yet and interviews those who have (Larry King, Oprah). Status rises through association. This was Brunson's starting identity and it's the easiest way to start in a new niche.
- **Reluctant Hero**: avoids the spotlight but feels a moral duty to share what they found. This is Brunson's identity now.
- How: pick the one that feels natural. If building the character feels forced, re-examine which identity you chose.

**Attractive Character Storylines (six)**
1. **Loss and Redemption**: you had success, lost it, and came back. Gives hope to followers who are in a loss right now.
2. **Us vs. Them**: "us" does what it takes to succeed and "them" doesn't. Gives fans a rallying cry.
3. **Before and After**: your life before and after the result (weight loss photos, a home before and after money).
4. **Amazing Discovery**: something new you found that helped you and can help them.
5. **Secret Telling**: share a secret you know or heard. Curiosity pulls people in.
6. **Third-Party Testimonial**: tell customer success stories again and again as social proof.

## Key Concepts
- **Attractive Character**: the persona your business communicates through. Attractive means personality, not looks.
- **Brand**: the image and personality applied to your offers (after Jenna Kutcher). The Value Ladder holds the offers and the Attractive Character is the brand on top.
- **Backstory / origin story**: why you do this. The fastest way to build rapport.
- **Parable**: a short story that makes a concept stick, e.g. a potato-gun DVD for "you can sell info products."
- **Polarity**: taking clear stands that attract fans and repel others.
- **Identity**: the archetypal role you take (Leader, Adventurer, Reporter, Reluctant Hero).
- **Audience segmentation by story**: each story you tell attracts the segment that relates to it.

## Mental Models
- Think of every story you tell as a filter. The story decides which segment of the market walks up to buy.
- Use the Reporter identity when you lack credentials. Borrow authority by interviewing people who have it.
- Use a parable instead of an assertion whenever you need a belief to shift (for example, investing vs. buying).
- Think of the Attractive Character as the glue that binds people to the Value Ladder.

## Anti-patterns
- **Posturing and a perfect facade**: it alienates the people you're trying to reach.
- **Neutrality**: when you try to win everyone's vote you reach nobody.
- **Surface-level origin stories**: "it pays well" builds no connection.
- **Telling your backstory once**: the market needs to hear it many times.
- **Teaching facts only**: concepts don't stick without parables.

## Worked Example
**Story-driven audience shift:** when Brunson told his college wrestling story from stage, mostly male athletes bought at the back of the room. When he told the story of his and his wife's fertility struggle, which led to twins, wives, mothers, and families started buying for the first time. The offer was the same; a new part of his character attracted a new segment.

**The "investment" parable (Coach Mark Schultz):** an Olympic champion hands a freshman his highlight tape, asks for his wallet, takes all the cash, and explains that he'd never watch a free tape but will watch one he paid for. He did watch it, over and over, and got better. Brunson tells this story whenever he asks for a purchase, instead of saying "this is an investment."

**The chiropractor's real backstory:** he was on the way to dental school when his wife was injured in a car accident. Painkillers and doctors failed, and a chiropractor relieved her pain within minutes and healed her within weeks. He switched careers to have that kind of impact.

## Key Takeaways
1. Write your real origin story (keep asking "why?" until you get past surface answers) and tell it everywhere, repeatedly.
2. Build a list of parables from your own life and others' lives, one for each belief you need to shift.
3. Share at least one real flaw or vulnerability.
4. Choose two or three stands you're willing to polarize on. Expect haters and accept them.
5. Pick your identity (Leader, Adventurer, Reporter, Reluctant Hero) and use its storylines.
6. Tag your stories to the six storylines so each email or ad has a structure to work from.

## Connects To
b1-ch02 (story in Hook, Story, Offer), b1-ch07 (Follow-Up Funnels deliver the character), b1-ch05 (Funnel Hacking), b2-ch03 through b2-ch05 (Attractive Character in depth, identity, storylines), b2-ch07 (Epiphany Bridge), b3-ch05 (content/publishing).
