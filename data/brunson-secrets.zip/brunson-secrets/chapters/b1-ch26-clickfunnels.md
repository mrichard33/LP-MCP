# Dotcom Secrets Secret 26: ClickFunnels

## Core Idea
Speed of execution is the bottleneck: hand-coding each funnel took Russell's team ~3 months; ClickFunnels (co-founded with Todd Dickerson and Dylan Jones, launched Sept 23, 2014) cuts it to about an hour. The chapter is a process overview, not a tutorial: choose the funnel by price, sketch it, build from templates, customize with sections/rows/elements, plug in hook-story-offer, attach follow-up funnels, launch. Partly product promotion; the durable value is the price-to-funnel selector and build sequence.

## Frameworks Introduced

**Funnel Selection by Price (Value Ladder Tiers)**:
- When to use: Deciding which funnel to build first for a given offer.
- How:
  - **$0** → front-end lead funnels (lead squeeze, survey, summit).
  - **$1–$100** → unboxing funnels (book, cart, challenge).
  - **$100–$2,000** → presentation funnels (VSL, webinar, product launch).
  - **$2,000+** → back-end phone funnels (application).
  - Flex rules: a $1,000 offer can be unboxed; a $100 offer can sit on a lead funnel's thank-you/special-offer page.
- Why it works: Price determines how much trust and persuasion time the buyer needs.
- Failure mode: Over-deliberating—you never know which funnel will win; guess, launch, and audible.

**Funnel Build Process (7 steps)**:
1. **Choose your funnel** (by price tier above).
2. **Sketch your funnel** — answer: which pages? order bump? how many upsells? downsell? hook, story, and offer for each page? price for each offer?
3. **Build in ClickFunnels** — "Add New" → funnel wizard (Collect Emails = lead squeeze; Sell Your Product = unboxing; Host a Webinar = live/auto webinar; or custom). Add/delete steps to match the sketch; pick a template per page (or the 10 core funnel templates from the book's resources page).
4. **Customize with the page editor** — **Sections** (green; header/body/footer containers with own backgrounds) → **Rows** (blue; multi-column, responsive) → **Elements** (orange; 40+ types: headlines, video, order forms, buttons, timers, progress bars, opt-ins, surveys).
5. **Plug in hooks, stories, and offers** — design matters less than these; they're also what you tweak when a page underperforms.
6. **Build follow-up funnels** — map the attractive character's soap opera sequence and Seinfeld emails; create one email per sequence day; connect to the funnel so opt-ins trigger it.
7. **Launch** — drive traffic, track stats.

## Key Concepts
- **Funnel wizard** — guided start by goal (emails, product, webinar, custom).
- **Templates / shared funnels** — prebuilt pages and the book's 10 core funnels.
- **Sections, rows, elements** — the three-level page structure.
- **Mobile responsive** — rows adapt automatically; preview in editor.
- **Follow-up funnel** — email sequence tied to the funnel (b1-ch07).
- **Speed-to-market** — failing costs a week or two instead of 3–6 months.
- **Price tier** — the value-ladder step that dictates funnel type.

## Mental Models
- Think of the software as scaffolding; hook, story, offer is the building.
- Use price as the first filter for funnel type.
- Think "whiteboard first, software second."

## Anti-patterns
- **Building before sketching**: pages sprawl without a plan.
- **Obsessing over design**: conversions come from hook, story, offer.
- **Waiting for the perfect funnel choice**: launch your best guess.
- **Forgetting follow-up**: a funnel without its email sequence leaks buyers.

## Worked Example
A $100–$2,000 course → presentation tier → choose webinar funnel → sketch registration, thank-you (with bump offer), webinar, order form (bump + 1 upsell + downsell), replay → wizard "Host a Webinar" → pick templates → edit sections/rows/elements → insert curiosity headline, Who What Why How thank-you video, Perfect Webinar → five-day soap opera sequence attached → launch with traffic. History: two failed predecessors (click.com, clickfusion.com) cost millions; 150+ hand-coded funnels over years; ClickFunnels reached 100,000+ active members by the second printing.

## Key Takeaways
1. Pick the funnel type from the offer's price tier, then commit.
2. Sketch every page, bump, upsell, downsell, and price before building.
3. Start from templates; customize via sections → rows → elements.
4. Spend your energy on hook, story, and offer, not visuals.
5. Wire the soap opera sequence to the funnel before launch.
6. Launch fast; if it fails, audible (b1-ch28) or try another funnel type.

## Connects To
b1-ch03 (value ladder), b1-ch02 (hook, story, offer), b1-ch05 (funnel hacking), b1-ch07 (follow-up funnels), b1-ch08 through b1-ch17 (the 10 core funnels), b1-ch27 (funnel stacking), b1-ch28 (funnel audibles), b3-ch16 (funnel hub).
