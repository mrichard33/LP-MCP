# DotCom Secret 10: Summit Funnels

## Core Idea
A virtual summit is a free online conference of pre-recorded expert interviews. Guest speakers promote it to their own lists, so their subscribers become your leads. You build a list, influencer relationships, and borrowed authority, and a low-priced All-Access Pass pays for the effort. It needs no ad spend, which makes it good for beginners. This chapter was guest-written by Bailey Richert.

## Frameworks Introduced

**Virtual Summit mechanics (three steps)**
1. **Invitations**: the host invites colleagues in the niche who own lists of your ideal clients. Target about 30 confirmed speakers, and expect to approach more.
2. **Interviews**: pre-record each interview, to be broadcast for a limited window during the event.
3. **Promotions**: speakers promote the summit to their lists, motivated by affiliate commissions and the prestige of being featured.
- Why it works / failure mode: you use other people's traffic (warm, from trusted hosts), and your face appears next to established names on every page. That association transfers authority and starts lasting relationships. The failure mode is neglecting speaker relationships, or running it too long, since engagement drops after three or four days.

**Summit Funnel (three pages)**
1. **Registration page** (long-form): a curiosity headline plus the summit name, topic, dates, and every speaker's name, headshot, site, and interview topic. Speakers expect to be featured, and their fans convert better when they see them.
2. **Special offer page** (an order form in three parts): (a) registration confirmation ("check your inbox"), (b) the All-Access Pass offer with a host video, text, and images, (c) the order form.
   - All-Access Pass: lifetime access to every interview, plus bonuses (extra interviews, transcripts, compiled notes, MP3s).
   - Alternative: offer a next-rung product (e.g., a challenge) and include the replays as a bonus.
   - Price: about $100 or less, a no-brainer first purchase.
3. **Broadcast pages**: sent by email on event days, not shown at signup. Post one day's interviews per page with a countdown timer, about 24 hours per day so all time zones get a chance. Remove each day's videos when the next day posts. After that, the only way to see them is to buy. Run 3 to 4 days.
- After the event: keep selling replays. If you bought ads, sales should cover them. Pay speakers commission on the sales they generate.

## Key Concepts
- **Virtual summit**: a free, time-limited online conference of expert interviews.
- **Host**: the organizer, who is co-branded with every speaker.
- **Guest speaker**: a niche peer with a list of your dream customers.
- **Registration page**: the long-form opt-in featuring every speaker.
- **All-Access Pass**: a paid upgrade for lifetime replay access plus bonuses.
- **Broadcast page**: a daily viewing page with a 24-hour window.
- **Borrowed authority**: credibility gained from appearing beside established experts.
- **Affiliate commission**: the incentive for speakers to promote.

## Mental Models
- Use a summit when you have no list, credibility, or ad budget but can reach people who do.
- Think of the 24-hour takedown as built-in, real urgency for the All-Access Pass.
- Think of speaker outreach as networking with a deliverable. The relationships outlast the event.
- Use the Reporter identity (b1-ch04). Interviewing people is how newcomers borrow status.

## Anti-patterns
- **Summits longer than 3 to 4 days**: engagement collapses.
- **Leaving speakers off the registration page**: they won't promote as hard and their fans won't convert.
- **A high-priced first offer**: keep it at $100 or under to get the first yes.
- **Showing broadcast pages at signup**: this kills the time-limited urgency.

## Worked Example
**The ClickFunnels 30 Day Summit:** Richert pitched Brunson through a ClickFunnels employee who had spoken at her own summit twice. She became project manager. The summit featured 32 Two Comma Club winners explaining how they would restart in 30 days if they lost everything. The special offer page sold a challenge-style offer with the replays as a bonus. It did more than $1M in sales in under two weeks. Her own start was similar: no list, no credibility, no budget, and organic channels that were too slow, until annual summits built her list and network.

## Key Takeaways
1. Recruit about 30 speakers who each own a list of your dream customers. Offer affiliate commissions.
2. Pre-record the interviews and plan 3 to 4 broadcast days with 24-hour viewing windows.
3. Feature every speaker prominently on a long-form, curiosity-led registration page.
4. Offer an All-Access Pass (or a next-rung product with replays as a bonus) for $100 or less right after registration.
5. Email each day's broadcast link, and take videos down on schedule to drive upgrades.
6. Keep selling replays after the event, and look after speaker relationships for future joint ventures.

## Connects To
b1-ch08 (Lead Squeeze Funnels), b1-ch09 (Survey Funnels), b1-ch11 (Book Funnels, which opens the unboxing funnels: free plus shipping, order bump, CPA/ACV), b1-ch13 (Challenge Funnels as the special offer), b1-ch04 (Reporter identity), b3-ch04 (Dream 100 for recruiting speakers), b3-ch08 (affiliate and joint-venture traffic).
