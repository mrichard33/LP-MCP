# Traffic Secrets — Secret #7: Infiltrating the Dream 100 (plus the Section Two "Fill Your Funnel Framework")

## Core Idea
When you have your own show, everyone answers your calls. A platform (podcast, vlog or blog) is the most valuable thing you can offer your Dream 100 because they want exposure. Start one show on one channel, publish daily, document your journey, use it to interview and win over your Dream 100, and never forget that you're renting space on someone else's network. Keep converting show traffic into your list. This row also contains the Section Two opener: the six-step **Fill Your Funnel Framework** for mastering any platform.

## Frameworks Introduced
**Your Own Show as Leverage (the Arsenio Hall lesson)**: Arsenio couldn't get calls returned once his show was gone. A platform opens doors that money and gifts can't.
- When to use: when Dream 100 outreach stalls because you have nothing to offer them.
- How: phones are today's TV (Gary Vaynerchuk). Facebook is the talk show, podcasts are radio, YouTube is the sitcom, Instagram is reality TV, and blogs are newspapers. Pick one and start your show for free.
- Failure mode: a show is *rented* traffic. If Arsenio had pushed viewers to an opt-in ("top 100 jokes free"), he'd have kept a million-person list after cancellation.

**Two Channels Only: Primary Distribution (email) + Primary Show**: don't launch everywhere.
- How: email is the only list you truly own. Use it to push every episode right away, and treat viral or algorithmic reach as "gravy." Choose the show channel by talent and habit: writers start a blog, on-camera people a vlog (YouTube), people with a radio voice or camera shyness a podcast. If unsure, pick the platform you consume most. Expanding to other channels comes later (Conversation Domination, b3-ch15).

**The Four Steps to a Successful Show**:
1. **Publish daily for at least a year.** Consistency is how you find your voice and how your audience finds you. Brunson's first ~45 episodes were weak, but nobody was listening yet. Don't check stats early. Seth Godin only guests on shows with 100+ episodes ("endure long enough to get noticed," Nathan Barry).
2. **Document, Don't Create (Gary Vaynerchuk).** Share your process as you chase the same result your audience wants. Say "here's what I'm finding," not "you should." Name the big question your show answers in its intro. Gary's cadence: at least 1 long-form piece per week plus 6–7 stories per day.
3. **Test your material (the comedian's 10 jokes, Dean Graziosi).** Publish, watch what lands, keep the winners, and replace the losers. Books, webinars and keynotes are built from material tested on the show (DotCom Secrets was tested for about a decade; Expert Secrets for about 2 years).
4. **Introduce your Dream 100.** Early episodes tell your origin story, since bingers start at episode 1. Then interview Dream 100 members. You give them a platform, dig your well, promote their episode, and buy ads to their audiences even if they don't share it.

**One Yes Unlocks the Club (the "Never Been Kissed" principle)**: you only need one "cool kid" to vouch for you.
- How: keep asking through the no's. After the first yes, ask for referrals, then go back to earlier no's with your list of who's in.
- Why it works: markets run like old boys' clubs, and social proof converts no's into yes's.

**Fill Your Funnel Framework (the six-step pattern for any platform)**:
1. **Understand the platform's history and goal.** Every platform optimizes for user experience. Align with it rather than hacking the algorithm, because spammer loopholes get closed.
2. **Find and model your Dream 100 on that platform.** Keep a platform-specific list. Spend **10 minutes per day** noting what they post, how they drive engagement and what ads they run; engage on their posts; model the working pattern.
3. **Identify the publishing strategy and create your publishing plan** for each format (e.g., IG Stories, feed, Live, IGTV).
4. **Work Your Way In** to get organic exposure to Dream 100 audiences.
5. **Buy Your Way In** with ads targeting their followers.
6. **Fill your funnel**: convert all attention into owned traffic, sell front-end offers, and run follow-up funnels.

**Modeling vs. Copying / Pattern Interrupts**: funnel hacking is modeling, not copying. Study 100+ posts, ads and quotes per day for inspiration. When a pattern interrupt becomes the pattern, it gets less effective (not dead). Start by modeling the current pattern, then test the next interrupt. Examples: meme videos with headlines above and below, early on; black-and-white text quotes on Instagram.

## Key Concepts
- **Platform leverage**: your audience is the currency Dream 100 members want.
- **Rented vs. owned**: shows and followers are rented; email is owned.
- **Primary distribution channel**: email, used to push each new episode.
- **Primary show channel**: the one blog, vlog or podcast you commit to.
- **Document, Don't Create**: content as a record of your real process.
- **Finding your voice**: comes only from publishing volume.
- **Binge path**: new fans consume from episode 1 and often buy high-ticket before finishing.
- **Pattern interrupt**: a novel format that wins until everyone copies it.

## Mental Models
- Think of your phone as the 1965 TV, and each app as a network where you can be the star.
- Use "one show + email" until that show works; expand only afterward.
- Think of early episodes as practice nobody hears. Volume beats polish.
- Use guest interviews as both content and Dream 100 relationship-building.

## Anti-patterns
- **Starting shows on every channel at once**: none of them grows.
- **Relying on algorithm reach**: reach collapses when the algorithm changes. Push every episode with email.
- **Checking stats early and quitting**.
- **Perfectionism / "one at-bat" thinking**: it kills your output.
- **Copying instead of modeling**: you inherit a pattern that's already worn out.
- **Stopping at the first no's**: you only need one yes.

## Worked Example
Tellman Knutson's summit had no list and no platform. He called his Dream 100 and heard 48 no's in a row (including Brunson). #49 said yes and referred 3 more, who all said yes. He then re-approached the earlier no's with the growing yes list. The next 30 in a row said yes. Result: a 100,000+ person list in a few months and $800K+ in first-year sales. Brunson's "Marketing in Your Car" podcast launched in 2013 in the middle of a crisis (layoffs, $250K owed to the IRS), recorded during a 10-minute commute. About 3 years later it had tens of thousands of listeners per episode and was the main source of his top coaching and mastermind clients.

## Key Takeaways
1. Pick ONE show channel that fits your talent (blog, vlog or podcast) and use email as distribution.
2. Commit to publishing daily for 12 months and ignore stats for the first few months.
3. Document your pursuit of the result your audience wants, and state the show's big question in the intro.
4. After origin-story episodes, invite Dream 100 guests and promote each episode to their audience (organically or with ads).
5. Keep asking until one yes, then use referrals and social proof to turn no's around.
6. Every episode gets a CTA into a list-building funnel.
7. For any new platform, run the six-step Fill Your Funnel Framework, including 10 minutes per day of Dream 100 modeling.

## Connects To
b3-ch02 (Dream 100), b3-ch04 (Work/Buy Your Way In, Dig Your Well), b3-ch05 (Traffic You Own), b3-ch08 (organic), b3-ch09 (paid), b3-ch10 (Instagram), b3-ch11 (Facebook), b3-ch12 (Google), b3-ch13 (YouTube), b3-ch15 (Conversation Domination), b1-ch04 (Attractive Character), b1-ch05 (funnel hacking), b2-ch01 (finding your voice).
