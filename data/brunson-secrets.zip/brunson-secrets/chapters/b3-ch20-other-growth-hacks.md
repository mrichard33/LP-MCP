# Traffic Secrets — Secret 20: Other Growth Hacks (and Conclusion: Tying It All Back Together)

## Core Idea
Small "butterfly" changes built into your signup flow, such as refer-a-friend incentives, share-to-unlock rewards, and branded badges, can turn every customer into a traffic source and compound into huge results. The conclusion ties the trilogy together: traffic (this book) only works on top of a sound funnel (Dotcom Secrets) and a converting offer (Expert Secrets), applied one platform at a time.

## Frameworks Introduced

**Butterfly Marketing (Mike Filsaime)**
- Formulation: tiny changes inside your funnels, especially ones that get buyers to refer others, can compound virally into outsized results (the butterfly effect).
- When to use: when auditing any signup or upsell flow, yours or one you are funnel-hacking.
- Why it works / failure mode: every referral mechanic multiplies traffic you have already paid for. Most tests produce small gains, so keep testing to find the rare outsized winner.

**Viral "copulation rate" (Mark Joyner; the viral coefficient)**
- Formulation: the average number of new people each new user brings in. Below 1, growth dies. Exactly 1, it flatlines. Above 1, it is truly viral until saturation.
- Brunson's only >1 funnel: an NDA-gated front end for a network-marketing launch that gave 5 invite codes plus 5 more after 5 referrals, modeled on Gmail's invite scarcity (invites resold on eBay for $100+). It signed up 1.6M people in 6 weeks at about 3 new signups per joiner, then stalled when the company delayed launch by about 9 months.

**Three modeled growth hacks (source → ClickFunnels version)**
1. **Dropbox hack** (extra storage for sharing on social): ClickFunnels capped new accounts at 20 funnels and doubled it to 40 for referring users via their affiliate link.
2. **Facebook hack** (import contacts, invite non-members): after webinar registration, a **tell-a-friend page**. Refer 5 friends to the webinar and get a best-selling product free. About 20%+ of each webinar's registrations came from these referrals at no cost.
3. **Hotmail hack** ("P.S. I love you. Get your free email at Hotmail" footer, 12M users in 18 months): a **"This page made with ClickFunnels" badge** on every member page, on by default, carrying the page owner's affiliate link. More than 10,000 members and over $1M a month in recurring revenue (more than $12M a year).

**Conclusion: the 5-step "what now" plan**
1. Decide who you want to serve and know them better than they know themselves.
2. Choose your first publishing platform, usually the one you already use most, because you speak its native language.
3. Build your Dream 100 on that platform.
4. Dig your well: serve your Dream 100 and work your way in.
5. At the same time, learn how to buy your way in on that platform.
- Keep 100% of your focus there until the funnel reaches the **Two Comma Club** ($1M+). Then add a second platform, then a third, reinvesting a large share of profits into ads, and work toward Conversation Domination.
- **Diagnosis across the trilogy**: if traffic arrives but doesn't convert, you have either a funnel-strategy problem (Dotcom Secrets) or a conversion/story problem (Expert Secrets).
- **Daily "give yourself a raise" questions**: Who in my Dream 100 can I connect with today? What new integration opportunities exist? Who can I add to the Dream 100? How can I get them to become affiliates, and to promote more often?

## Key Concepts
- **Butterfly marketing**: small funnel tweaks with compounding effects.
- **Copulation rate / viral coefficient**: referrals per user, and >1 means true virality.
- **Saturation**: viral growth always slows eventually.
- **Share-to-unlock**: a product capability gated behind referrals.
- **Tell-a-friend page**: a post-registration referral step with a gift incentive.
- **Default-on badge**: a branded, affiliate-linked footer on user-generated pages.
- **Two Comma Club**: a funnel that has made $1M, the gate for adding platforms.
- **Traffic as lifeblood**: consistent lead flow is what keeps a business healthy.

## Mental Models
- Think of every user's output (pages, emails, invites) as ad inventory you can brand.
- Look at other companies' signup flows the way a funnel hacker would, then model and test.
- Use the three-book diagnosis: no traffic → Traffic Secrets; traffic but a weak funnel path → Dotcom Secrets; visitors who don't convert → Expert Secrets.

## Anti-patterns
- **Building viral momentum you can't fulfill**: the 1.6M-signup funnel died waiting on a delayed launch.
- **Expecting sustained virality**: saturation always arrives. Treat referral hacks as multipliers, not engines.
- **Adding platforms before $1M on the first**: spreads focus too thin.
- **Treating the book as one read**: it is meant to be a playbook you come back to.

## Worked Example
**ClickFunnels badge economics**: one default-on footer badge ("This page made with ClickFunnels"), linked to each member's affiliate ID and switchable off by the member, produced more than 10,000 members over about 5 years and more than $1M a month in recurring revenue. It combines the Hotmail footer with the Affiliate Army (every member is an affiliate).

## Key Takeaways
1. Add at least one referral mechanic to every signup flow: a share-to-unlock feature, a tell-a-friend gift, or a branded badge.
2. Make every customer an affiliate automatically so referral hacks pay users as well as you.
3. Track referrals per user, and only expect true virality for short bursts with scarce, invite-gated offers.
4. Run the conclusion plan: avatar → one platform → Dream 100 → work in → buy in, until the funnel reaches $1M, then layer the next platform.
5. Ask "How can I give myself a raise today?" every day, and use all three books to answer it.

## Connects To
b3-ch18 (Affiliate Army, since the badge uses affiliate links), b3-ch17 (integrations), b3-ch15 (Conversation Domination), b3-ch14 (framework for any platform), b3-ch01 (dream customer), b3-ch02 (Dream 100), b3-ch04 (work/buy your way in), b1-ch27 (funnel stacking), b1-ch03 (value ladder), b2 (conversion, Perfect Webinar).
