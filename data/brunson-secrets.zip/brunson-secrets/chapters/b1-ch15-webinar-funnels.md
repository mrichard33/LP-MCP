# Dotcom Secrets Secret 15: Webinar Funnels

## Core Idea
A webinar funnel turns one proven sales presentation into thousands of simultaneous "one-on-one" pitches: register on curiosity, warm up on the thank-you page, sell live with the Perfect Webinar, and recover the no-shows with a deadline replay. Master it live first; only automate the version that has already converted best.

## Frameworks Introduced

**Live Webinar Funnel (5 pages)**: Registration → Thank-You → Webinar Room → Order Form → Replay.
- When to use: Selling a mid-ticket offer (roughly $100–$2,000, the presentation tier of the value ladder) that needs belief-shifting before purchase; also for launching a new offer or company (ClickFunnels grew on this).
- How:
  1. **Registration page** — curiosity headline only (Secret 18 templates); no origin story. State the start time so they can calendar it; the entire page pushes one "Register my seat" button → pop-up email capture → soap opera sequence starts.
  2. **Thank-you page** — goal is show-up and relationship. Video using the Who, What, Why, How script (who you are, what they'll learn, why it matters, how to add it to their calendar). Optionally offer a low-ticket book/cart funnel that *complements* the webinar offer to liquidate ad spend.
  3. **Webinar room** — hosted in GoToWebinar or Zoom (integrated with ClickFunnels pages); deliver the Perfect Webinar script slide by slide.
  4. **Order form** — recap the offer and let them buy; do *not* resell. Add order bumps, OTOs/downsells, offer walls, links to phone funnels.
  5. **Replay page** — recording up for a 48–72 hour countdown; follow-up emails tell them what they missed and when it disappears.
- Why it works: Scale, not close rate. A presenter who closes less than a great salesperson still wins because 9,000 people (or 30,000 monthly viewers) hear the pitch at once.
- Failure mode: Automating an unproven presentation — an auto-webinar only multiplies a pitch that already works.

**Automated Webinar Funnel (variation)**: Registration → Presentation page → Order form, all inside ClickFunnels, no external webinar software.
- When to use: After a year (or enough reps) of live webinars has produced a best-converting recording.
- How: Pre-record the winning live presentation; register people for a session starting "in a few minutes" or a future date using the same curiosity hook; send them straight to a replay-style presentation page; run expiring-access email sequences like the live replay emails.

**Thank-Page Ad-Cost Recoup**: sell a complementary low-ticket offer between registration and webinar.
- When to use: Any paid-traffic webinar.
- How: Pitch it as preparation for the webinar; make sure it creates *more* need for the webinar offer, never substitutes for it.

## Key Concepts
- **Registration page** — pure hook page; curiosity drives signups, answers kill them.
- **Soap opera sequence** — indoctrination emails that warm registrants before the presentation (see b1-ch07).
- **Show-up problem** — about 80% of registrants will not attend live no matter what.
- **Replay deadline** — 48–72 hour window that manufactures urgency for the no-shows.
- **Cannibalization** — a thank-page offer that competes with the webinar offer and steals its sales.
- **Resell mistake** — re-pitching on the order form after the presentation already closed them.
- **Live-first rule** — keep running live webinars until the presentation is mastered.
- **Presentation tier** — the value-ladder step where webinars, VSLs, and product launches live.

## Mental Models
- Think of a webinar as a stage talk you can give to thousands at once, every day.
- Use the thank-you page as a relationship and cash-flow page, not a dead end.
- Think of the live webinar as the lab and the auto-webinar as the factory.
- Use the order form as a checkout, not a second sales letter.

## Anti-patterns
- **Telling your story on the registration page**: it lowers curiosity; save story for the thank-you page and webinar.
- **Thank-page offer that competes with the webinar offer**: cannibalizes webinar sales.
- **Reselling on the order form**: consistently hurts conversions; just recap and let them buy.
- **Evergreen replay with no deadline**: the 80% who missed it never get around to watching.
- **Going automated too early**: automation of an unmastered pitch just scales failure.

## Worked Example
Russell's 10X stage presentation (Perfect Webinar script, ~90 minutes, 9,000 attendees) sold a $2,997 course bundled with a year of ClickFunnels: $3.2M from one talk. The same presentation ran as live and automated webinars online, seen 30,000+ times per month. The original ClickFunnels registration page used an odd image, a stated start time, one button, and a question-raising headline about a "weird niche funnel" making $17,947/day that you could "ethically knock off in less than 10 minutes." In year one Russell ran 1–3 live webinars per day before switching to automated.

## Key Takeaways
1. Build the registration page around one curiosity headline and one button; give no answers.
2. Put a Who, What, Why, How video on the thank-you page and optionally a complementary low-ticket offer to recoup ad spend.
3. Deliver the Perfect Webinar script (b1-ch22) live; practice until it converts consistently.
4. On the order form, recap and add bumps/upsells—do not re-pitch.
5. Run a 48–72 hour replay with deadline emails to capture the ~80% who don't show.
6. Automate only your best-converting live recording.

## Connects To
b1-ch07 (soap opera sequence), b1-ch18 (curiosity headlines), b1-ch19 (Who What Why How), b1-ch22 (Perfect Webinar script), b1-ch16 (product launch variant), b1-ch27 (webinar → application stacking), b1-ch28 (webinar benchmarks), b2-ch11 (Perfect Webinar framework), b2-ch16 (testing live), b3-ch09 (paid ads to fill it).
