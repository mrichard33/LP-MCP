# DotCom Secret 14: Video Sales Letter Funnels

## Core Idea
A video sales letter (VSL) funnel puts a 20 to 30 minute scripted presentation in front of the order form, so perceived value is built before the price appears. It is the entry-level presentation funnel for offers up to about $100 that need explaining or belief-breaking, and it also suits memberships and continuity. The words of the presentation matter more than the video style. This short chapter also opens the "presentation funnels" family.

## Frameworks Introduced

**Presentation Funnels (family overview)**
- Purpose: as price rises, perceived value must rise with it. The presentation teaches people about their problem, breaks their false beliefs, discounts other solutions, and gets action now. It can take cold traffic to hot in minutes, days, or weeks.
- Which presentation funnel fits:
| Funnel | Length / delivery | Price range |
|---|---|---|
| Video Sales Letter | 20 to 30 min video | Low ticket up to about $100; memberships and continuity |
| Webinar | 60 to 120 min, live or automated | $100 to $2,000 |
| Product Launch | Dripped over days or weeks | $100 to $2,000, new product with anticipation |
- All three use the Perfect Webinar script (in depth in Expert Secrets; a simplified version appears in b1-ch22).

**VSL Funnel pages**
1. **Sales page**
   - **No order form at the top.** Everything above the fold exists to get the video watched. The curiosity headline's only job is to get a play.
   - **Video script**: Star, Story, Solution (b1-ch20) or the Perfect Webinar (b1-ch22). Grab attention, break false beliefs, make the offer irresistible.
   - **Video spoiler box** below the video: "In today's free presentation..." followed by four blocks, one for each of the three secrets in the Perfect Webinar and one hinting at what comes next (the call to action). Its goal is to push people back into the video.
   - **Call-to-action section**: an order button that is either hidden until the call-to-action moment in the video or visible throughout. Results are mixed, so split-test it for your traffic.
2. **Upsell pages**: the same as book or cart funnels. Info products get the next logical thing; physical products get more of the same at a discount.
3. **Thank-you page**: an offer wall for physical products, or an invitation to the next Value Ladder funnel for info products.
- When to use: when the offer needs more explaining or belief-shifting than a book or cart page can give before the price.
- Why it works / failure mode: the viewer can't scroll ahead to the price and hears every argument in the designed order. The failure mode is spending on production style (whiteboard animation, text-on-screen, talking head) while the script is weak.

## Key Concepts
- **Video sales letter (VSL)**: a sales letter delivered as a video, originally on-screen text read aloud line by line.
- **Presentation funnel**: a funnel that uses a long-form presentation to justify higher prices.
- **Perceived value before price**: why the order form is moved down or hidden.
- **Video spoiler box**: four teaser bullets under the video that drive viewing.
- **Delayed CTA / hidden button**: the order button appears at the pitch moment. Test it.
- **Controlled sequence**: the viewer receives arguments in the order you set, with no skipping ahead.
- **Doodle / whiteboard VSL**: a hand-drawn style pioneered by Vince Palko's team.

## Mental Models
- Think of the VSL as a long-form sales letter where the reader can't skip to the price.
- The script matters more than the production. How you present is secondary to what you say.
- Pick presentation length by price: about 20 to 30 minutes up to $100, 60 to 120 minutes for $100 to $2,000.
- Use a VSL instead of a book or cart page when false beliefs block the purchase.

## Anti-patterns
- **Showing the price or order form before value is built**: it pushes people away.
- **Using a VSL above about $100**: move to a webinar or product launch.
- **Polishing video style instead of the script**.
- **Assuming the hidden vs. visible button question has one right answer**: test it.

## Worked Example
**The first VSL Brunson saw (the day after Christmas, about a decade earlier):** a page with only a headline and a video. The video showed the sales letter's text one sentence at a time with a voiceover reading it. With no way to scroll to the price, he watched all 30 minutes. At the call to action, an add-to-cart button appeared under the video. The format later evolved into hand-drawn videos and talking-head presentations by the Attractive Character.

**Page build:** curiosity headline, then the VSL (Star, Story, Solution), then the spoiler box ("In today's free presentation you'll discover: Secret 1..., Secret 2..., Secret 3..., and what's next..."), then the order button (hidden or visible, tested), then upsells, then a thank-you page leading to the next funnel.

## Key Takeaways
1. Use a VSL funnel for offers up to about $100 that need explaining, and for memberships or continuity.
2. Keep the order form off the top. The headline's only job is a play.
3. Script with Star, Story, Solution or the Perfect Webinar, and put your effort into words, not visuals.
4. Add a four-block spoiler box tied to the three secrets and the call to action.
5. Split-test hiding the order button until the pitch against showing it throughout.
6. Reuse book or cart upsell rules and the matching thank-you page (offer wall or next funnel).

## Connects To
b1-ch11 (Book Funnels, info upsells), b1-ch12 (Cart Funnels, physical upsells and offer wall), b1-ch15 (Webinar Funnels), b1-ch16 (Product Launch Funnels), b1-ch18 (Curiosity-Based Headlines), b1-ch20 (Star, Story, Solution), b1-ch22 (Perfect Webinar script), b2-ch09 through b2-ch11 (Perfect Webinar in depth).
