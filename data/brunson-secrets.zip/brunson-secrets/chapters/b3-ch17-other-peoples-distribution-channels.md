# Traffic Secrets — Secret 17: Other People's Distribution Channels

## Core Idea
Every Dream 100 member owns a distribution channel: an email list, a Messenger or push list, a buyer list, a group, a blog. Your job is to plug your offers into those channels, first by buying one-off placements, then by **Integration Marketing**, which embeds you permanently in their sales process.

## Frameworks Introduced

**Shark Tank Distribution Lens**
- Formulation: sharks (Daymond John in retail apparel, Lori Greiner on QVC and with retailers, Mark Cuban in media) don't have a "Midas touch." They bite on deals they can plug into distribution they already own.
- When to use: choosing investments, partners, or products. Brunson only takes projects where he already knows the channel (whose list to rent, who can rank or buy traffic).

**Email Solo Ad buying process**
- How: (1) Find solo publishers on your Dream 100, or search "[niche] email advertising" or "[niche] online media kit." (2) **Join their list for a few weeks first**, and skip anyone who beats their list with promotions. (3) Ask for click reports from their last 5–10 mailings. (4) Reverse-engineer: expected clicks × your landing-page conversion × revenue gives the most you should pay. Negotiate toward that, because "suckers pay rate card." (5) Supply the creative, ideally written as the publisher endorsing your page, and have *them* send it from *their* servers. (6) Use drops for fast split tests.
- Why it works / failure mode: a relationship list with fewer clicks beats a bigger, burned list ("not all clicks are created equal"). Clicks arrive fast, most within 12 hours and the rest by 36–48, so you can burn $5K in a day that would have lasted weeks on Facebook. Avoid sponsorship (embedded) ads, which Brunson rarely got profitable. Buy full solos only.

**Integration Marketing (Mark Joyner)**
- Formulation: rather than buying a single blast, build your offer into the partner's ongoing process, e.g. your email goes to every new lead on day 3 of their sequence.
- How: set it up once and get new leads every day. Options include day-N autoresponder slots, blog pop-ups, exit pops, and "before-you-need-us" partners (for ClickFunnels: domain registrars, logo designers, business-license services that introduce ClickFunnels after purchase).
- Why it works: your growth compounds with the partner's growth, with no repeat effort.

## Key Concepts
- **Distribution channel**: any audience someone owns and can direct.
- **Solo ad**: an entire email devoted to your offer, sent by the list owner.
- **Media kit**: a publisher's rates and audience data.
- **Rate card**: the published price, which is negotiable.
- **Messenger and desktop-push buys**: an emerging market (as of 2020). Messages must be low-promo, but open and click rates are very high.
- **Co-op direct mail via mailing house**: the partner sends their buyer addresses to a secure mail house that mails your pre-approved postcard or letter, so you never see the list.
- **AdSense replacement**: test a site's placements via GDN, and if they convert, pay the owner directly to swap the AdSense block for your banner.
- **"Give myself a raise"**: Brunson's daily question, since each new channel is a pay raise.

## Mental Models
- Think of your Dream 100 as a set of pipes. Your job is to find each pipe and connect your funnel to it.
- Pay for clicks and results, not list size. Model the price from click history.
- Use integration over one-off buys whenever a partner has steady lead flow, because it compounds.

## Anti-patterns
- **Sending your ad to a list without joining it first**: you can't judge list health.
- **Accepting a list file to mail yourself**: a scam, so run.
- **Paying by list size or rate card**: overpays for weak lists.
- **Buying sponsorship blurbs**: rarely profitable.
- **Dumping an untested funnel on a big solo drop**: the budget disappears in hours.

## Worked Example
**Integration math**: a partner adds 1,000 new leads a day. One deal puts your email at day 3 of their sequence, so 1,000 new people see your message every day indefinitely, and your volume grows with theirs. **Channel stack Brunson buys from Dream 100 partners**: solo emails, postcards to buyer lists via a mailing house, text blasts, sponsored posts in Facebook and LinkedIn groups, forum promotions and banners, blog banners that replace AdSense, and paid exit pops on partner sites.

## Key Takeaways
1. List the distribution channel each Dream 100 member owns.
2. Before buying a solo, join the list for weeks, get click history from 5–10 mailings, and price from your own conversion numbers.
3. Have the publisher send endorsed creative from their own servers, and use drops to split-test landing pages.
4. Branch out to Messenger, push, direct mail (via a mailing house), SMS, groups, and banners.
5. Turn your best one-off buys into permanent integrations (autoresponder slot, pop-up, exit pop, post-purchase referral).
6. Ask every morning, "How can I give myself a raise today?"

## Connects To
b3-ch02 (Dream 100), b3-ch04 (buy your way in), b3-ch05 (traffic you own), b3-ch07 (infiltrating the Dream 100), b3-ch09 (GDN testing), b3-ch12 (buying ads on ranked pages), b3-ch18 (affiliates, a commission-based version of the same idea), b3-ch19 (cold solo ads need a bridge).
