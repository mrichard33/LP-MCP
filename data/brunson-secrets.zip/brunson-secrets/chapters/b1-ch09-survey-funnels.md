# DotCom Secret 9: Survey Funnels

## Core Idea
A quiz engages visitors, segments them with one "bucket question," and sends each segment to a customized opt-in, results page, and follow-up sequence while selling the same core product. Use it when different types of people would each benefit from your offer in a different way. This is a short chapter.

## Frameworks Introduced

**Survey Funnel (three pages)**
1. **Survey page**
   - Offer: "Take this short quiz and I'll tell you ___."
   - Ask several engaging questions. Only one of them, the **bucket question**, decides where the person ends up.
2. **Squeeze page**: a "calculating your results" step (optional, but it lifted conversions), then an email opt-in for a result matched to their bucket, such as a case study from their own industry. Tag each lead into a bucket-specific Soap Opera Sequence.
3. **Results page**: shows the customized case study or story, then makes the offer. It can be a video, a custom PDF, or text. The customization matters more than the format.
- When to use: when your market has several segments (business types, symptoms, skill levels) that need different messages for the same product.
- Why it works / failure mode: the sales message feels written for each person's problem. The more you customize each results page and follow-up sequence per bucket, the higher conversions go. The failure mode is collecting answers and then showing everyone the same pitch.

**Six-Question Survey Template (the common pattern in hacked surveys)**
1. Self-identifying (gender, age, etc.)
2. Self-identifying on the subject ("Do you have a funnel?" "Have you tried to lose weight before?")
3. Self-declared skill level (revenue so far, knowledge of the topic)
4. Self-declared biggest challenge ("I struggle most with traffic" / "with carbs")
5. Educate and clarify ("People who answered X usually suffer from one of these three. Which is yours?")
6. A surprising, curiosity-based question ("Wait, do you drink water first thing in the morning?")
- One of these becomes the bucket question. It doesn't have to be the first. ClickFunnels put it first, asking business type, with nine options each mapped to its own case study.

## Key Concepts
- **Survey / quiz funnel**: a lead funnel that segments through questions before the opt-in.
- **Bucket question**: the single question whose answer picks the landing page, results page, and follow-up (the term comes from Ryan Levesque's book *Ask*).
- **Calculating page**: an interstitial that suggests results are being computed. It raises conversions.
- **Results page**: the customized payoff plus the offer.
- **Bucket-specific Soap Opera Sequence**: follow-up written for each segment.
- **Engagement questions**: non-bucket questions that build commitment and curiosity.

## Mental Models
- Think of a quiz as a sorting hat. Same product, different story per bucket.
- Use a survey funnel when one-size-fits-all copy underperforms across clearly different buyer types.
- Think of each extra layer of customization (results page, emails) as a conversion lever.

## Anti-patterns
- **Too many buckets without matching content**: segmentation only pays off if each bucket gets its own message.
- **Treating every question as critical**: design around one bucket question and let the rest engage.
- **A generic results page**: this wastes the data you collected.

## Worked Example
**FuzzyYellowBalls tennis serve quiz:** the hook asked whether you can add 10 to 15 mph to your serve overnight by eliminating your number one "serve killer." A series of questions followed, then a calculating page: "We've pinpointed the serve killer costing you 10 to 15 mph." Opt in for a free video fixing it. The sales page then addressed that exact problem. Retaking the quiz with different answers led to different sales messages for the same program.

**ClickFunnels survey:** the bucket question was "What type of business do you own?" with nine options. After a calculating page, the opt-in offered a free case study from their industry. The results page showed that case study and the offer, and each lead went into an industry-specific Soap Opera Sequence.

## Key Takeaways
1. Decide your bucket question first, since it defines your segments.
2. Build the quiz around it using the six-question template to engage people.
3. Add a "calculating results" step before the opt-in.
4. Create one results page and one Soap Opera Sequence per bucket.
5. Offer a bucket-specific lead magnet (case study, video, PDF) in exchange for the email.

## Connects To
b1-ch08 (Lead Squeeze Funnels), b1-ch10 (Summit Funnels), b1-ch07 (segmented Soap Opera Sequences), b1-ch06 (qualify subscribers), b1-ch01 (dream customer segments), b3-ch01 (dream customer targeting).
