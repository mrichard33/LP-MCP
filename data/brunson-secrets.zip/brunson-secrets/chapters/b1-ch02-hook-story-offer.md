# DotCom Secret 2: Hook, Story, Offer

## Core Idea
Every step in a funnel has three parts: a hook that grabs attention, a story that raises perceived value and builds trust, and an offer that makes the price feel small. That covers every ad, email, landing page, upsell, webinar, and call. When something isn't converting, one of the three is broken.

## Frameworks Introduced

**Hook, Story, Offer**
- **Hook**: a headline, image, or video placed where your dream customer congregates. It holds attention just long enough for them to hear the story. (The first edition called these "curiosity-based interrupts," after checkout-aisle tabloid headlines.)
- **Story**: builds rapport, shows why you are uniquely qualified, breaks false beliefs, and raises the perceived value of each item in the offer.
- **Offer**: the product restructured so it is (1) higher in perceived value and (2) unique to you, available only inside this offer.
- When to use: at every funnel step, and as the first diagnostic question when anything underperforms.
- How: build in reverse order. Offer first, then the story that raises its value, then many hooks that point at the story.
- Why it works / failure mode: price resistance means low perceived value, not a lack of money. A $10K pair of shoes sounds expensive and a $10K Ferrari sounds cheap. The failure mode is listing features without a story, or using a single hook and giving up when it flops.

**The Irresistible Offer (Offer Stack) build**
1. Name what you sell. Physical products, info products, and services are all commodities if the buyer can get the same result elsewhere.
2. Whiteboard session: ask what else you could give them to help guarantee their success. Write down every idea, however crazy.
3. Set your non-negotiables and cross off anything you won't deliver.
4. Stack what's left into one named offer that nobody else can sell.
5. Aim for total stack value of at least 10x the price ($100 offer worth $1,000 or more; $1,000 offer worth $10,000 or more).
- Why it works: there are two ways to be the lowest-price product in your market. You can cut price and margin, or you can raise value until the real price feels cheap. Only the second leaves you money for ads, a good team, and good service.

**Hook generation from one story**
- How: take one core story and list every angle it offers: a press clip, before and after photos, you with the product, you with clients, video of you telling it, emotional images, and a headline for each twist in the story. Put out dozens of hooks and keep the ones that land.

## Key Concepts
- **Commodity**: anything the customer can buy or get the same result from somewhere else. It pushes you into a price war.
- **Offer stack**: the itemized list of everything in the offer with a value on each, adding up to a large total.
- **10x value rule**: stated total value should be at least ten times the asking price.
- **Perceived value**: what the buyer believes the offer is worth. Stories and bonuses raise it.
- **Non-negotiables**: brainstormed offer items you refuse to deliver.
- **Hook**: something that grabs attention but gives no value on its own. Each story can support dozens of them.
- **Story selling**: telling the backstory behind the offer so each element feels more valuable and you become the trusted guide.
- **Schemer**: early ad agencies' name for the person who invented offers. Claude Hopkins earned $52K a year in 1907 doing this.

## Mental Models
- Think of every price objection as a value problem. Add value, don't cut price.
- Use Hook, Story, Offer as a three-point diagnostic. If there are no clicks, fix the hook. If there are clicks but no trust, fix the story. If there is trust but no buy, fix the offer.
- Think of offer creation as a recurring job, the most important one you have as an owner. Every ad, email, and Value Ladder rung needs a new offer.
- Use Dan Kennedy's rule: being the second-cheapest has no strategic advantage, but being the most expensive does.

## Anti-patterns
- **Competing on price**: margins shrink, you can't afford ads or a good team, and customers get worse service.
- **Selling the bare product**: a 14-day free trial is not an offer. Wrap it.
- **A feature list without a story**: listing items doesn't raise perceived value. The story behind them does.
- **Launching one hook**: you can't predict which hook will land, so test many per story.

## Worked Example
**The $750,000 iPhone (a live auction at a Wake Up Warrior event):**
- Hook: "In the next 10 minutes, someone here will pay at least $100,000 for this phone." (It cost $600, and at first nobody raised a hand.)
- Story: he walked through what was on the phone. An audiobook library ripped from more than $750K of courses, many of them rare. A contact list of influential people with personal numbers. A private Voxer channel that clients pay $100K a year for, included for life. Company SOPs and investment spreadsheets in Google Drive.
- Offer: stated stack value of more than $1M. He then auctioned it: every hand went up at $600, and more than 50 hands were still up at $100K. Three people walked on stage at $750K.

**The babysitter offer (a 12-year-old at $5/hour):** her core offer was babysitting at the market rate. She stacked on dishes done and the house cleaned, no video games, outdoor activities, reading and homework help, kids asleep before the parents get home, snacks for the kids and treats for the parents, and a photo collage of the night. Brunson offered her $20/hour, four times the market rate. Parents would book her weeks ahead.

**ClickFunnels free trial:** the plain 14-day trial became a stacked offer with SOPs, 100 templates, event recordings, and client contracts. It brought in tens of thousands of members.

## Key Takeaways
1. Before you write any copy, turn your product into a named offer that only you sell.
2. Brainstorm bonuses by asking what would guarantee their success. Then cut the non-negotiables.
3. Stack the value to at least 10x the price.
4. Lead with your origin story and why you are uniquely qualified (for example, Drew Manning's fit-to-fat-to-fit). Use it in ads and on landing pages before the offer.
5. Pull dozens of hooks from each story and keep testing until one grabs your dream customer.
6. When a funnel step underperforms, work out whether the hook, the story, or the offer is failing.

## Connects To
b1-ch01 (Secret Formula: bait is step 3), b1-ch03 (Value Ladder: a new offer at each rung), b1-ch04 (Attractive Character storytelling), b1-ch06 (Seven Phases), b1-ch18 through b1-ch20 (scripts), b2-ch07 (Epiphany Bridge), b2-ch10 (Stack Slide / irresistible offers), b3-ch03 (hooks for traffic).
