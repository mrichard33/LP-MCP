# Traffic Secrets — Secret #5: Traffic That You Own

## Core Idea
The list is the only real asset in a business. It includes email, Messenger, social followers and pixel/retargeting audiences. The single purpose of Traffic You Control (ads) and Traffic You Earn (Dream 100 endorsements) is to convert those clicks into Traffic You Own, which you can market to again and again for free.

## Frameworks Introduced
**The Three Traffic Types, ranked (Own > Control / Earn)**: when forced to choose one, always choose Traffic You Own.
- When to use: when setting the goal of every campaign.
- How: every ad and every guest appearance ends with a CTA into a front-end funnel that captures an email address, a Messenger subscription, or both. Selling on the first click is secondary to getting the lead.
- Why it works / failure mode: an ad gets someone to click once; a list lets you email them as often as you like at no cost. Failure mode: sending paid or earned traffic to pages with no capture, so you pay for one-time visits. (Brunson's early failure: he bought a CD of "1 million spam-free emails." Buying a list is spam. He got about 30 complaints in 6 hours and his ISP shut him down. Build your list with permission.)

**Front-End Funnel CTAs (converting a click into owned traffic)**: three standard calls to action, for example at the end of a podcast interview.
- **Lead funnel**: a free lead magnet in exchange for an email address (e.g., the "Marketing Secrets Blackbook: 99 secrets"). Nothing is sold; profit comes later from follow-up.
- **Book funnel**: a free book plus shipping. Upsells cover ad cost, and you create a *customer* on your list.
- **Webinar funnel**: register for a free web class, which puts them on the list. The offer at the end covers ad spend and ideally makes a profit (Perfect Webinar).

**List Value Benchmark ($1 per name per month)**: a worst-case planning metric.
- How: income goal ÷ 12 ÷ $1 = list size needed. $100K/yr needs ~10,000 names (10K × $1 × 12 = $120K). $1M/yr needs ~100,000 names.
- Adjust by list type: local businesses may have only 500–1,000 names but earn $50–$100 per name per month thanks to closer relationships. Retargeting or social lists may earn about $0.50 per name. Set $1 as the floor and try to beat it.

**List-as-Investment math**: compare it with a rental property. $250K might produce $500/mo and take about 30 years to pay off. With leads at $1–$5 each on Facebook, $5,000 at $5/lead buys 1,000 leads. At $1 per name per month you break even in about 5 months, then clear about $1,000/mo.

## Key Concepts
- **Traffic You Own**: email, Messenger, SMS, followers and pixel audiences you can reach again without paying.
- **Leverage**: one email to a large list can out-earn hundreds of hours of hourly work.
- **Lead magnet**: a free item that attracts opt-ins.
- **Front-end break-even funnel**: the first funnel, designed to cover ad cost while building the list.
- **Pixel list**: a retargeting audience built by tracking pixels (Brunson has tens of millions).
- **List as emergency fund**: a new offer emailed to the list can raise cash within days. Brunson says this twice saved him from bankruptcy.
- **Acquisitions buy lists**: eBay bought Skype (54M users) for $2.6B; Facebook bought Instagram (30M users) for $1B.

## Mental Models
- Think of every campaign as a list-building campaign that also happens to sell.
- Use "$1 per name per month" to set list-size goals from revenue targets, then beat it with a stronger relationship.
- Think of a lead as a cash-flowing asset. Once you know its payback period, buy as many as you can.
- Use lists as insurance: an owned audience lets you pivot fast when a market or platform changes.

## Anti-patterns
- **Buying or renting email lists**: that is spam. It brings complaints, shutdowns and legal risk.
- **Sending ads straight to a sales page with no opt-in**: you get one click and lose the chance to follow up.
- **Relying only on platforms you don't own**: a network change can wipe out your business overnight.
- **Judging list value by the first sale alone**: see follow-up funnels in b3-ch06.

## Worked Example
Leverage math: a list of 32,000 got one email for a $37 e-book. 232 bought (0.7%) = $8,584 from about 15 minutes of writing. At $50/hour that would take more than 171 hours of work. Brunson's current owned assets are 1.6M email subscribers, hundreds of thousands on Messenger, 1M+ social followers and tens of millions of people on pixel lists. The early "spam CD" test still showed demand: 6,423 emails produced 7 sales ($70), which pushed him to learn permission-based list building (via Mark Joyner's $1,000 course).

## Key Takeaways
1. Make "convert to owned traffic" the explicit KPI of every paid and earned campaign.
2. End every interview or ad with one front-end CTA: a lead magnet, a free-plus-shipping book, or a webinar.
3. Set a list-size target with income goal ÷ 12 ÷ $1 (e.g., 10K names ≈ $120K/yr).
4. Capture email AND Messenger (and SMS where appropriate) to build several owned channels.
5. Never buy lists. Build them only with permission.

## Connects To
b3-ch04 (Earned and Controlled traffic feeding the list; break-even funnels), b3-ch06 (follow-up funnels monetize the list), b3-ch08 and b3-ch09 (organic and paid list building), b1-ch03 (value ladder), b1-ch07 (follow-up funnels), b1 lead/book/webinar funnels, b2-ch11 (Perfect Webinar).
