# Traffic Secrets — Secret #6: Follow-Up Funnels

## Core Idea
The fortune is in the follow-up. About 81% of sales happen on or after the fifth contact (David Frey). Once traffic is owned, push every lead through a multi-channel follow-up funnel that stacks them up your value ladder. Follow-up is what lets you break even (or lose a little) on the front end and still win, because you can outspend competitors to acquire a customer.

## Frameworks Introduced
**Break-Even-on-Day-X / Funnel Stacking**: break even can happen in the front end *or* later in the follow-up. Find the day it happens, then scale ad spend.
- When to use: when a front-end funnel loses money and you're tempted to kill it.
- How (lead funnel example, $3 CPL): Days 1–3: nurture emails (make sure they got the magnet, send extra value video or article); still −$3. Next: 3 emails inviting them to a free-plus-shipping book funnel; average +$1.50/lead, still −$1.50 by about day 6. Next: invite to a webinar that sells a higher-ticket offer; average revenue per lead passes $3, so you break even around day 7. Everything after that is profit. Once break-even day X is known, buy leads aggressively.
- Why it works / failure mode: "Amateurs focus on the first sale" (attributed to "Mike Lipman" in the source text; likely Mike Filsaime). Dan Kennedy's rule is that whoever can spend the most to acquire a customer wins. Failure mode: shutting off a funnel a few days before its follow-up break-even point.

**Multi-Dimensional Follow-Up Funnels**: attention spans are short and many emails go unopened (Brunson cites up to 87%), so follow up across several channels.
- **Email**: the base channel, can be sent daily.
- **Retargeting ads**: ads that follow visitors around the web and push them to the next funnel (detail in Secret #9 / b3-ch09).
- **Messenger**: much higher open rates, but more personal. Limit to **1–2 messages per week**, each aimed at a funnel.
- **SMS**: don't ask for a phone number on opt-in pages (every extra field lowers conversion). Collect it at purchase or webinar registration. Use it for webinar reminders, order status, and the next step on the ladder.

**The Three Closes: Emotion → Logic → Fear**: the order for every page, sequence and retargeting set.
- How (sales page): top block = emotional headline + story video + order form. About 50% of buyers act here and never scroll. Middle = logic: why it's a good deal, comparison with other investments, money-back guarantee, risk reversal. About 30% are analytical buyers afraid of losing status. Bottom = fear: urgency (why now) and scarcity (why it's going away). About 20% are driven by FOMO.
- Sequence math: 3 emails = 1 emotion, 1 logic, 1 fear. 5 emails = 3 emotion, 1 logic, 1 fear. Hit all three closes; the exact count matters less. When moving to the next funnel, start again with emotion.
- Why it works: each close converts a different group of buyers, so a sequence missing one close loses that group completely.

**Soap Opera Sequence + Daily Seinfeld Emails (how they fit together)**:
- **Soap Opera Sequence (SOS)**: linked story emails, each hooking the next. *Season 1* builds rapport with the Attractive Character. *Season 2* tells the story behind the first product or funnel and moves through emotion → logic → fear. *Season 3+* introduces the next funnel on the value ladder.
- **Daily Seinfeld emails**: standalone broadcasts, each with a hook, a story, and a push back to a core offer, new front ends, webinar re-registration, blog posts, podcast episodes or affiliate offers. Leads move to the broadcast list after the follow-up funnel ends, usually **30–60 days** in.

## Key Concepts
- **Follow-up funnel**: an automated multi-message path that moves a new lead up the value ladder.
- **ACV (Average Cart Value)**: average front-end revenue per buyer, including upsells.
- **Funnel stacking**: follow-up that leads from one funnel into the next, higher-priced one.
- **Break-even day X**: the day in follow-up when cumulative revenue per lead exceeds CPL.
- **Emotional / analytical / FOMO buyers**: roughly a 50/30/20 split of buyers by close type.
- **Risk reversal**: guarantees that remove the logical buyer's fear of losing status or money.
- **Broadcast list**: the post-sequence bucket for daily Seinfeld emails.

## Mental Models
- Think of the list without follow-up as a bathtub without the stopper.
- Use "can I break even by day X?" in place of "is this front end profitable?"
- Think of every message sequence as emotion → logic → fear, restarting at emotion for each new offer.
- Use the SOS for new subscribers (sequence), and the Seinfeld broadcast for everyone who has finished it.

## Anti-patterns
- **Only 1–2 follow-ups**: most sales happen at contact 5 or later.
- **Killing a front end that loses a little money** without checking follow-up break-even.
- **Email-only follow-up**: most messages are never seen.
- **Daily Messenger blasts**: that inbox is intimate, so going over 1–2 per week causes unsubscribes.
- **Asking for a phone number on the opt-in**: every extra field lowers conversion.
- **Only emotional (or only logical) messaging**: you lose the other buyer groups.
- **Treating the SOS and Seinfeld emails as competing** instead of sequential.

## Worked Example
Four break-even front ends over 30 days:
| Funnel | Leads | Sold | ACV | Gross | Ad spend | Profit |
|---|---|---|---|---|---|---|
| DotCom Secrets free+shipping | 5,410 | 2,395 | $30.81 | $73,790 | $69,026 | $4,764 |
| 108 Split Tests book | 2,013 | 1,357 | $12.38 | $16,800 | $13,814 | $2,986 |
| Perfect Webinar Secrets | 1,605 | 760 | $34.38 | $26,129 | $22,360 | $3,769 |
| Marketing in Your Car MP3 player | 5,177 | 1,765 | $14.79 | $26,104 | $23,205 | $2,899 |
Total: $142,823 revenue − $128,406 ads = **$14,418 profit**. That's 14,205 leads, so Brunson was *paid* about $1 per lead to build the list. Follow-up: value videos, then a ClickFunnels webinar invite. 1,129 registered, 57 bought at $2,997 = $170,829. Total follow-up sales in 30 days were **$234,240**, about **$16.49 for every $1** made on the front end.

## Key Takeaways
1. Aim for a front end that breaks even; if it doesn't, find break-even day X in follow-up before killing it.
2. Stack funnels in follow-up: lead magnet, then book/low-ticket, then webinar/high-ticket.
3. Run email + retargeting + Messenger (1–2/week) + SMS (collected at purchase or registration).
4. Structure every sequence as emotion → logic → fear (for 5 emails: 3/1/1).
5. New leads get the Soap Opera Sequence for 30–60 days, then move to the daily Seinfeld broadcast list.
6. Judge lead value over 30, 60, 90 and 360 days, not by the first sale.

## Connects To
b1-ch03 (value ladder), b1-ch07 (follow-up funnels, SOS, Seinfeld emails), b1-ch04 (Attractive Character), b1-ch15 (webinar funnels), b2-ch11 (Perfect Webinar), b2-ch14 (stack and closes), b3-ch04 (ACV / break-even), b3-ch05 (Traffic You Own), b3-ch09 (retargeting), b3-ch11 (Facebook/Messenger).
