# DotCom Secret 5: Funnel Hacking

## Core Idea
Don't pioneer. Before building any funnel, find people already selling successfully to your market, buy their products, record the Hook, Story, and Offer at each step, and model the structure with your own product and words. If nobody is successfully selling to the market, don't move forward. This is a short, process-focused chapter.

## Frameworks Introduced

**Funnel Hacking (modeling, not copying)**
- Formulation: reverse-engineer proven funnels, then put your product, your words, and your art into the same structure (layout, page order, price points).
- When to use: before every new funnel; also as a validation test for a market.
- How:
  1. Choose the funnel type you will build (from the funnels in Section 2).
  2. Find 10 or more funnels to model from three sources: **direct competitors** (similar product, same people), **indirect competitors** (different product, same demographic), and **same funnel type** in any market (any webinar, any free-book funnel).
  3. Act like a real customer. Search your market's Google keywords and click the paid ads. Like related Facebook pages so you get served ads.
  4. For each ad, write down its Hook, Story, and Offer. Click through.
  5. On each page (pre-sell, landing, sales, order form, upsells), write down the Hook, Story, and Offer, then take the action the page asks for.
  6. **Buy the products** so you see the whole funnel, including upsells and follow-up.
  7. Go through at least six funnels to spot trends and set a baseline.
  8. Put on your "marketing consultant" hat and ask how you would make each hook sexier, each story more attractive, and each offer and upsell more irresistible.
- Why it works / failure mode: incumbents have already absorbed the costly tests ("pioneers have arrows in their backs"). Newcomers who undercut on price or invent a new model fail every year. The failure mode is copying: lifting products, sales letters, or wording is illegal and not what funnel hacking means.

## Key Concepts
- **Funnel hacker**: someone who models proven funnels. It's the name the ClickFunnels community uses for itself.
- **Modeling**: using the structure and strategy someone has proven works, with your own content.
- **Copying**: reproducing someone's product, text, or art. Don't.
- **Direct competitor**: similar product, same audience.
- **Indirect competitor**: different product, same audience.
- **Same-funnel-type model**: any funnel using the format you plan to use, whatever the market.
- **Baseline**: the standard of hooks, stories, and offers you must beat to win the dream customer.
- **Market validation**: finding existing successful sellers. No sellers is a stop signal.

## Mental Models
- Think of competitors' funnels as free R&D labs with hundreds of staff testing variables for you (Agora, Porter Stansberry).
- Use the Tony Robbins model: to succeed, model those who have already succeeded.
- Think of funnel hacking as wrestling film study. Record the winners, drill their moves, then make them your own.
- Use the same-funnel-type route when no one in your niche runs funnels. The framework carries across markets.

## Anti-patterns
- **Being the pioneer**: you pay for every failed test yourself.
- **Undercutting price or inventing a new model to compete with a leader**: this fails every year.
- **Copying text or products**: it's illegal and it's not modeling.
- **Browsing without buying**: you miss the upsells, order forms, and follow-up where most of the funnel lives.
- **Hacking just one funnel**: you can't see which patterns are real without at least six.

## Worked Example
**Brunson's first software funnel (modeling Armand Morin):** he built his own software product and wrote his own sales letter. He modeled Morin's look and feel, page layout, and price points. Where Morin had a headline, he had a headline. Where Morin placed a software box, he placed his. Where Morin had a bold list of features and benefits, he wrote his own list. The structure was proven, and the content was entirely his.

**Wrestling:** his father filmed the winning wrestlers at each level, and they studied and drilled those moves. He went from bad to state champion, second in the nation, All-American, and a Division I scholarship.

## Key Takeaways
1. Validate first: if you can't find anyone successfully selling to this market, don't build.
2. Collect 10 or more funnels across direct, indirect, and same-funnel-type sources.
3. Buy the products and log the Hook, Story, and Offer for every ad and page, upsells included.
4. Study at least six funnels to set the baseline, then design better hooks, stories, and offers.
5. Model structure, layout, and pricing. Never copy words or products.

## Connects To
b1-ch02 (Hook, Story, Offer logged per page), b1-ch06 (Seven Phases: spot each phase while hacking), b1-ch08 through b1-ch17 (funnel types to model), b3-ch02 (finding congregations and competitors), b3-ch04 (Dream 100 / finding who already has your audience).
