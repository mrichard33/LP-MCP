# Expert Secrets — Secret 18: The Five-Minute Perfect Webinar

## Core Idea
The Perfect Webinar works for any business, including physical products, when compressed. Jamie Cross (a master herbalist selling soaps and lotions) failed with a 90-minute webinar for a $200 bundle, then built a five-minute version to sell a $39 product. She reached $130K in six weeks and nearly $2M in her first year. Match presentation length to price point.

## Frameworks Introduced
**Five-Minute Perfect Webinar**: the same architecture in miniature. A curiosity hook plus Big Domino claim, "three secrets" announced up front, a quick expert intro, one short story or proof beat per secret, then a mini stack and CTA.
- When to use: Facebook Lives, ads, landing-page/sales videos, VSLs, and especially low-ticket offers (under $100) and e-commerce/unboxing funnels.
- How: open with a contrarian hook tied to the new opportunity (e.g. "the most powerful skin ingredient doesn't come from plants"), promise three secrets, introduce yourself, run each secret in about a minute, then offer and CTA. The full fill-in script (built by Jamie with Jim Edwards of Funnel Scripts) is in the book's supplemental PDF and isn't reproduced in the text.
- Why it works / failure mode: the belief sequence still runs (domino, three false beliefs, stack) but at a length a $39 buyer will watch. It fails when a long 90-minute format is applied to a cheap product, or when a five-minute version is used for high-ticket offers that need more belief-building.

**Price-to-length rule**: the higher the price, the longer the presentation. 5 min for under $100, a 30-min shortcut for mid-ticket or VSLs, 90 min for high-ticket or webinars.

## Key Concepts
- **Five-minute perfect webinar**: a compressed Perfect Webinar for ads and low-ticket sales pages.
- **"Three secrets" hook**: announcing three secrets in the first seconds signals structure and builds curiosity.
- **Universality**: e-commerce sellers' claim that "my business is different" is a false belief. The principles transfer.
- **Apply your art to the framework**: keep the structure and adapt the content and length.
- **Dual use**: the same five-minute video serves as both the ad and the landing-page video.

## Mental Models
- Think of the Perfect Webinar as scalable: the ratios and belief targets stay fixed while duration flexes with price.
- Use five minutes when the ask is small and ninety when the ask is big.
- When someone says "it won't work for my business," ask "how *can* I make it work?" as Jamie did.

## Anti-patterns
- **90-minute pitch for a sub-$200 product**: it failed for Jamie.
- **Assuming the framework is only for coaches, authors, and speakers**: most e-commerce sellers wrongly concluded this.

## Worked Example
Jamie Cross opening (paraphrased structure): hook ("the most powerful skincare ingredient isn't a plant") → "today I'll share three secrets that will revolutionize how you care for your skin" → "I'm Jamie, a master herbalist" → three quick secrets → $39 offer. Result: $130K in 6 weeks, about $2M in year one, used as both ad and landing-page video.

Thin chapter: the actual step-by-step five-minute script lives in the supplemental PDF, not in this text.

## Key Takeaways
1. Match presentation length to price: under $100 → about 5 minutes.
2. Open with a contrarian new-opportunity hook and announce "three secrets" immediately.
3. Keep the domino → three beliefs → stack order even when compressed.
4. Use the same video as the Facebook ad and the sales-page video.
5. Iterate for months if needed. Jamie tweaked for months before it took off.

## Connects To
b2-ch11 (framework), b2-ch17 (shortcut, the mid-length version), b2-ch19 (five-minute webinars in ads and unboxing funnels), b1-ch22 (Perfect Webinar script), b1-ch03 (value ladder: low-ticket front end), b3 (ads and hooks).
