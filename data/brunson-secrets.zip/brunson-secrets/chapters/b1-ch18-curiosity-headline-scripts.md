# Dotcom Secrets Secret 18: Curiosity-Based Headline Scripts

## Core Idea
Headlines are the most-used and most underrated script in the funnel: ads, landing pages, email subject lines, sales pages, upsells, and the first sentence of every video. A headline's job is not to sell—it is to stop the right person, create curiosity, pre-frame them, and move them to the next step. Guest chapter by Jim Edwards (Funnel Scripts), who supplies templates by traffic temperature.

## Frameworks Introduced

**Headline Job Description (Hook → Curiosity → Pre-frame → Next Step)**:
- When to use: Every piece of copy—ad, page, email, video opener.
- How: Check each headline against four criteria: (1) calls out the right audience, (2) makes them stop, (3) opens a curiosity gap, (4) sets up the next element (click, open, watch, keep reading).
- Why it works: A better headline gets more people "up to bat"; even mediocre copy beats great copy nobody reads.
- Failure mode: Writing the headline last as an afterthought, or a headline about you rather than them.

**Headlines by Traffic Temperature** (Schwartz awareness via Russell's hot/warm/cold):
- When to use: Never send hot, warm, and cold traffic to the same headline.
- How (templates, fill the blanks):
  - **Hot** (knows you/product) — name the product: "Finally discover how [Product] gives you [Big Result] without [Pain]"; "[Big Result] with [Product]—guaranteed"; "Watch this free video to see how [Product] gives you an unfair advantage with [Main Topic]."
  - **Warm** (knows solutions exist, not you) — lead with the payoff: "See how easily you can [Big Result] without [Pain]"; "How [Target Audience] like you [Big Result] in [Timeframe]"; "The secret to [Big Result] without [Pain]."
  - **Cold** (knows only their problem) — lead with the problem: "Don't let [Pain] stop you"; "How [Target Audience] can stop [Pain]"; "How to eliminate [Pain] from your life—guaranteed."

**Question Headlines**: ask about something they badly want or want to avoid—"What if you could [Desire] without [Pain]?", "Worried about [Pain]?", "Isn't it time you stopped struggling with [Pain]?", "Are you getting enough [Desire]?"

**Curiosity Headlines**: "Imagine [Desire] in just [30 minutes]"; "You may be sabotaging your [Main Topic] success and not know it"; "Don't even think about [Desire] without reading this"; "What [Enemy] doesn't want you to know about [Main Topic]."

**Three Emotional Targets**: amp any headline by hitting (1) a clear desire, (2) a pressing problem, or (3) a nagging/intense pain.

## Key Concepts
- **Hook** — the element that stops the right people.
- **Pre-frame** — setting the lens through which the rest of the copy is read.
- **Traffic temperature** — hot/warm/cold awareness levels needing different headlines.
- **Headline test** — swapping only the headline to isolate its effect.
- **Modeling** — adapting a headline that already got *you* to spend money.
- **Market vote** — only the buyer with a credit card decides which headline wins.
- **Batting analogy** — more at-bats (readers) beats a better average.

## Mental Models
- Think of headline scripts as the flashlight in a gold mine.
- Use "if this copy got me to buy, it's worth studying" as a swipe filter.
- Think of doubled click-through as leverage on profit, not just revenue.

## Anti-patterns
- **Headline that sells or explains everything**: kills curiosity.
- **Headlines you fall in love with**: they rarely work; test instead.
- **Headlines about you** ("how I went from X to Y"): the reader only cares about themselves.
- **One landing page for all temperatures**: mismatched conversation.
- **Stopping at the first winner**: keep testing for a bigger lift.

## Worked Example
Headline math: $1,000 in ads buys 500 readers ($2 each). Double clicks → 1,000 readers at $1 each. On a $1,000 product costing $900 in ads per sale, profit is $100; doubling clicks doubles revenue to $2,000 with the same $900 ad cost → $1,100 profit, an 11x profit increase. Launch story: a two-CD product with headline "How I went from trailer trash to piles of cash" got 0 sales in 300 visitors; a quick new headline made a sale in minutes; then modeling a headline Jim had bought from ("how to gain a positively unfair advantage in the search engine wars") into "How to gain a positively unfair advantage in business and in life" produced 5 sales in 5 minutes—nothing else changed.

## Key Takeaways
1. Write the headline first and treat it as the highest-leverage copy on the page.
2. Match headline to traffic temperature: product name for hot, payoff for warm, problem for cold.
3. Make it about them and open a curiosity loop they must close by taking the next step.
4. Generate many variants from templates, split-test, and keep testing past the first winner.
5. Swipe and adapt headlines that have made you buy.

## Connects To
b1-ch02 (hook, story, offer), b1-ch15 (registration headlines), b1-ch20 (pattern-interrupt hook), b1-ch28 (headline audible: $24.85 → $5.84 registration), b3-ch03 (hooks), b3-ch19 (cold traffic), b2-ch11 (big promise).
