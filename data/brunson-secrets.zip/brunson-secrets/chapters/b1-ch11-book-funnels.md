# DotCom Secret 11: Book Funnels

## Core Idea
A book funnel is the main unboxing funnel for information businesses. You take an offer that could sell as one $800+ bundle and "unbox" it, selling a free-plus-shipping front end (a book, CD, DVD, or preloaded MP3 player), then an order form bump, one or two upsells, and a thank-you page that points to the next funnel. The low entry price wins the first yes, and the bump and upsells raise Average Cart Value above Cost Per Acquisition. The unboxing principles below come from the Section 2 unboxing overview and apply to book, cart, and challenge funnels.

## Frameworks Introduced

**Unboxing Funnel principle**
- Formulation: split a bundled offer so each piece is sold on its own funnel step. Example: Expert Secrets book $27, audiobook $19, Expert Secrets home study $297, Traffic Secrets home study $497. As a bundle that is $840 and would need a presentation funnel. Unboxed, it becomes a book funnel lower on the ladder.
- Why it works / failure mode: more people become buyers, and a good average cart value funds aggressive ad spend. Small first yes, then bigger yes. The failure mode is "upsell hell," dozens of upsells that damage lifetime value and ascension.

**The 100 Visitor Test (Free Plus Shipping)**
- Control: a $197 product on a well-written page converted 1% of cold traffic, so 100 visitors produced $197 and one buyer.
- Test: a free-plus-shipping piece of the product converted 8% with almost no copy, and 25% of those buyers took the $197 upsell. 100 visitors produced $394 and eight buyers. That is 2x the revenue and about 7x the customers.
- Variants: sell the product with free shipping, with no conversion dip and sometimes a lift. Digital giveaways work but lose buyer qualification and one-click upsells.

**Order Form Bump**
- A checkbox after the card details and before submit offers a simple, low-ticket add-on that needs no explanation (the grocery checkout impulse buy). About 33% take it, with no loss of lifetime value. It often covers the whole ad cost.
- Book examples: audiobook +$27, behind-the-scenes training +$37, templates +$47. Placing it earlier hurts conversion.

**CPA vs. ACV**
- CPA (cost per acquisition) is ad spend per customer. ACV (average cart value) is total funnel revenue per customer.
- Rule: if CPA is less than ACV, scale spend like a slot machine that pays out. If CPA is greater than ACV, go back to the drawing board. Example: CPA $20, ACV $100, profit $80 per customer.

**Book Funnel pages**
1. **Sales page**: curiosity headline (b1-ch18). On the left, a story and offer video (Who-What-Why-How, b1-ch19, or Star-Story-Solution, b1-ch20). On the right, a **two-step order form**: step 1 "Where should I ship this?", step 2 card details for shipping. State the shipping charge up front, or it's unethical. Below the top block, bullets for logical buyers. At the bottom, urgency and scarcity for fear-driven buyers. For a digital product at $7 to $27, move the order form to the bottom so value is built before the price.
2. **Upsell (OTO) page(s)**: keep the buying loop open ("Wait, your order is not yet complete. Customize your order now."). Use the OTO script (b1-ch21). **OTO rule for info products: don't sell more of the same thing.** Sell the next logical need, the new problem the purchase creates (a car needs gas; a funnel book needs funnel software). Put a visible no-thanks link near the button with loss-framed wording, never a benefit. An optional **downsell** removes elements, switches physical to digital, or offers a payment plan. An optional second upsell follows the same rule.
3. **Thank-you page**: delivery or access details plus the next funnel (webinar registration or application).
- Upsell cap: two upsells, or one upsell plus one downsell. More hurts lifetime value, fewer makes profit hard.

## Key Concepts
- **Unboxing funnel**: a low-ticket funnel ($1 to $100) that sells a bundle piece by piece.
- **Free plus shipping**: a free physical item where the buyer pays shipping. It qualifies buyers and enables one-click upsells.
- **Two-step order form**: shipping details first, card second. Step 1 often out-converts an email squeeze page because physical items feel more valuable.
- **Order form bump**: an impulse checkbox before submit.
- **OTO (one-time offer)**: an upsell after purchase that uses the stored card with one click.
- **Buying loop**: the buyer's "still shopping" mindset. "Thank you" closes it.
- **Downsell**: a cheaper version after a no.
- **CPA / ACV**: the two core funnel metrics.

## Mental Models
- Think of the first yes as removing friction. Once the card is out, the second yes is easy.
- Use CPA below ACV as the only green light to scale ads.
- Think "what problem did this purchase just create?" to pick each info OTO.
- Think of the page as serving three buyer types: emotional (top block), logical (bullets), fearful (urgency at the bottom).

## Anti-patterns
- **Hiding the shipping charge**: this is unethical and poisons the Value Ladder.
- **Saying "thank you" on the upsell page**: conversions stop.
- **Upselling more of the same info**: the itch already feels scratched.
- **A positive-sounding no-thanks link** ("take me to the members area"): it raises declines.
- **Bumps that need explaining, or bumps placed before card entry**: low take rate.
- **More than two upsells in an info funnel**: lifetime value drops.

## Worked Example
**The DotCom Secrets book funnel:** Brunson modeled dozens of book funnels and built his own. It sold more than 100K copies before the second edition. The same framework was built for Tony Robbins, Dave Asprey, Grant Cardone, and Robert Kiyosaki, and it also sold an MP3 player preloaded with 257 podcast episodes. Dean Graziosi's *Millionaire Success Habits* thank-you page asks buyers to reserve a seat at a web class that was already included in the book offer, which ascends them to a presentation funnel.

## Key Takeaways
1. Unbox your bundle so the front end is free plus shipping (or paid with free shipping), then the pieces follow as the bump and upsells.
2. Use a two-step order form and disclose the shipping charge.
3. Add a simple order form bump (about 33% take rate) between card entry and submit.
4. Keep the buying loop open on OTOs, sell the next logical need, and use loss-framed no-thanks links.
5. Cap info funnels at two post-purchase offers.
6. Track CPA vs. ACV and scale only while ACV is higher.
7. Use the thank-you page to push buyers into a webinar or application funnel.

## Connects To
b1-ch03 (unboxing tier $1 to $100), b1-ch06 (phases 4 and 5), b1-ch12 (Cart Funnels: the physical-product OTO rule), b1-ch13 (Challenge Funnels), b1-ch15 (Webinar Funnels as the next rung), b1-ch18 through b1-ch21 (headline, video, and OTO scripts), b3-ch09 (funnel math / paid ads).
