# Traffic Secrets — Secret 15: Conversation Domination

## Core Idea
Master one primary platform first, for at least 12 months. Then become omnipresent without burning out by running one weekly live "master show" whose segments are built to be stripped into native content for each platform, and promote every piece through distribution channels you own.

## Frameworks Introduced

**One Platform First rule**
- When to use: before you publish or spend anywhere else.
- How: choose the platform where you already consume the most media, which is usually the one that hosts your show from Secret 7. Put all Dream 100, publishing, and ad effort there for at least 12 months, until the Dream 100 is mapped, publishing runs on autopilot, and there is a process for working in and a team for buying in. Then add platform #2 and run the six-step Fill Your Funnel framework on it.
- Why it works / failure mode: spreading across platforms leaves you mediocre everywhere and thins your ad dollars. ClickFunnels stayed on Facebook alone until it passed $100M in sales, then added the podcast, then Instagram, then the blog. Each new channel needed its own Dream 100, strategy, and team.

**Three routes to omnipresence**: (1) repurpose one piece of content into every format ("watered down at best"); (2) create unique content for every platform (needs a huge team and burns out the host); (3) **the master show**, Brunson's answer.

**The Master Show (Marketing Secrets Live, talk-show format)**: stream it live on Facebook and Instagram, then split out the segments.
- **Monologue** (stories, connection) → one podcast episode.
- **Interview** → a second podcast episode. Together that is two episodes a week.
- **Q&A collabs**: exchange question videos with Dream 100 members in advance, then post them to IGTV with each side tagging the other.
- **Top 10 list** ("Letterman" segment) → the team writes it up as a blog skyscraper in your voice and starts link building.
- **How-tos**: 2–3 demos aimed at target keywords → one YouTube video each.
- **JK5 images**: at least one per category, with the story behind it, so the team can write Instagram captions.
- **Quotes** plus your explanation → quote cards with captions in your own words.
- **Final thoughts**: live-only, never reposted, to reward the people who watch to the end.
- After the show: record podcast intros, and YouTube intros and outros (subscribe/notifications, a comment prompt), so the team can package each asset.
- Why it works: native language per platform. Facebook wants personal stories, current events, and live video. Podcasts want long interviews. Blogs want long, detailed lists. Instagram wants images and behind-the-scenes. YouTube wants keyword how-tos and entertainment.

**Distribution stack for every new piece**: **email** (daily Seinfeld list after the Soap Opera Sequence, fully owned) + **Messenger** (rented, but high open and click rates) + **desktop push**. Push these at launch so early views, likes, and comments tell each algorithm the content is good, before paid ads start, which makes each ad dollar go further.

## Key Concepts
- **Primary channel**: the one platform you master before expanding.
- **Omnipresence**: whatever app your prospect opens, they see you. It is the end state, not the start.
- **Native language**: the content form each platform's audience expects.
- **Master show**: one live production designed so each segment feeds a specific platform.
- **Live-only segment**: exclusive content that keeps live viewers until the end.
- **Distribution channels**: owned or rented lists used to trigger early engagement.

## Mental Models
- Think of the master show as a raw-material factory. Each segment is cut for the platform it is headed to.
- Use "has platform #1 reached autopilot (Dream 100 known, publishing systemized, work-in and buy-in running)?" as the gate before adding platform #2.
- Get engagement first and paid spend second: organic signals from traffic you own make paid reach cheaper.

## Anti-patterns
- **"Create once, post everywhere"** (rip the audio from YouTube for the podcast, transcribe it for the blog): it breaks each platform's native language and feels strange to the audience.
- **Launching on all platforms at once**: "crumbles under the weight."
- **Turning on paid ads before seeding organic engagement**: wastes ad efficiency.

## Worked Example
**Weekly master show** → 2 podcast episodes (monologue plus interview), 1+ IGTV collab, 1 blog skyscraper from the top-10 list, 2–3 keyword YouTube videos from the how-tos, 5+ Instagram posts from the JK5 images, and several quote cards. Each is announced to email, Messenger, and push when it goes live. A fill-in-the-blank show outline is listed at trafficsecrets.com/resources.

## Key Takeaways
1. Choose one primary platform and give it 12 months of focus.
2. Add each new platform with the full six-step framework, a new Dream 100, and a dedicated team member.
3. Build a weekly live show with segments mapped to each platform's native format.
4. Record platform-specific intros and outros right after the show so the team can package the assets.
5. Announce every new piece to email, Messenger, and push before you boost it with paid ads.

## Connects To
b3-ch05 (traffic you own), b3-ch07 (your show), b3-ch08 (organic publishing), b3-ch10 (Instagram, JK5), b3-ch11 (Facebook), b3-ch12 (skyscraper), b3-ch13 (YouTube how-tos), b3-ch14 (podcast, framework), b1-ch07 (Soap Opera Sequence, Seinfeld emails), b2 attractive character.
