# Expert Secrets — Secret 7: The Epiphany Bridge

*(This opens Section 2, "Creating Belief." The section intro links back to Hook-Story-Offer: Section 1 raised the value of the **offer**, and Section 2 raises it through **story** as a pre-frame.)*

## Core Idea
People buy on emotion and justify with logic. Experts fail because they share the *logic* that convinced them (techno-babble) and skip the *emotional* experience that sold them first. An **Epiphany Bridge** story recreates your original aha moment so listeners have the same epiphany and sell themselves. Don't sell. Guide them to their own decision.

## Frameworks Introduced
**The Epiphany Bridge**: a story that takes people through the emotional experience that got you excited about the new opportunity, bridging them from emotion to logic.
- When to use: any time you want someone to adopt a new concept, including sales videos, webinars, emails, podcasts, and "what is X?" questions.
- How:
  1. Go back to your pre-expert state, when you were just a spark. That's where your dream customers are now.
  2. Identify the **guide** (a person, or God/inspiration) and the **epiphany** they gave you. (Brunson: Google raised ad costs → Mike Filsaime described one-time-offer upsells converting about 1 in 3 → funnels.)
  3. Recall the setting and your feelings in detail, then tell the story so listeners enter that same state.
  4. Let them reach the conclusion themselves. Logic (science, data, features) comes *after* the epiphany, and they'll go find it on their own.
- Why it works / failure mode: if you plant the idea in a story and they supply the answer, the buying decision is theirs. Logic before epiphany annoys and even offends people. When the listener isn't in your state, you get "I guess you had to be there." Proof point: a rewritten epiphany-bridge launch video brought 1.5M users in 6 weeks with $0 ad spend.

**Emotional → Logical Bridge**: the expert's own path was epiphany (emotional buy-in) → geeking out → logically sold. The mistake is presenting the logical end state to someone who hasn't crossed the emotional bridge. Status sits on both sides: you want the emotional status gain, and you need the logic to justify it to others (the Ferrari and gas-mileage example).

**Effective Storytelling Keys**:
- **Oversimplification**: speak at about a third-grade reading level (Flesch-Kincaid). Big words lose people, and they stop listening after the first unknown term.
- **The "Kind of Like" Bridge**: at every friction point, relate the concept to something familiar. "Ketones are *kind of like* millions of little motivational speakers running through your body." "Ketosis is *kind of like* eating the power pellet in Pac-Man."
- **Make them feel**: describe the setting (room, sounds, people) and your physical and emotional feelings, the way a novelist spends pages on a scene. (Contrast Magneto's wordless film scene with a one-line summary that makes you feel nothing.)

## Key Concepts
- **Epiphany Bridge**: a story that transfers your aha so the listener has it too.
- **Guide**: the source of the epiphany (a mentor, or divine inspiration).
- **Techno-babble**: jargon and data shared before emotional buy-in. Kim Klaver calls it the number one sales killer.
- **Emotion buys, logic justifies**: the order of every purchase decision.
- **Kind of Like bridge**: an analogy connector that simplifies complex terms.
- **Third-grade level**: the target reading level for persuasive stories.
- **State transfer**: putting the listener in the emotional state you were in at the epiphany.
- **Story as pre-frame**: a story told before the offer raises its perceived value.

## Mental Models
- Think of yourself as the guide passing on the epiphany your own guide gave you.
- Use "kind of like" whenever a word is above a third-grade level.
- If a prospect resists your logic, they haven't had the epiphany yet. Tell a story instead of adding facts.
- Think of the story in cinematic terms: set, sensation, feeling, then the aha.

## Anti-patterns
- **Pitching why they should buy**: feels "dirty" and creates no emotion.
- **Leading with science, stats, features**: this is techno-babble, and it doesn't land before the epiphany.
- **Using sophisticated vocabulary**: signals intelligence and loses influence.
- **Summarizing events without feelings**: the audience feels nothing (the flat-Magneto version).
- **Retelling the same flat story repeatedly** instead of recreating the state.

## Worked Example
**Brunson's funnel epiphany, told with feeling.**
- Pre-state: potato-gun DVD sold via Google ads (about $10/day in ads for one $37 sale per day).
- Crisis: Google raised costs to more than $50/day, the business died, and he was facing either quitting wrestling or his wife working two jobs.
- Guide: Mike Filsaime calls and says business is better than ever.
- Epiphany: add an upsell right after purchase ("like McDonald's: fries and a Coke?"). One in three buyers take it.
- Result: Brunson adds a potato-gun-kit upsell, one in three buy, and ads are profitable again.
- New belief: success depends on *how* you sell (funnels), not what you sell.

Told with sensory detail (the scene-setting "Christmas with no money" passage is the model), the listener reaches "I need a funnel" on their own.

## Key Takeaways
1. Write down your core epiphany: who the guide was, what the aha was, and what changed.
2. Recreate the scene and your feelings in detail so listeners enter your state.
3. Hold all logic, data, and jargon until after the emotional epiphany lands.
4. Edit stories to about a third-grade reading level and add a "kind of like" bridge at every hard term.
5. When asked "what is X?", answer with your epiphany bridge story instead of a definition.

## Connects To
b1-ch02 (hook-story-offer), b1-ch04 (Attractive Character stories), b1-ch20 (star story solution), b2-ch02 (learned-or-earned pre-frame), b2-ch08 (Hero's Two Journeys), b2-ch09 (Epiphany Bridge script), b2-ch10 (four core stories), b2-ch11 (Perfect Webinar origin story).
