# Traffic Secrets — Secret #2: Where Are They Hiding? The Dream 100

## Core Idea
Your Dream Customers have already been gathered by other people: the owners of websites, groups, podcasts, lists, channels and keyword results. Stop asking "How do I get traffic?" and ask "Where are my Dream Customers already congregating?" Then build a Dream 100 list of those congregations and their owners. It is the foundation for every later traffic tactic.

## Frameworks Introduced
**The Dream 100, One-to-One (Chet Holmes, *The Ultimate Sales Machine*)**: pick the small set of best buyers and market to them relentlessly.
- When to use: high-ticket or B2B models that need a small number of big customers.
- How: (1) find the buyers who control most of the spend. Chet found that 167 of 2,000 advertisers spent 95% of the industry's budget. (2) Drop everyone else. (3) Mail a package with a "lumpy object" every 2 weeks and follow each with a phone call (2 mailings + 2 calls per month). (4) Keep going with "pig-headed discipline" (PHD) through months of silence.
- Result: zero responses for 4 months; then Xerox. By month 6 he had 28 of 167 accounts, which doubled sales and took the magazine from #15 to #1. By year 3 he had all 167.
- Awareness ladder: never heard of you → keep hearing about you → think I've heard of you → know you → do business with you.

**The Dream 100, One-to-Many (Brunson's version)**: run the Dream 100 campaign at the *owners of audiences*, not at individual buyers.
- When to use: low-ticket or volume products where courting each buyer doesn't pay (e.g., a $7.95 book).
- How: list every congregation, record each one's audience size, then (a) court the owner for promotion (Work Your Way In) and (b) target their followers with ads (Buy Your Way In). See b3-ch04.
- Why it works / failure mode: one "yes" from an owner can produce hundreds or thousands of customers. Failure mode: people understand it but never build the list. Brunson says a $100K consulting day would start with 3–4 hours of building it.

**A Different Dream 100 on Each Platform**: people consume media on the platform they love, so keep a separate list per platform.
- When to use: growing any channel (podcast, blog, YouTube, Instagram).
- How: podcast listeners come from other podcasts, and blog readers come from other blogs. Build each platform's Dream 100 from the same platform. Brunson's relaunched podcast flatlined after an owned-traffic push because Instagram fans don't move to podcast apps.

**Two Types of Congregations**:
- *Interest-based*: people, influencers, brands, books, movies and companies your customers follow on social networks (Facebook tracks roughly 52,000 data points per user). Write 20–100 names per network, then do the same for podcasts, blogs and newsletters.
- *Search-based*: the keyword phrases people type into Google, YouTube, Quora or Pinterest. Each phrase is its own congregation (e.g., potato-gun phrases had 18,000+ searches/month). List your best-guess phrases now and refine them with tools later.

**Market → Submarket → Niche expansion**: fixes the "I'm stuck at a Dream dozen" problem.
- How: take the core market (wealth), then the submarket (marketing), then your niche (sales funnels). Fill the list with every *other niche* in your submarket, since that is your warmest traffic. Prompt: "What other vehicles are people using to get [result] inside [submarket]?" Examples: real estate → flipping, short sales, wholesaling; weight loss → keto, vegan, carnivore, bodybuilding; parenting → homeschooling, baby sign language, sports, drama.

## Key Concepts
- **Congregation**: an existing gathering of Dream Customers (site, group, list, show, keyword).
- **Dream 100**: the list of congregation owners or targets. Aim for 100+ and let it grow (Brunson's grew to 736).
- **Tribe owners**: people who already hold your customers' attention (Rachel Hollis DMed anyone with 200K+ followers).
- **Traffic isn't created**: it already exists; your job is to tap existing streams.
- **Interest-based vs. search-based congregation**: targeted by who people follow vs. what they type.
- **Warmest traffic**: other niches inside your own submarket.
- **Dream 100 worksheet**: one column per network or platform, plus a search-phrase column.

## Mental Models
- Think of each congregation as a barrel full of your fish. Your job is to throw hooks into it.
- Use one-to-one when a single customer is worth the cost of courting them; use one-to-many when you need to reach thousands.
- Think "complement, don't compete": the Dream 100 is also your market research (choosing markets, blue oceans, modeling offers).
- Treat traffic as a numbers game. From 100 names, expect ~5–10 free promoters and ~10 more audiences you can target with ads.

## Anti-patterns
- **Asking "how do I get traffic?"**: the wrong question. Ask where your customers are.
- **One combined list for all platforms**: ignores how people prefer to consume media.
- **Stopping at a Dream dozen**: too few names given the conversion math.
- **"It works for books but not my business"**: it works for local businesses too. A juice bar's Dream 100 would be local gyms, health-food stores, chiropractors, trainers and nutritionists.
- **Treating the list as static**: rebuild it 2–3 times a year, dropping names that don't bring the right customers.

## Worked Example
*DotCom Secrets* launch Dream 100: 10 websites/forums, 15 Facebook groups, 50 FB/IG influencers, 30 podcasts, 40 email newsletters, 20 blogs and 20 YouTube channels. That's 185+ communities with about 30M combined followers. Brunson mailed each owner the book with a letter asking for launch-day promotion. John Lee Dumas (EOFire) interviewed him, and that one episode sold 500+ books in a week. More than 30 of the 185 became partners. Non-responders (e.g., Tony Robbins, then 3.2M followers) were reached with interest-targeted Facebook ads. Total: 100K+ books sold. Quest Nutrition used the same play with handwritten letters and free samples to several hundred fitness influencers, on the way to becoming a billion-dollar company.

## Key Takeaways
1. List your Dream Customers' top websites, forums, FB groups, influencers, podcasts, newsletters, blogs, YouTube channels and search keywords.
2. Record each congregation's audience size to see the total reachable market.
3. Build a separate Dream 100 (20–100 names) for each platform.
4. Expand the list with the market → submarket → niche "other vehicles" question.
5. Aim for 100+ names, since only ~10% will promote you for free.
6. Rebuild the list 2–3 times per year.

## Connects To
b3-ch01 (Dream Customer), b3-ch04 (Work/Buy Your Way In), b3-ch07 (infiltrating the Dream 100), b3-ch11 (Facebook interest targeting), b3-ch12 (Google search congregations), b3-ch15 (conversation domination), b3-ch18 (affiliate army), b2 Expert Secrets (market/submarket/niche).
