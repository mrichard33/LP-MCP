# Traffic Secrets — Secret 18: Your Affiliate Army

## Core Idea
Rather than becoming the world's best traffic driver, recruit your Dream 100 (and your customers) as commission-only affiliates who run ads, send emails, and rank pages for you. You pay only after a sale, and paying generously is how you win the top affiliates.

## Frameworks Introduced

**The 5-step Affiliate Army process**: (1) Recruit your army of affiliates; (2) Make them affiliates; (3) Give them a reason to promote; (4) Train them to become super affiliates; (5) Compensate them.
- When to use: once your funnel converts and you have (or are building) Dream 100 relationships.
- Why it works / failure mode: it blends working your way in (the relationship earns the yes) with buying your way in (you pay per sale), and the risk sits with the affiliate. It fails if you never "dig your well before you're thirsty," or if you pay as little as possible.

**Step 1: Recruit.** Dream 100 lists are your affiliate prospect lists, because each member owns a distribution channel. Expect a funnel of roughly **100 asked → 30 yes → 15 actually promote**. Send Dream 100 packages (Chet Holmes, popularized by Dana Derricks), since one yes can be worth millions. Motivations differ: some want conversion rates, some want audience fit. Serve both.

**Step 2: Make them official.** Use an affiliate platform (ClickFunnels' **Backpack**) for signup pages, tracking links, and commission payouts. Recruit customers too: put the affiliate signup link on thank-you pages, in funnels, and in emails.

**Step 3: A reason to promote now.**
- **New launch**: 2–3 new front-end products a year. Recruit 60–90 days out. Get dates blocked on partners' calendars. Put committed affiliates in a private Facebook group with leaderboards and contests.
- **Rolling launch**: each affiliate gets their own date (for ClickFunnels, a dedicated webinar per affiliate, 2–3 a week for months). It lasts longer, fits partners' calendars, and spreads customer-support load.
- **Something special or new**: custom landing pages, offers, or higher commission for SEO/PPC specialists or top performers.

**Step 4: Train.** Build an **affiliate center** with (a) training for new affiliates (running ads, tracking) and (b) copy-and-paste swipes (emails, banners, Facebook posts) for "lazy" super affiliates. The best affiliates are busy and need it done for them. Beginners need to be taught.

**Step 5: Compensate** (percentage of sale or flat CPA)
- **Rule of thumb: pay 50% of the profit.** Digital product: assume about 20% fulfillment, so split the remaining 80% (about 40% to the affiliate). Physical product with 60% COGS: split the remaining 40% (about 20%). Front-end funnels: 100% or more of the front-end price, because the value ladder earns it back. Brunson has paid $80+ per free book.
- **Guardrail**: stay at or under 100% on front-end offers until you know customer lifetime value and can float cash while follow-up funnels work.
- Why it works: top affiliates "don't need you, you need them," so the highest payer gets the best affiliates.

## Key Concepts
- **Affiliate**: a commission-only partner who carries the ad risk and shares the reward.
- **Super affiliate**: a high-performing affiliate who is often too busy to build their own promos.
- **Dream 100 package**: a mailed attention-grabber that recruits partners.
- **Rolling launch vs. launch**: staggered individual dates vs. one open/close window.
- **Flat CPA**: a fixed payout per sale or lead, used to motivate affiliates on break-even front ends.
- **Dream Car bonus**: a recurring bonus for recruiting milestones, modeled on network marketing car programs.
- **Recurring commission**: an ongoing percentage of subscription revenue.

## Mental Models
- Think of affiliates as a commission-only sales team you don't manage day to day. Your job is recruiting, arming, and paying them.
- Pay the most you can afford, not the least you can get away with. Commission rate is a competitive weapon.
- Use the front end as a loss leader for affiliates when LTV and follow-up funnels are proven.

## Anti-patterns
- **Asking strangers cold at launch time**: you have to dig the well first (Tim Ferriss spent a year befriending bloggers before sending 1,000+ advance copies of *The 4-Hour Workweek*).
- **Taking "no" or no-shows personally**: it's a numbers game, so ask more people.
- **Under-paying compared with competitors**: you lose the top affiliates.
- **Paying more than 100% on the front end before knowing LTV**: cash-flow risk.

## Worked Example
**ClickFunnels compensation build**: competitors paid 20–30%, so ClickFunnels launched at **40% recurring** and pulled in their top affiliates. **Dream Car bonus**: at 100 members × $100/month, a $500/month bonus (about 5%) covers a car lease, and 200 members earn $1,000/month. **Dotcom Secrets book funnel**: the book was free plus $7.95 shipping, and upsells averaged about $20 per buyer, while Brunson's own Facebook ads cost about $20 per book (a break-even funnel). He first paid affiliates 50% of the funnel plus 40% recurring on later ClickFunnels upgrades. In the final launch week he switched to a flat **$20 CPA per book**. Affiliates moved tens of thousands of books, Brunson broke even, and thousands of ClickFunnels members came in at no net cost.

## Key Takeaways
1. Treat your Dream 100 as your affiliate prospect list. Ask widely and expect about 15% to actually promote.
2. Put an affiliate program on every funnel and invite customers from thank-you pages and emails.
3. Always give a reason to promote now: a dated launch, a rolling slot, or a custom deal.
4. Ship an affiliate center with training and ready-to-paste swipes.
5. Pay about 50% of profit on core offers and up to 100% (or a flat CPA) on front ends once LTV is known.
6. Add milestone bonuses (e.g. a car bonus) to attract top affiliates.

## Connects To
b3-ch02 (Dream 100), b3-ch04 (work/buy your way in), b3-ch07 (digging the well), b3-ch17 (distribution channels), b3-ch20 (built-in affiliate badge), b1-ch03 (value ladder, break-even front ends), b1-ch07 (follow-up funnels), b2 (Perfect Webinar in rolling launches).
