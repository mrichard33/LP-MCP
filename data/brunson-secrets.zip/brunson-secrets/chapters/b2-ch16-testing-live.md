# Expert Secrets — Secret 16: Testing Your Presentation Live

## Core Idea
A presentation becomes a predictable cash machine only after you deliver it live over and over, mining attendee questions and fixing confusion points each time. Run the same webinar live every week for a year (or until it hits the Two Comma Club) before automating it. "Take the show on the road" instead of writing a new show each month.

## Frameworks Introduced
**Take the Show on the Road (Mary Ellen Tribby)**: marketers launch a great "Broadway show" in one town, then tear it down to write the next one. Instead, keep touring the winning show to new audiences until it stops making money.
- When to use: when you have one presentation that converts.
- How: drive new traffic to the *same* webinar every week, and don't build funnel #2 until funnel #1 reaches the Two Comma Club ($1M).
- Why it works / failure mode: repetition turns close rate into a known constant, so revenue becomes attendance × close rate × price. The failure mode is recording once and automating, which leaves real objections undiscovered.

**Live Presentation Model (weekly cycle)**: Mon–Thu promote (email, Facebook ads, JV partners) → Thursday live webinar and offer → Fri/Sat/Sun replays with urgency → cart closes Sunday midnight → Monday repeat.

**Live Presentation Webinar Funnel (8 steps)**:
1. Traffic to the registration page. Curiosity is everything: a "How to X without Y" headline, an odd but related photo, no video (or split-test without one), and urgency/scarcity.
2. Thank-you page with a passion video plus a **Self-Liquidating Offer (SLO)** ($37–$47, or a free/$1 trial) to cover ad costs, raise show-up, and create buyers in motion.
3. Indoctrination emails/videos, one per secret, each pre-selling the false belief the framework fixes without answering it. They amplify the sale but aren't essential to it.
4. Reminders: the day before, the morning of, 1 hour before, 15 minutes before, and "we're live" (email plus SMS).
5. Present live (Thursday for Brunson; daytime for entrepreneurs, evenings for 9-to-5 markets; GoToWebinar/Zoom).
6. Follow-ups Fri–Sun: replay link, PDF cheat sheet or slides, urgency. This usually *doubles* sales.
7. Close the cart Sunday at midnight (buy buttons and replay removed).
8. Repeat Monday.

**Question-mining iteration loop**: after each live run, export chat questions and comments, find the four or five points of confusion or offer ambiguity, and add slides that answer them before they're asked.

## Key Concepts
- **Two Comma Club**: $1M in funnel revenue, the gate before building another funnel.
- **Show-up rate**: about 25% of registrants. Below that, strengthen indoctrination and reminders.
- **Cost per registrant**: target $3–$5. At $7–$8 front-end profit gets hard; above target means the page, message, or targeting is off.
- **SLO**: a low-ticket offer on the thank-you page that liquidates ad spend.
- **Buyers in motion**: someone who buys before the webinar is more likely to buy on it.
- **Close rate benchmarks**: 5% = good and likely front-end profitable; 10% = a million-dollar-a-year webinar; 15% = about $10M in the first year (Funnel Hacks).
- **Automating too soon**: the major mistake. Funnel Hacks ran 60+ times live over 12 months before automation.

## Mental Models
- Think of each live run as a free focus group where the questions are your rewrite list.
- Use pitch-time headcount × known close rate × price to forecast revenue (250 on at minute 60 × 15% × $997 ≈ $37.5K).
- Treat a 10% vs. 15% close rate as the difference between a seven-figure and an eight-figure webinar. Small hinges swing big doors.

## Anti-patterns
- **Record once, automate forever**: you never learn the objections.
- **Serial funnel launching**: good paydays, but nothing sustainable gets built.
- **Revealing too much on the registration page**: if they think they know the answer, they won't register or show up.
- **Quitting after a bad first run**: Liz Benny had zero attendees on her first webinar and still reached the Two Comma Club in year one.
- **Scaling ads before knowing conversion**: start with at least 100 live attendees (about 300 registrants) on a small budget.

## Worked Example
Weekly target: 1,000 registrants at $3 = $3,000 ad spend → 250 attend (25%) → 25 buy live at $997 (10%) = $25K → 25 more buy from replays = $25K → $50K sales − $3K ads = $47K net, plus 1,000 new leads a week. Iteration proof: first partner webinar had ~600 live and $30K sales. After mining questions and adding slides, the same-day rerun to ~500 people did $120K+. The original stage debut closed over one third of a ~100-person room on a $1,000 ClickFunnels bundle, and adding non-supplement examples after one attendee's objection closed three more. The funnel-hacks thank-you page trial produced 15,000+ trials, 4,500 active, about $450K/month recurring.

## Key Takeaways
1. Commit to one presentation live weekly for 12 months (or until $1M) before building anything new.
2. After every run, export the questions and patch the confusing slides.
3. Hit $3–$5 per registrant, 25%+ show-up, and a 5%→10%→15% close-rate ladder.
4. Put an SLO ($37–$47 or trial) on the thank-you page to self-fund ads.
5. Use Fri–Sun replay urgency and a hard Sunday-midnight close. Expect replays to double sales.
6. Automate only when the objections are covered and the numbers are predictable.

## Connects To
b1-ch15 (webinar funnels), b1-ch22 (Perfect Webinar script), b2-ch12 (registration headline formula), b2-ch13 (indoctrination videos per secret), b2-ch14 (Q&A slide), b2-ch17 (shortcut version), b3 (Dream 100 and JV partners for traffic; paid ads).
