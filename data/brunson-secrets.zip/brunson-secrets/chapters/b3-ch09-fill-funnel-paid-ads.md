# Traffic Secrets — Secret #9: Fill Your Funnel with Paid Ads (Buying Your Way In)

## Core Idea
Paid ads are lighter fluid on the charcoal of your organic work. They get you off the "traffic roller coaster" of promotion spikes and make growth predictable. The strategy (credited to ClickFunnels' paid-ads lead, John Parks) is the same on every network. Create large volumes of **prospecting** creative to hook cold Dream Customers, then move the people who engage through **retargeting** audiences (Engaged → Landed → Owned) using emotion → logic → fear. With a break-even funnel, you have no ad budget.

## Frameworks Introduced
**No Ad Budget / $100 Test**: if the funnel breaks even or better, every dollar comes straight back, so the goal is to spend as much as possible *profitably*.
- How: launch each new funnel with a **$100** test. If sales ≥ $100, scale it. If not, turn it off, rework the funnel (hook, story, offer), and test again with another $100. Never put much money at risk at once.

**Step 1: Prospecting Ads (volume of creative)**: reach cold traffic and hook them long enough to engage.
- When to use: always. Prospecting is what fills the retargeting pools.
- How: become prolific. Dean Graziosi's team outsold Brunson's 5,000 to 1,200 books per week mainly by running about 4× more creative, making new phone-shot ads every day (at a softball game, at home, at the airport, at dinner). Each hook attracts a different slice of the market and wears out fast, so keep feeding new ones.
- Targeting, in priority order: (1) **Dream 100** interest targeting (FB/IG: followers of a thought leader, brand or celebrity; YouTube: placements on Dream 100 videos or channels); (2) **Ideal customer avatar** (interests, age, career, home life); (3) **Overlapping audiences**, where the viewer must match all criteria (e.g., Tony Robbins follower AND business owner AND woman aged 35–55); (4) **Algorithms**: once a few hundred people have engaged, converted or bought, seed **Lookalike** (FB/IG) or **Similar** (Google/YouTube) audiences.
- Why it works / failure mode: more hooks mean more "fish" pulled from the ocean. Failure mode: chasing one perfect ad, which fails half the time and burns out fast.

**The 80/20 Rule of Prospecting**: expect about 80% of spend on cold prospecting to produce about 20% of results, and about 20% of spend on retargeting and followers to produce about 80%.
- Failure mode: shutting off prospecting because the cost per sale looks high. That empties your retargeting pools.

**Step 2: Retargeting Funnels (the three audiences)**: place a **pixel** on every funnel page to track progress and feed the algorithm.
| Audience | Who | Window | Ad job |
|---|---|---|---|
| **Engaged** | watched, liked or commented, stayed on the platform | up to **5 days** | hook + story that *sells the click* |
| **Landed** | visited the funnel, didn't opt in or buy | up to **7 days** | *sell the opt-in or purchase* |
| **Owned** | leads and buyers | ongoing | *sell the next step*: another front end or the next rung of the value ladder |
People who don't act fall back into the prospecting pool (the "conveyor belt" model). Build retargeting ads once, like a Soap Opera Sequence, and sequence them emotion → logic → fear/urgency/scarcity.
- Why it works: most engaged people never opt in, and retargeting follows up with those who never gave you an email address. Running ads to your owned list also reaches the roughly two-thirds who don't open emails.

## Key Concepts
- **Prospecting ads**: ads to cold audiences who don't know you. The most expensive kind, but essential.
- **Retargeting ads**: ads to people who have already engaged, landed or converted.
- **Creative**: individual ad assets (images or videos); volume is the lever.
- **Pixel**: tracking code that records how far each visitor got.
- **Custom audience**: a platform audience built from pixel or engagement data.
- **Lookalike / Similar audiences**: algorithm-built audiences modeled on your converters.
- **Audience layering**: targeting only the overlap of several criteria to cut costs.
- **Traffic roller coaster**: launch spikes followed by droughts when you rely only on affiliates and promotions.

## Mental Models
- Think of prospecting as fishing an ocean where everyone has a different reason to bite, so throw many hooks.
- Use retargeting windows as conveyor belts: move people forward or drop them back into prospecting.
- Treat any break-even funnel as "unlimited budget." Treat any losing funnel as "back to the drawing board after $100."
- Use your phone as an ad factory: every location is a chance to record a pitch.

## Anti-patterns
- **Hunting for the one perfect ad**: it fails half the time and fatigues quickly.
- **Stopping prospecting to save money**: retargeting pools dry up.
- **Retargeting Engaged viewers forever**: cap it at about 5 days (Landed at about 7) so you don't waste spend.
- **Big untested budgets**: risk $100 at a time until the funnel is proven.
- **Letting a hired buyer own the strategy**: tactics can be outsourced; the entrepreneur must understand the strategy.

## Worked Example
LeadFunnels.com $100 test: a $7 report + $37 order bump + $100 OTO. $100 of Facebook ads gave about 100 clicks, 7 report sales ($49), 2 bumps ($74) and 1 OTO ($100) = **$223 in revenue, +$123 net**, so the funnel was scaled with no fixed budget.
Retargeting math (John Parks): $2,000 in spend → 100,000 views → 4% engage (4,000) → 2% click (2,000) → 30% opt in (600 leads) → 10% buy (60 buyers). That leaves **3,940 engaged non-converters** for Engaged/Landed retargeting.

## Key Takeaways
1. Test every new funnel with $100 in ads. Scale the winners; rework and retest the losers.
2. Produce new ad creative daily (phone videos anywhere) and keep dozens of hooks running.
3. Target Dream 100 interests first, then the avatar, then layered overlaps, then lookalikes once you have a few hundred conversions.
4. Pixel every funnel page and build Engaged (5-day), Landed (7-day) and Owned audiences.
5. Write retargeting ads once in an emotion → logic → fear sequence, matched to each audience's job.
6. Expect about 80% of spend on prospecting for about 20% of results. Don't turn it off.
7. Always run ads to your owned lists and followers; they're the cheapest conversions.

## Connects To
b3-ch04 (Buy Your Way In, break-even / ACV), b3-ch05 (Traffic You Own), b3-ch06 (follow-up funnels, three closes), b3-ch03 (Hook Story Offer for creative), b3-ch10 (Instagram ads), b3-ch11 (Facebook ads), b3-ch12 (Google), b3-ch13 (YouTube), b3-ch19 (cold traffic), b1-ch03 (value ladder), b1-ch07 (follow-up funnels).
