# Dotcom Secrets Secret 21: The OTO Script

## Core Idea
The buyer is already sold on you—don't resell them. A one-time-offer (OTO) upsell should confirm the first purchase and ask for a quick second "yes" with a short (3–5 minute) video focused on one key benefit. Rewriting a dozen 20–30 minute upsell videos to this structure took Russell's upsell conversions from near zero to double digits, on price points from $27 to $997+.

## Frameworks Introduced

**OTO Script**:
- When to use: The upsell page immediately after any front-end purchase (book, cart, VSL, webinar order).
- How:
  1. **Confirm the initial decision (keep the loop open)** — congratulate, but say the order isn't finished yet; don't close the browser.
  2. **Smart, here's why** — reinforce why buying was a great decision.
  3. **Question: next or more** — info products: "now that you have X, people ask me about Y" (next problem). Physical products: "want more at a big discount?"
  4. **Exclusive** — not for everyone; available only because they proved they're an action taker.
  5. **Results, fast** — this complements the original purchase to deliver the result faster.
  6. **The one thing** — pick the single most valuable element and explain only that (what it is, results it produced, what they can expect); say there's too much else to cover.
  7. **Future pacing** — imagine life with that one thing.
  8. **Call to action** — click to add it to the order.
  9. **Guarantee** — reverse risk.
  10. **Value stacking** — list other components, each "worth $X, free if you act now"; say "free" as often as possible.
  11. **Scarcity** — sold elsewhere at a higher price; this page only; gone when they leave.
  12. **Second call to action.**
  13. **Testimonial rush** — stacked testimonials from people who took the offer.
- Why it works: The first yes is already won; the job is consistency—confirm, then offer the logical next step.
- Failure mode: The "cardinal upsell mistake"—running another full Star, Story, Solution pitch that re-litigates trust.

**Choosing the OTO Offer**:
- Info product front end → the product that solves the *next* problem they now face (book on funnels → funnel software or traffic course).
- Physical product front end → more of the same at a discount (see b1-ch12).

**Open-Loop Language**: replace "Congratulations, your order is complete" with "Wait, your order is not yet complete"—the closed-loop phrasing tells the brain the buying session is over.

## Key Concepts
- **OTO (one-time offer)** — upsell shown once, immediately post-purchase.
- **Second yes** — easier than the first because trust exists.
- **Open loop** — language that keeps the purchase session psychologically unfinished.
- **The one thing** — single key element that drives the result; the only feature you explain.
- **Next vs. more** — next-problem offer vs. more-of-the-same offer.
- **Value stacking with "free"** — bonuses framed as free with the order.
- **Testimonial rush** — rapid sequence of proof at the end.

## Mental Models
- Think of an upsell as a confirmation, not a conversion.
- Use "what problem does my product create next?" to pick the OTO.
- Think one-thing depth beats everything-breadth on an upsell.

## Anti-patterns
- **Reselling who you are**: they already bought; 20–30 minute upsells tank.
- **"Your order is complete" before the OTO**: closes the loop.
- **Explaining everything in the product**: kills the sale; teach one thing.
- **Fake scarcity**: make it genuinely one-time on this page.

## Worked Example (fill-in template)
- "Congratulations on getting [front-end product]—don't close this page, your order isn't quite finished."
- "You made a smart choice, because [reason it gets them result]."
- "Let me ask you: now that you have [product], many people ask me about [next problem]." / "Would you like more of [product] at a huge discount?"
- "This isn't for everyone—only action takers who grabbed [front end]."
- "What I'll show you helps you get [result] in a fraction of the time."
- "Inside [OTO product] there's too much to cover, but one strategy will give you [result] fast: [one thing]. Here's how it works… and that's just one piece."
- "Imagine when you have [one thing]."
- "Click below to add [OTO] to your order." + guarantee.
- "Act now and also get [bonus] worth $[X] free, [bonus] worth $[Y] free…"
- "It sells for $[higher] on our site; here only $[price]. Leave this page and it's gone."
- Repeat CTA → testimonials.

Russell's example: the Perfect Webinar system OTO had 24+ hours of video, but the pitch focused only on one video teaching "the stack."

## Key Takeaways
1. Keep OTO videos to 3–5 minutes.
2. Open with confirmation and "your order isn't complete yet."
3. Offer the next logical solution (info) or more at a discount (physical).
4. Sell one standout element; stack the rest as free bonuses.
5. Use genuine one-time scarcity, two CTAs, and a testimonial rush.

## Connects To
b1-ch11 (book funnels), b1-ch12 (cart funnels), b1-ch14 (VSL funnels), b1-ch20 (Star Story Solution front-end pitch), b1-ch22 (the stack), b1-ch28 (OTO/downsell benchmarks 3–15%), b1-ch03 (value ladder ascension), b2-ch05 (irresistible offer).
