# Chapter 4: Stage #1 Copy Formulas

## Core Idea
Stage #1 (Indifferent) prospects don't know they have the PROBLEM, or don't see it as critical and urgent. A Webinar Funnel, which the author calls a "Workshop" or "Masterclass" because "webinar" now means "pitch," wakes them up with crisis, curiosity and myth-busting, turning them into Stage #2 prospects.

## Frameworks Introduced
**Stage #1 Objections and Rebuttals**
- "I don't have that problem" → make the PROBLEM **relevant**
- "It isn't that serious" → make it **critical**
- "It's serious, but I can wait" → make it **urgent**

**Webinar Ad/Post Formula (Attention → Curiosity → Objections → Action)**: for any traffic piece (paid ad, post, blog, video, email).
- Why it works: it moves the reader through relevance, then critical and urgent, then defused doubts, then an urgent action. Failure mode: clever "pick-up line" hooks that aren't tied to symptoms the reader feels every day.

**High-Value vs Low-Value Curiosity**: attach a curiosity seed to a PROBLEM they want to solve or avoid, or a BENEFIT they want. Novelty-only hooks ("Weird weight loss trick") attract curiosity seekers, not buyers.

**Breadcrumbing**: resolve one curiosity while opening the next, so attention moves from section to section.

**Three Webinar Openings**: Story, Hypnotic (five senses), Pain vs Promise. Most people leave in the first 5–10 minutes or at the pitch transition.

**Three Story Formulas**: Hero's Journey, Conspiracy, Tragic Teacher ("Blackie").

**Webinar Funnel Elements (11)**: 1 Ad/Post, 2 Registration Page, 3 Opening, 4 Storytelling, 5 Myth-Busting (these turn Stage #1 into Stage #2), 6 Solution Pitch (#2→#3), 7 Offer Positioning (#3→#4), 8 Offer Stack, 9 CTA, 10 Post CTA (#4→customer), 11 Power PS.

## Copy Formulas

### Webinar Ad: Attention
Callout: ATTENTION [AUDIENCE]!
"Are you [SYMPTOM 1]?" / "Do you often feel [SYMPTOM 2]?" / "Have you noticed [SYMPTOM 3] lately?"
(Optional) These can escalate into [CONCRETE, EMOTIONAL CRISIS] if the PROBLEM is left alone or mistreated.
Transition: "If you want to [avoid CRISIS / get PROMISE], then [this could be the most important secret…]"

### Webinar Ad: Curiosity
Your Workshop reveals how to solve [PROBLEM] and get [PROMISE], plus a surprising link between [SYMPTOMS] and [CRISIS].
"Here's what you'll learn:"
- Why [AUDIENCE] has [PROBLEM] (tease the cause)
- How critical [PROBLEM] gets if unsolved or mistreated
- Why it's urgent and they can't wait
- A hint at the real [SOLUTION]
Close: "By the end you'll have [SOLUTION tied to PROMISE] without [EXTERNAL OBJECTION], even if [INTERNAL OBJECTION]." Keep both objections specific and real.

### Webinar Ad: Objections
"This Workshop is NOT about:" [MYTH 1] / [MYTH 2] / [MYTH 3] (tired clichés)
"This Workshop reveals:"
- How to get around the usual obstacles to [PROBLEM]
- What you *won't* have to do
- Why it works despite past failures or current doubts
- Why it works "no matter…" how often you've failed or how skeptical you are
"You'll FINALLY understand how [AUDIENCE] really solve [PROBLEM] without [hassles]." Soft CTA hinting at evidence (a story or statistic) revealed in the Workshop, plus a [LINK] for skimmers.

### Webinar Ad: Action
"If [PAIN/desire], then attending is the smartest thing you've done in years."
CTA covers 1) exactly what to do, 2) why, 3) why now (limited seats).
PS: bonus or premium for acting now, with scarcity (e.g. first 10 registrants).

### Registration Page
Eyebrow: PRIVATE WORKSHOP: [TITLE]
Headline: curiosity seed attached to [PROBLEM to solve/avoid] or [BENEFIT]. Patterns: "The #1 [MISTAKE] That [causes PROBLEM]" / "WARNING: This [THING] [causes PROBLEM]" / "Discover How [odd THING] [delivers BENEFIT]"
Four bullets: 1) PROBLEM and why it's critical and urgent 2) most common MYTH 3) foreshadow the SOLUTION 4) handle an EXTERNAL or INTERNAL OBJECTION
Button (split-test the three CTA types): DIRECT "Click Here to Register Now" / DIALOGUE "Yes, Show Me The Secrets!" / OUTCOME "Register Now to Discover These Secrets"

### Opening: Story Opening
"You're here because [desire to solve PROBLEM / get BENEFIT + curiosity seed]. If that's you, here's why [watching to the end will be the best decision you've made]…" (open loop)
"My name is [NAME]" + brief credentials. Don't overdo it.
Then either (a) **damaging but redeemable admissions** ("you and I are a lot alike… I'm not naturally [X]… yet I discovered [system] that [RESULT]"), or (b) **us vs them** ("you've probably been secretly suspicious of [AUTHORITY's advice]…").
"The story you're about to hear [how it benefits them]…"
"By the end of this webinar you'll [PROMISE] without [EXTERNAL OBJECTION], even if [INTERNAL OBJECTION]." (resolve one loop, open a new one)
Always open with a crisis: physical, financial, social or existential.

### Opening: Hypnotic Opening
Direct attention to something the PROBLEM affects, then ask 1–3 sensory SYMPTOM questions ("Do you see / hear / feel [SYMPTOM]?")
"If [so], here's why [CRISIS]…"
Recall a SYMPTOM plus a **double tie-down**: "You know [SYMPTOM]? It [gets worse at X], doesn't it?"
Logical evidence foreshadowing the cause (don't reveal it) → "This is why [another SYMPTOM detail]" → it's an early warning of [CRISIS]
"If [worried], here's why you need to watch to the end…"
Show the symptom through a sensation they can't deny. Don't just tell them they have it.

### Opening: Pain vs Promise Opening
"Are you… / Do you often feel… / Have you noticed… lately" [SYMPTOMS] → escalating [CRISIS] → "If you answered YES, here's why…"
"My name is [NAME]" + brief credentials.
"In the next [__] minutes / by the end, you'll discover why [PROBLEM] is more critical and urgent than you realize, and why [common advice] doesn't fix it and may make it worse." Optionally: "even [ASSUMED ADVANTAGE] won't save you."
"The good news is… a [shortcut/system/loophole/framework] that [PROMISE] without [EXTERNAL OBJECTION], even if [INTERNAL OBJECTION]." Swap "best" for how-words such as "the safest, quickest…" (see the "Super Seven"; the book points to Chapter XI).
The same contrast also works in headlines and CTAs. The author suggests an hour a day for a year writing headlines, CTAs and openings in this pattern.

### Storytelling
**Hero's Journey**: Desire → Resistance → Failure → Insight → Success → Contribution (leads into the offer). The audience must relate to Desire, Resistance and Failure.
**Conspiracy** (saturated B2C markets or deep-pocketed rivals; avoid for B2B unless selling to entrepreneurs): Desire → Resistance (a clue of the Conspirator's hidden agenda) → Persecution → Discovery (the secret is their weakness or source of power) → Success (narrow escape optional) → Contribution + Epilogue. It must confirm an existing suspicion, give them an enemy, and tell them they're not alone and their failure isn't their fault. Segue: "If you secretly suspected [X], you're not alone… once you understand the myths pushed by [ENEMY], you'll never be fooled again."
**Tragic Teacher / Blackie** (expert positioning in info-saturated markets): Desire → Resistance → Encounter (a reluctant Teacher agrees) → Overconfidence (rebuked) → Tragedy (the ill Teacher entrusts the secret and the mission) → Contribution. The Teacher must seem like a true, rare authority, though not necessarily a famous one.
Don't have AI write stories from scratch. Record and transcribe an interview with the person who lived it, then use AI to polish.

### Myth-Busting
"You've probably heard / [EXPERT] will tell you / Many people believe [MYTH] will [promised outcome]."
"What you haven't heard / what they won't tell you is [FLAW/catch]." (add a stat)
"This is why [what the AUDIENCE, or people they see, experience because of the MYTH]."
Between myths: "Do you really want to keep paying [cost of MYTH]?" or a metaphor, anecdote, quote or joke.
Final myth: rhetorical bridge. "So if it's not [MYTH 1], [MYTH 2] or [MYTH 3], how do you [PROMISE]?" This leads into the Solution Pitch (ch05).
"Lies" instead of "myths" works only in low-trust markets. Too much conspiracy tone attracts junk prospects.

## Key Concepts
- **Curiosity seed**: the mysterious element (mistake, product, secret) the reader must keep reading to uncover.
- **Curiosity seekers**: responders with no intent to buy. Low-value curiosity makes this worse.
- **Open loop**: an unresolved question. Strong in webinars and VSLs, weaker on scanned sales pages.
- **Double tie-down**: a statement plus a tag question that makes the prospect confirm the symptom.
- **Early (soft) CTA**: serves readers who want to skip ahead while others keep reading.
- **"Secret" naming**: refer to the OFFER as a shortcut, system, habit, loophole or framework that clearly signals what it does.

## Mental Models
- Use crisis-first stories and openings when prospects are in denial. Being nice doesn't wake them up.
- Use Conspiracy when the market is saturated and suspicious. Use Blackie when you need one-of-a-kind authority. Use Hero's Journey by default.
- Use pain vs promise contrast anywhere: headlines, CTAs, openings, emails.

## Anti-patterns
- **Pitching solutions or brand superiority to Stage #1**: they don't care yet.
- **Low-value curiosity headlines**: they draw non-buyers.
- **Long presenter bios**: keep it to one line plus credentials.
- **Telling rather than showing the symptom**: use sensory proof.
- **Vague objections**: EXTERNAL and INTERNAL objections must be concrete and real.
- **AI-invented origin stories**: they lose authenticity and grit.

## Worked Example
Ad for weightlifters aged 35–50. "ATTENTION Weightlifters 35 to 50! Noticed more back pain lately? Stuck on squat and deadlift plateaus? Compound lifts flat for months? These are early signs of a biological change that can lead to injuries, arthritis, bone loss, even early dementia. If you want to slow or reverse it…" Then: "We're inviting 50 people to a Private Virtual Workshop…" with four learn-bullets. "NOT about: spreadsheet workout formulas / mobility routines and pills / generic form lectures." "Reveals: activate 'switched off' muscles / a 90-second warm-up / works even after 10+ years of pain / a custom plan." CTA: seats limited to 50. PS: a free custom meal plan for the next 10 registrants.

## AI Training
There is a link to "AI Training on Stage #1 Copy." Its purpose is to generate webinar ads (including shorter test versions and retargeting for visitors who didn't register), registration pages, openings, and story polishing from interview transcripts. No prompts are printed.

## Key Takeaways
1. Stage #1 copy has three jobs: make the PROBLEM relevant, critical and urgent.
2. Ads follow Attention → Curiosity → Objections → Action, with the "Are you / Do you often feel / Have you noticed" symptom triad and an if/then bridge.
3. Attach curiosity to a problem or benefit (high-value curiosity) and breadcrumb from section to section.
4. Registration page = eyebrow + curiosity headline + 4 bullets (problem, myth, solution, objection) + a split-tested CTA type.
5. Open with Story, Hypnotic or Pain vs Promise, always starting from crisis.
6. Choose the Hero's Journey, Conspiracy or Tragic Teacher story by market saturation and positioning needs.
7. Myth-busting (heard → haven't heard → this is why → bridge question) sets up the Solution Pitch.

## Connects To
ch03 (Stage #1 → Webinar Funnel; 12 variables), ch05 (Solution Pitch, VSL reuses openings and stories), ch06 (Offer Positioning/Stack), ch07 (CTA, Post CTA, Power PS, retargeting), ch08 (show-up reminders), ch11 (split-test CTA types), bonus3 (headlines)
