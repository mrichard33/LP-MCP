# Chapter VI: Stage #3 Copy Formulas

## Core Idea
Stage #3 (Comparing) prospects know their PROBLEM, are sold on a specific SOLUTION type, and are looking for the best provider. A Trip-Wire (Low-Ticket) Funnel wins them by proving the four trust points (Convenience, Charisma, Competence, Character) through Offer Positioning and an Offer Stack. At this stage the No-Brainer Offer matters more than the copy.

## Frameworks Introduced
**Stage #3 Objections and Rebuttals**: "Are you competent?" → make a bold guarantee. "Are you trustworthy?" → tell your company story. "Can I get this somewhere else?" → introduce your USP. In addition, be likable and memorable (Charisma) and easy to buy from (Convenience). Confusing or hard-to-act-on CTAs sink otherwise good funnels.

**Trip-Wire Ad: Attention → Offer → Action**: keep the Attention section short. These prospects already want the result, and their real question is whether they can trust you, so dwelling on the problem oversells and loses them.

**4 Trip-Wire Openings**: "Two Paths", Hypnotic, Bold Promise, Pain to Promise.
- The **Bold Promise Opening** uses 6 variables: PROMISE, DEADLINE, EXTERNAL OBJECTION, INTERNAL OBJECTION, CONDITIONS, RISK REMOVAL. The rest of the sales letter simply restates, reinforces and reassures on these six. Why it works: it answers "how long, what's the catch, will it work for me, what do I have to do, what if it fails" up front.

**Offer Positioning (5 elements)**: X Factor, Superiority, Relevance, Uniqueness, Qualification. The order is flexible: in low-trust markets lead with Superiority then X Factor, and to filter out bad-fit buyers lead with Qualification. Positioning fixes price shoppers, deals collapsing at close, poor post-purchase participation, and low repeat and referral rates. If prospects still object to price or drop off right after Positioning, one of the elements missed.

**Offer Stack (5 steps)**: Introduction → Value Stacking → Price Reveal → Guarantee → Urgency, driven by **Perceived Value > Perceived Cost**. The Introduction clarifies, Value Stacking raises value, the Price Reveal lowers the financial cost, the Guarantee lowers the intangible cost (time, energy, disappointment), and Urgency makes them act now. The Guarantee sometimes comes before the Price Reveal. The Offer Stack is shared across funnels: after the Solution Pitch (webinar), after Positioning (VSL and trip-wire), and after the Reopening (retargeting).
- Failure mode: a price that seems too low triggers "too good to be true" skepticism.

**USP 3 rules**: Specific (concrete and verifiable, no "quality/service/excellence"), Beneficial (a before-and-after "mind movie"), Unique (a claim competitors can't make without legal consequences, e.g. patents or proprietary mechanisms). A USP explains how you're different, not that you're better.

**Two-guarantee Risk Removal**: one guarantee covers the money and one covers their time (e.g. a refund plus $100). Always attach CONDITIONS (they must use it as directed), and honor it only when they did and didn't get the result.

**Trip-Wire Funnel Elements (8)**: Ad/Post, Squeeze Page, Opening, Offer Positioning, Offer Stack (these take a prospect from Stage 3 to Stage 4), CTA, Post CTA, Power PS (Stage 4 to customer; see ch07).

## Key Concepts
- **Four trust points**: Convenience (easy to buy from), Charisma (likable and memorable), Competence (delivers results), Character (cares about the customer's success).
- **Demographic vs Psychographic Relevance**: shared traits vs shared pains, desires, values and shopping preferences. Together they answer "Is this best for someone like me?"
- **Superiority proof hierarchy**: Results > Reviews > Endorsements > Experience.
- **Surrogate endorsement**: an expert endorses the idea or ingredient your product is built on. It only counts if the AUDIENCE recognizes and respects the person.
- **REDEEMABLE ADMISSION**: sounds damaging but appeals to the right buyer ("Not for Beginners!").
- **Take Away / Qualification**: a reverse-psychology stop sign. It raises perceived value and repels toxic buyers.
- **Social, Time, Money objections**: plus EXTERNAL and INTERNAL, these are the 5 objections your bonus stack should neutralize, one bonus each.
- **External vs Internal Pressure**: limited time or supply vs cognitive dissonance (Internal Pressure is covered in ch07).
- **Dog Whistle Language**: in-group phrases that signal psychographic relevance.

## Mental Models
- Trust, not desire, is the Stage #3 bottleneck. Shorten the problem talk and lengthen the proof.
- Positioning answers the Solution Pitch's X Factor: "our brand fixes the category's flaw."
- The price must feel like a steal, but not too much of one.
- A refund to someone who didn't use the product is a "tax on laziness." A conditional guarantee protects you while still removing risk.

## Anti-patterns
- **Using a Trip-Wire Funnel when you need a webinar or VSL funnel**: the costliest, most common mistake, even among famous coaches.
- **A bad OFFER dressed in good copy**: engagement and time-on-page stay high, but sales don't come.
- **Cliché USPs** ("We stand by our product," "We really care"): vague, unverifiable, and any competitor can say them.
- **Money-back-only guarantees**: they ignore the time and hope the buyer invested.
- **Timid urgency**: always state exactly what happens if they miss the deadline.
- **Social Proof introductions for elite outcomes** (getting rich, an elite physique): "everyone uses it" contradicts exclusivity.
- **Overselling the problem to Stage #3 prospects**: you lose their attention.

## Copy Formulas
**Trip-Wire Ad/Post**
- Attention (pick one): Question w/Contrast ("Do you want [PROMISE] but [INTERNAL/EXTERNAL OBJECTION]?" or "Are you tired of [PROBLEM]? [PROMISE]"), Future Pacing ("Imagine/Picture…"), or If [PROMISE], then [RESPONSE] (a CTA, "would you be interested?", or an impression such as "most important book you've read").
- Offer: [PRODUCT] is the best way to [BENEFIT] by [DEADLINE] without [EXT], despite [INT] + guarantee/risk removal → "Here's what you'll get when you [ACTION]…" bullets covering relevant/personalized, superior (social proof), unique, without [EXT], despite [INT], and risk removal → who it's for + restated PROMISE + optional "I'm so confident that…".
- Action: If ___, then ___ + CTA (exactly what, why, "right now/hurry") + PS: [bonus] + [limited time or supply].

**Trip-Wire Openings**
- Two Paths (best for health, relationships, money, career): two equal characters with the PROBLEM → fast-forward: what they still share + an astonishing difference (unexplained) → "What Was The Difference…" → what it's NOT (MYTHS, ALTERNATIVES, or "even without [EXT], despite [INT]") → reveal an advantage only your OFFER provides → "And that's why…". Modern variant: put "What Made the Difference?" first to frame the story for distracted readers.
- Hypnotic: a sensory description (see, hear, feel, smell, taste; 5 variants) of using the product, or of the end result if using it isn't enjoyable, or a negative version showing the PROBLEM's pain → anchor with "If ___, then [OFFER]". Recommended source: Jack Hart, *A Writer's Coach*, Ch. 9 "Color".
- Bold Promise: optional "Dear [AUDIENCE]" → one of Question w/Contrast / Future Pacing / If-Then series using [PROMISE]+[DEADLINE]+[EXT]+[INT] → optional [CONDITIONS] sentence → "(If ___), here's why…" + [RISK REMOVAL].
- Pain to Promise: 3 SYMPTOM questions ("Have you noticed…", "What is ___ doing to your…", "Can you really afford to keep…") + Bold Promise.

**Offer Positioning**
1. X Factor: "[PRODUCT] is a [SOLUTION] that/with…" [BENEFITS for webinar/VSL; features for trip-wire] → how it was made (years, money, research, experts, peer input) → how that delivers [PROMISE] by [DEADLINE] → "This makes it the best… without [EXT], despite [INT]" → bold "only one" claim + GUARANTEE or an open challenge to competitors.
2. Relevance: subhead "Why [AUDIENCE] prefer [PRODUCT] for [PROMISE]" → empathize with how SYMPTOMS hit their demographic ("This is why others failed") → "That's why/Thankfully…" [built for them] → "This means…" [PROMISE/DEADLINE/EXT/INT] → "That's what makes [PRODUCT] best for [AUDIENCE]…" → psychographic subhead (shopping preference, e.g. "Your Convenience is Our Top Priority", or values, e.g. "The #1 Earth-Friendly…") + the Alternatives-Debunked formula aimed at competitors → optional bold claim + guarantee.
3. Superiority: subhead "Are you tired of… / Ready to finally…" → Feel, Felt, Found with PROMISE, DEADLINE, BENEFITS, EXT, INT → optional psychographic rant → wall of testimonials (result lines bolded) → "Join These Happy Clients / Now It's Your Turn to [PROMISE]" → "These are just a few of [#]…" → the debunk formula against competitors → how it was made → optional totals and averages ("clients lost an average of…") → recognized endorsements → "Why [NEGATIVE], when you can [POSITIVE]?"
4. Uniqueness: subhead "Here's Why No Other [SOLUTION]… / A Promise No Other [SOLUTION] Can Make" (your hill to die on) → the unique mechanism + investment behind it → "This is why we're the only [SOLUTION] that… / This is why we can promise…" [PROMISE+DEADLINE+EXT+INT] → bold exclusivity claim, how it's protected + GUARANTEE or a challenge.
5. Qualification: stop command ("Wait! Before You Order") → assume the sale ("There's a reason you're about to [ACTION]") → optional reminder of PROMISE, GUARANTEE or USP → REDEEMABLE ADMISSION or "This isn't for everyone" → "This is for… / We're looking for…" → Kennedy's **winners and losers** formula (contrast the two, "it's better to win," 3 examples; short form: "For every [winner], thousands [struggle]") → "Here's the difference…" → "If ___, then here's [PROMISE/OFFER]".

**Offer Stack**
- Step 1, Introduction (5 formulas): Claim + Deliverables (multimedia info products); Price of Creation ("[NAME] is the result of…", then transition via private invitation for Validation/Purpose needs, special price for Excitement, or "at no risk" for Security); Audience Relevance (high-end customized services: "best [SOLUTION] for [AUDIENCE] who want…"); Social Proof (broad appeal: "used by [#] [AUDIENCE]", languages, countries); USP (saturated markets: "the only [SOLUTION]…" + the mind behind it if experts are crowded, an open challenge for first-time buyers in a competitive market, or the objection answer for an audience burned before).
- Step 2, Value Stacking: "Here's What You'll Get When You [ACTION] Today" → for each deliverable, "First/You'll also get [NAME]. This is a [WHAT] that [SOLVES/PROMISE] so you can stop [SYMPTOM pain] and [emotional benefit]. Total value [$]" + a running recap of the total → "But That's Not All / PLUS, [ACTION] and Get These Bonuses" → one bonus each for the Time, Money, Social, EXTERNAL and INTERNAL objections, using the same pattern and running total.
- Step 3, Price Reveal (10 formulas): Cost of Development ("…taken me 15 years… yours for [PRICE]. That's less than…"); Cost of DIY ("…for [PRICE]. This means for [small increment]…"); Cost of the PROBLEM ("instead of [costs]… try [PRODUCT] for [PRICE]; a small price to pay for…"); Guarantee Reminder (any reveal + restated guarantee and its CONDITIONS, for anxious buyers); Appeal to Sophistication ("It takes a smart [AUDIENCE] to appreciate…" + debunk + "Why [NEG] when [POS]?"); Payment Plan (concrete ROI of past clients + "[#] payments of…", with the DEADLINE arriving before the final payment); Appeal to Competition (when the PROMISE has social value: "If you have what it takes… only [PRICE]"); No Hidden Fees ("Other [type] will cost you [fees]… all for [PRICE], with no…"); Reveal and Review (many deliverables: "And the best part is… just [PRICE]. That's less than… [recap everything]"); What's It Worth to ___? (emotional, long-term payoff: "What's it worth to…" ×n → "priceless" → "That's why we're offering…").
- Step 4, Guarantee: state it + reason (confident it will deliver / want you confident) + "If [CONDITIONS], then [RISK REMOVAL money + time]".
- Step 5, Urgency (External Pressure, 3 formulas): Limited Time, Limited Supply, and Reason for Removal. Each = stop word (WARNING/ALERT/IMPORTANT) + the exact deadline, quantity or reason + "your [discount/bonus]" + a bold consequence (order canceled, passed to the next person, gone forever).

## Worked Example
Bold Promise Opening built from the 6 variables: PROMISE = lose 10% body fat. DEADLINE = 90 days. EXT = no starving, wrecked metabolism or low energy. INT = even if overweight for years after multiple failed diets. CONDITIONS = a 30-minute daily workout plus a done-for-you nutrition plan. RISK REMOVAL = refund plus $100. In the Question w/Contrast version: "What if you could lose 10% of your body fat in 90 days without starving yourself…?" → "What if you could do this even if you've been overweight for years?" → a CONDITIONS sentence → "If that sounds good, here's why…" + the refund-plus-$100 guarantee.

## AI Training
The chapter-end link (theantifragilesalessystem.com/chapter-6) points to AI-assisted help writing trip-wire ads (including short test versions and cart-page retargeting), sales page openings, positioning messages and offer stacks.

## Key Takeaways
1. At Stage #3 a No-Brainer Offer beats copy. Confirm the funnel type is right before optimizing.
2. Keep openings short, then spend the words proving trust: X Factor, Superiority, Relevance, Uniqueness, Qualification.
3. A real USP is specific, beneficial and legally unique. It shows how you're different, not that you're better.
4. Stack value item by item with dollar values and a running total, plus a bonus for each of the 5 objections.
5. Match the Price Reveal formula to the market situation. Avoid "too cheap to be true."
6. Use two conditional guarantees (money and time) and hard, explicit urgency consequences.

## Connects To
ch02 (No-Brainer Offer, guarantee and risk removal), ch03 (trip-wire funnel selection, four trust types), ch05 (Solution Pitch X Factor → Positioning; Alternatives-Debunked formula reused), ch07 (CTA, Post CTA, Power PS, Internal Pressure, retargeting reuses the Offer Stack), ch08 (follow-up/abandoned cart), ch11 (Super Seven, human needs, ordering of elements), ch12 (troubleshooting drop-off after positioning), bonus1 (demographic/psychographic avatar).
