# Chapter V: Stage #2 Copy Formulas

## Core Idea
Stage #2 (Curious) prospects know they have the PROBLEM but are unaware, misinformed or confused about its real cause, the ALTERNATIVES and your SOLUTION type. They ignore "buy now" and "we're better" messages. A VSL (or Quiz) Funnel educates them on the cause, debunks the ALTERNATIVES and sells the SOLUTION category, which moves them to Stage #3.

## Frameworks Introduced
**Stage #2 Market Types (4)**: your VSL angle depends on the market you compete in.
- 1) B2C Products/Services: tell a story about someone whose life changed with the product. 2) B2B Products/Services: reveal a SECRET, because thought leadership sells B2B. 3) Information Saturated: expose the MISTAKE(S) the AUDIENCE, or your competitors, make. This is strongest where failure rates are high and trust in experts is low (weight loss, biz opp, marketing, finance). 4) Product/Service Saturated: debunk the ALTERNATIVES, using the AUDIENCE's negative biases against them.
- When to use: pick the type before you write anything. The ad, squeeze page, opening and indoctrination all follow from it.
- Why it works: it keeps every micro-commitment on one consistent angle. Failure mode: a mismatched angle, such as pitching superiority to a prospect who still doubts the category.

**Stage #2 Objections and Rebuttals**: "What causes this?" → clarify the cause. "How do you solve it?" → reveal secret(s). "I'm already doing ___" → expose mistake(s). "Which solution is best?" → debunk alternatives. "Your solution isn't for me" → sell your type of solution.

**Law of One**: one PROBLEM, one driving EMOTION, one SOLUTION, one BENEFIT and one call to action (opt in or leave). The PROBLEM can have many SYMPTOMS and the BENEFIT many side benefits.
- Why it works: confusion is the deadliest marketing sin. A bored prospect can still buy, but a confused one never will (the author's one disagreement with Dan S Kennedy).

**Solution Pitch (9 elements)**: Introduction; Explain What It Is; Explain Why It Works; Use a Metaphor; Explain Long-Term Impact; Expert Endorsements; Peer Testimonials; Time Era Relevance; Expose a Flaw (X Factor). The middle elements can be reordered, but cover all nine. It is required when the audience has many misconceptions about your category. On warm lists, pitch it if viewers drop off sharply when the OFFER is introduced.

**VSL Funnel Elements (10)**: Ad/Post → Squeeze Page → VSL Opening → Indoctrination → Solution Pitch (these five take a prospect from Stage 2 to Stage 3) → Offer Positioning (Stage 3 to 4) → Offer Stack → CTA → Post CTA → Power PS (Stage 4 to customer). Elements 6–10 are covered in ch06 and ch07.

## Key Concepts
- **Curiosity seed**: a surprising or mysterious opener about something that worsens the PROBLEM, blocks the PROBLEM or BENEFIT, or speeds up the result. It can be a warning or a promise.
- **Teaser video squeeze**: put the VSL opening, cut as a short video, under the squeeze headline in place of bullets, followed by a "continue watching" opt-in. It doubles as a cheap test of different hooks.
- **Squeeze page**: the VSL works as both the lead magnet and the sales vehicle, so you can follow up with non-buyers and people who drop off.
- **REDEEMABLE ADMISSIONS**: damaging-sounding but forgivable confessions by the narrator that build likeness with the viewer.
- **Synthetic experience**: hypnotic, sensory CRISIS flashback copy.
- **ALTERNATIVES vs direct competitors**: ALTERNATIVES are outside your category and get debunked here. Competitors are inside your category and are handled in Offer Positioning (ch06).
- **Surrogate endorsement**: an expert endorses the idea, feature or ingredient your SOLUTION is based on, not your product.
- **X Factor**: a flaw in the general SOLUTION category that your brand will later fix or compensate for.
- **Super Seven**: seven BENEFIT types that define "best" (detailed in ch11).
- **Breadcrumbing / relevance / curiosity / hope**: the core techniques that carry the ad through the opening.

## Mental Models
- Clarity beats cleverness at the Solution definition. Name the category by its common name.
- Educate before you sell: cause → secret/mistake/alternative → category → (later) brand.
- Each section ends by opening the next loop, usually with a rhetorical "so how do you…?" question.
- The X Factor should magnify the INTERNAL OBJECTION, never the EXTERNAL one.

## Anti-patterns
- **Putting "limited time" or "we're better" offers in front of Stage #2**: they get dismissed as junk ads.
- **Straddling several problems or benefits on a squeeze page**: this creates confusion and kills conversions.
- **Promoting your specific brand in the Solution Pitch**: save that for Offer Positioning.
- **Giving away too much "why it works" in info products**: the prospect decides they can do it alone.
- **Overdoing the X Factor flaw**: it poisons the category, so the prospect won't want your brand either.
- **Magnifying the EXTERNAL OBJECTION in the X Factor**: this backfires.
- **Ridiculing DIY alternatives in low-trust, product-saturated markets**: the audience takes it as an insult. Use the Soft or Indirect approach, or the Mistakes formula.

## Copy Formulas
**VSL Ad/Post: Attention → Curiosity → Action**
- Attention: [CURIOSITY SEED headline] + 3 questions ("Are you…", "Do you want…", "Have you been…") confirming the [PROBLEM]/[BENEFIT] and foreshadowing the market-type angle (story / [SECRET] / [MISTAKE] / [ALTERNATIVE] failure) + "about to reveal…".
- Curiosity: This FREE video reveals [surprising insight on solving PROBLEM / achieving BENEFIT / flaw of ALTERNATIVE] + you'll understand how to [BENEFIT] without [EXTERNAL OBJECTION], even if [INTERNAL OBJECTION] + optional "why others succeed and you don't" + "Here's what you'll learn…" [3–4 bullets] + "This video is for [AUDIENCE] who [foreshadow SOLUTION tied to BENEFIT]".
- Action: If [desire], then [watch the VSL] + CTA (what to do / why / why now) + PS: [premium or bonus for watching now] + [limited time or supply].

**Squeeze Page**: header with exactly ONE hook: the video reveals a [SECRET] for [BENEFIT], OR exposes a [MISTAKE] blocking [BENEFIT], OR reveals an insight about an [ALTERNATIVE]. Then 3–5 bullets:
1. [BENEFIT] and why some get it while others don't (+ social proof). Bullet 1 can use the PROBLEM instead.
2. How [SECRET/MISTAKE/ALTERNATIVE] blocks [PROBLEM solved / BENEFIT].
3. Foreshadow [SOLUTION].
4. Address the [EXTERNAL/INTERNAL OBJECTION].
Button: "Yes, Show Me The Video!" Test versions with and without bullets.

**VSL Opening, 4 variants by market type**
- #1 B2C story: [CRISIS flashback, sensory] → "Little did I/[HERO] know…" [CRISIS led to SECRET/SOLUTION, revealed soon] → "My name is…" + "if you're watching this, you and I are a lot alike…" [3–5 REDEEMABLE ADMISSIONS] → "Yet, despite all this…" [what SECRET did for me/clients + hint for you + callback to story] → "You're here because…" [BENEFIT without EXTERNAL OBJECTION, despite INTERNAL OBJECTION] → "If ___, then here's why…" [watch to the end / best decision you've made / categorical life change]. The author gives 4 crisis flavors: physical, financial, social, existential.
- #2 B2B secret: 3 questions (Are you / Do you want / Have you been) → "If you answered YES…" this video will save you [time/energy/stress] by revealing [#] [adjective] SECRET(S) that [impact] → [brief intro] "In [SHORT TIME], I'll show you (the ___ truth about) how [top AUDIENCE members] (REALLY) [BENEFIT] (without [EXTERNAL OBJECTION]) (even if [INTERNAL OBJECTION]), and how the same happens for you once you apply the SECRET(S)" → "This SECRET is so [simple/powerful/fast] that not only [BENEFIT], but [physical/financial/social/emotional payoff] by [DEADLINE], and you'll believe it the moment you hear it."
- #3 Information saturated: same skeleton as #2, with [MISTAKE(S)] in place of SECRET. The close is "so [costly] yet so simple to fix that…".
- #4 Product saturated: same skeleton, "the truth about whether [ALTERNATIVE] (REALLY) [BENEFIT]…" + optional "In fact…" [ALTERNATIVE is making it worse] + "[Luckily/The good news is] you'll also discover a [fast/easy] ('[NICKNAME]') [shortcut/trick/hack/secret/loophole] that not only [PROMISE] but [payoff], without [EXTERNAL OBJECTION], even if [INTERNAL OBJECTION]."

**Indoctrination (repeat once for each SECRET, MISTAKE or ALTERNATIVE)**. With a B2C story opening, tell the story first using the ch04 storytelling formulas.
- Secrets Revealed: number and name the [SECRET] → confirmer (TIE DOWN "Haven't you noticed…" / IF-THEN "If others get it, how come you…" / METAPHOR / CAUSE-EFFECT) → "According to [SOURCE], it's not [MYTH] but [SECRET] that [solves PROBLEM]" (3 phrasings) → "This is a [surprising discovery / startling new fact] if you're [frustrated by MYTH]. It [proves/explains] [what's possible / why you've struggled]" → second [SOURCE] + nod-along impact + direct quote → "And that's [not all / just the beginning]" + bonus impact without [EXTERNAL] despite [INTERNAL] → metaphor/fable/analogy + quote from an AUDIENCE hero → optional third data source → END: if it's the last secret, "Now you know… but how do you combine them to [BENEFIT] by [DEADLINE]?" If more are coming, "Are you starting to [see/realize]…" + [past failure] and/or [imagine the payoff].
- Mistakes Exposed: number and name the [MISTAKE] → confirmer → validate their suspicion → "Ever notice how… / Think about the last time you… / How many times have you…" → painful-detail question → "This is because…" → "This is why [nothing has worked]" → "According to [SOURCE], it's not [MISTAKE] but [vague SECRET/SOLUTION]…" (or "[MISTAKE] not only fails, but [hidden side effect]") → support + second source + quote → "And that's not all" + hidden, more serious impact → metaphor + hero quote → END: rhetorical "So if it's not X, Y or Z, how do you…?" or "Are you starting to…" + "The good news is…" [fixing the MISTAKE, or a hinted SECRET, delivers PROMISE without EXTERNAL, even if INTERNAL].
- Alternatives Debunked: "You've probably heard / [Expert] will tell you / Many believe / You've probably tried…" [ALTERNATIVE's PROMISE] → "What they won't tell you / what most people don't know…" [flaw or catch] → "This is why…" [what you, or someone you know, experience using it] → END: final one gets the rhetorical "So if X won't… how do you…?" A mid-sequence debunk uses the Soft approach ("Do you really want to keep paying [price]?"), the Indirect approach (a hero quote), or the Aggressive approach (a metaphor or joke showing it's slow, convoluted, dangerous and so on; the reverse Super Seven). Note: the text lists "two" approaches but gives three.

**Solution Pitch (9 elements)**
1. Introduction: "You could…" [the high cost of doing nothing / believing MYTHS / DIY-ing the SECRETS / repeating MISTAKES / trying ALTERNATIVES] → contrast with [SOLUTION] as the best way to [BENEFIT] by [DEADLINE] without [EXT], despite [INT].
2. What It Is: plain definition by its common name + an optional feature some providers offer (sets up Positioning) + objective third-party results data for the category + "you" tie-in with [DEADLINE] / without [EXT] / even if [INT] + "Can you imagine… / How would your [life/business] change if…" + "Here's why this is just a glimpse…".
3. Why It Works: anti-positioning ("A good [SOLUTION] doesn't…") → how it solves the PROBLEM where ALTERNATIVES can't → "This is why…" [money well spent / usage stat].
4. Metaphor: "[SOLUTION] is like…" (ideally one that answers an objection, with a "the right [SOLUTION]" hint) → "Can you imagine…".
5. Long-Term Impact: 3–5 lasting effects → "This is why/This makes [SOLUTION] one of the smartest decisions…".
6. Expert Endorsements: 1–5 experts (surrogate endorsements allowed) → "If it did this for them, imagine what it will do for you."
7. Peer Testimonials: a statistic about AUDIENCE users + the result without [EXT], despite [INT] + the same "imagine" tie-off.
8. Time Era Relevance: "[SOLUTION] is more important today than ever. This is because…" [current conditions make the PROBLEM harder / flood of bad ALTERNATIVES] → restate.
9. X Factor: [a side effect, or some brands of SOLUTION are slow, complex, weak…] (magnifies the INTERNAL objection) → "This could cost you…" → "Thankfully / The good news is…" [you can still get BENEFIT by DEADLINE despite INT]. This bridges to Offer Positioning.

## Worked Example
A B2C self-defense VSL opening:
- CRISIS: Ethan lies bleeding after an attack, sirens approaching, thinking of his wife and kids.
- Little did he know: the attack would lead him to a simple system of quick moves that could have turned the fight around. Proof is promised within two minutes.
- Narrator and admissions: Dan Powers introduces himself and says you and he are alike. He isn't athletic, fast or strong, and doesn't like fighting.
- Yet, despite all this: he mastered the system and has trained dozens of people to beat bigger attackers. Ethan was one of his first students, and what happened next is teased.
- You're here because: you've been hurt in a fight and want the next attacker to regret it. So watching to the end is the most life-changing decision you'll make.

The EXTERNAL objection (complexity) and the INTERNAL objection (bigger attackers, no athletic ability) are both handled without being named.

## AI Training
The chapter-end link (theantifragilesalessystem.com/chapter-5) points to AI-assisted help drafting VSL ads (including shorter test versions and retargeting of opt-ins who don't watch), squeeze pages, VSL openings, indoctrination messages and solution pitches from your defined variables.

## Key Takeaways
1. Choose the market type (B2C story / B2B secret / info-saturated mistake / product-saturated alternative) first. It sets the angle for every VSL element.
2. The squeeze page obeys the Law of One: one hook, 3–5 bullets, one action. Test a teaser-video version.
3. Every opening confirms pain or desire with Are you / Do you want / Have you been, then promises the BENEFIT without the EXTERNAL objection, even if the INTERNAL one applies.
4. Indoctrination uses credible sources contrasted with MYTHS, then ends with an open loop into the next item or into the Solution Pitch.
5. Sell the category (Solution Pitch, 9 elements) before the brand. Use objective third-party proof, not emotion.
6. End with an X Factor flaw of the category, which sets up your brand as the fix.

## Connects To
ch03 (Angle Selling, VSL funnel choice, copy variables), ch04 (storytelling and myth-busting formulas reused in indoctrination), ch06 (Offer Positioning answers the X Factor), ch07 (CTA, Post CTA, Power PS finish the VSL), ch08 (follow-up for opt-ins who don't buy), ch11 (Super Seven, human needs, hook testing), bonus1 (avatar for AUDIENCE variables), bonus3 (headlines/curiosity seeds).
