# Chapter 8: Followup Formulas

## Core Idea
Followup is where the Antifragile Sales System stops leaking money. Every subscriber gets a sequence matched to their **stage of awareness** (Stage #1-4 Prospects) or their **stage as a customer** (Stage #5). Customers are still "prospects": you keep persuading them to earn repeat business, reviews, referrals, and win-backs. Czerepak says skipping this is how million-dollar years flatline within 1-3 years. Mass-mailing every buyer the same thing is the most common and costly followup mistake.

Nearly every followup message reuses copy formulas from chapters IV-VII (myths, secrets, mistakes, alternatives, positioning, offer stack, objections, CTAs). The medium changes the reader's state of mind (scanning an inbox vs. searching to buy), but it doesn't change the persuasion logic. Ignore the idea that email needs a completely different strategy.

## Frameworks Introduced

| Framework | When | How |
|---|---|---|
| **Stage #5 Customer Ladder** (Buyers, Loyalists, Promoters, Referrers, plus Stage #0 Winbacks) | After the first purchase | Buyer → loyalist → promoter (left a review) → referrer. Winbacks are *loyalists* who stopped buying. A one-time buyer who doesn't return isn't "lost." |
| **Trust-Building Sequence** | Any new Stage #1-4 subscriber | 8 message types: Welcome → Problem → Promise → Indoctrination → Solution → Positioning → Offer (Stack) → Downsell. The entry point depends on stage. |
| **Flash Sale Sequence** | Stage #3-4 non-buyers and existing customers buying a *complementary* offer | Prepare → Promote → Remind → Urgency → Downsell |
| **Abandoned Cart Sequence** | Anyone who started checkout and didn't finish (requires a two-step checkout) | Remind → Sweeten → Warning → Downsell, gated by opens |
| **Upsell Formulas** (Enhance Your Offer / Next Level Problem / Next Level Promise) | Immediately after checkout | Beat the three upsell objections with an opening that ties the upsell to the offer they just bought |
| **Upsell Sequence** | Buyers who declined the upsell | Remind → Resell, then the Offer Stack messages (Urgency, 4 objection types) → Downsell |
| **Call Booking Formulas** (Mandatory / Next Level Problem / Next Level Promise) + **Call Confirmation Video** | High-ticket offers (>$1k; human contact is needed past about $2k) | A 3-5 min video on the post-purchase page, then rules-based confirmation |
| **Reminder Sequence** | Booked calls, events, webinars | Confirmation → Daily → Evening → Morning → 2 Hour → 15 Minute → Final (email + SMS) |
| **Loyalty Sequences** (Review, then Referral) | Customers who have had time to get results | Prepare → Request → Remind. Send the review sequence first; send the referral sequence only to positive reviewers. |

**Why the Trust-Building Sequence works / failure mode:** it's the funnel copy (ch04-ch07) broken into emails, so each prospect only reads the stage messages they still need. It fails when you give Stage #1-2 prospects offer-heavy messages, when no automation removes buyers from the sequence, or when you don't route webinar/VSL completers ahead to Positioning.

**Why the Upsell Opening works / failure mode:** a buyer's dopamine is up, so an upsell priced at 4-5x the front-end price can still convert. It fails when the opening leaves any of these objections unanswered: "I just bought something that does this," "This has nothing to do with my problem," "I'll try what I bought first." It also fails when the upsell drops the buyer back to Stage #1-2, meaning a new problem or a new solution type. If an upsell needs a VSL or webinar to sell, pick a different upsell.

## Key Concepts
- **Stage-based entry points:** in the Trust-Building Sequence, Stage #1 starts at Welcome and then gets everything. Stage #2 gets Welcome, then Promise and Myths onward. Stage #3 gets Welcome, then Indoctrination/Solution onward (the Positioning messages are its first *core* messages). Stage #4 starts at the Offer Stack, or goes straight to Abandoned Cart if they reached checkout.
- **Behavioral skip-ahead:** people who attended the webinar or finished the VSL, or who opened every Solution message, jump to Positioning. Anyone who opens a Positioning message gets the Offer Stack. Buyers are removed. People who finish without buying go to lead scoring (ch10).
- **Two-step checkout:** collect name and email before payment so abandoned carts can be followed up. Split-test it against a one-step checkout (ch11).
- **Subject/HINT combo:** the subject line plus preview text, written as a pair. Abandoned-cart hints often imitate system notices ("[NOTICE/ALERT/ERROR]: Incomplete order").
- **Cross sells / order bumps / upsells:** before checkout / on the checkout page / after checkout. Their purpose is to "liquidate your ad spend." Any profit is a bonus, because the first sale exists to earn a customer.
- **Next level problem:** a problem created *by* the result of the main offer (e.g., more leads now need a followup/booking system). **Next level promise:** a result stacked *on top of* the original promise. Either one must obviously connect to the original promise.
- **Hat-in-the-hand close** (Zig Ziglar): a last-minute downsell pitched on the sales call, and only after a hard, definite no. The lower-ticket upsell plays this role.
- **Call rules:** non-negotiable conditions for the call: be somewhere you can focus and take notes (no driving), and confirm by SMS right after booking and again the night before. If the rules or the qualification answers are broken, cancel the call.
- **Surrogate endorsement:** an expert endorsement of the *idea* or ingredient behind your solution, used when nobody has endorsed your product itself.
- **Three-part CTA:** every message tells the reader what to do, why, and why right now. Most messages add an **early CTA** for skimmers and a **PS premium** with limited time or supply.

## Sequence Blueprints

### 1. Trust-Building Sequence
Trigger: opt-in. Cadence: roughly one message per send slot. The book doesn't specify intervals, so set them in your platform. Exit on purchase.

| # | Message | Purpose | Formula skeleton |
|---|---|---|---|
| 1 | **Welcome** (4 variants) | Confirm the opt-in and prime the next message | *General Subscription:* greet [NAME] → name the newsletter/podcast → you + one positioning line → "If [PROMISE], then subscribing…" + physical/financial/social/emotional impact → why you started it, tied to USP → "If ___, then ___" → tease an unnamed gift in the next email → sign-off + PS CTA (book a call). *Lead Magnet:* same, but lead with the download link. *New Customer Discount:* "[NAME], you won't believe this…" surprise OFFER + scarcity → "If ___ then ___" PROBLEM/PROMISE + GUARANTEE + RISK REMOVAL → ch07 CTA. *Contest Entry:* recap rules, prize, winner date (announced in your social group) → surprise offer that multiplies entries (e.g., 1 entry per $) for a limited window → same close. |
| 2 | **Problem** (Stage #1, webinar) | Get them to the webinar | 3 symptom questions ("Are you…", "Do you often feel…", "Have you noticed…lately") → escalation to crisis → "if/then" → "Here's what you'll learn…" 4 bullets (why they have it / how critical / why urgent / hint at real SOLUTION) → if/then tie PROMISE to attending → date + "reminders coming" → CTA: replay OR "skip to the front of the line" with a free consult (limited slots) |
| 3 | **Promise** (Stage #2, VSL) | Get the VSL watched | 3 questions ("Are you…", "Do you want…", "Have you been…") seeded by market type: B2C = story, B2B = SECRET, Info-saturated = MISTAKE, Product-saturated = failing ALTERNATIVE → if/then → optional early CTA ("ATTENTION: Want…? Click here") → bullets of what the VSL reveals → "only way to satisfy curiosity is to watch" → CTA + PS limited premium (e.g., "next 100 viewers") |
| 4 | **Indoctrination:** Myth (S1), Secrets (S1+S2), Mistakes (S2), Alternatives (S2) | Break the false belief that's in the way | "Have you ever wondered why…"/"Are you secretly asking yourself why…" (why past efforts failed, or why others succeed) that names the MYTH/SECRET/MISTAKE/ALTERNATIVE → "If so, you've probably heard…" → abbreviated ch04/ch05 formula → optional early CTA → CTA (replay/VSL or consult) → optional PS premium |
| 5 | **Solution #1 Introduction** | Sell the solution *category* | "By now, you know that…" recap cost of doing nothing/myths/DIY secrets/mistakes/alternatives → foreshadow SOLUTION as best way by DEADLINE → subhead "What is [SOLUTION]?" → plain definition (clarity, not curiosity) → optional feature some providers offer → anti-positioning ("a good [SOLUTION] doesn't…") → how it beats ALTERNATIVES → early CTA → subhead "Proof That [SOLUTION] Works" → objective data |
| 5 | **Solution #2 Social Proof** | Get authority on your side | "Would you trust a SOLUTION endorsed by [EXPERTS] / used by [AUDIENCE]?" → "If ___, here's why ___" → stat → worked without EXTERNAL OBJECTION / despite INTERNAL OBJECTION → "If it did this for them, imagine…" → 1-5 experts (surrogate endorsements OK) → "How would your [life/business] change if…" → CTA |
| 5 | **Solution #3 Flaw (X-Factor)** | Turn the internal objection into your edge | Damaging admission / flawed variants (amplify the INTERNAL, never the EXTERNAL objection) → "This could cost you…" → "Thankfully…" hint at a result by DEADLINE → name the X-Factor → "[PRODUCT] is a [SOLUTION] that…" → how it was made (years, money, research) → bold "only one" claim + GUARANTEE/RISK REMOVAL or an open challenge to competitors → CTA |
| 6 | **Positioning:** Relevance, Superiority, Uniqueness | Sell *your* offer (first core messages for Stage #3) | Restate PROMISE/desire (Superiority adds "without EXTERNAL OBJECTION", Uniqueness adds "despite INTERNAL OBJECTION") → early CTA → body = matching ch06 Positioning Formula → "only one" claim + guarantee → CTA to a sales page / booking |
| 7 | **Offer Stack:** Introduction, Urgency, External, Internal, Commitment, Character Objections | Close (first messages for Stage #4) | *Intro:* restate PROMISE by DEADLINE without EXTERNAL OBJECTION + guarantee → ch06 Offer Stack Intro → summarized Value Stack bullets → Price Reveal → PROMISE/GUARANTEE/RISK REMOVAL → CTA. *Urgency:* ch07 Post CTA formula + PS premium; optional who-it's-for/not-for qualifiers (high-ticket). *Objections 3-6:* the matching ch07 Objection Formula as the body → CTA → PS premium |
| 8 | **Downsell** | Last attempt, then move to regular automations | Open with one of: "still want to solve PROBLEM without [EXTERNAL OBJECTION]?", "solving it another way?", or "you subscribed to…" → one final offer framed as a *taste* of the full OFFER → "Here's what you'll get…" bullets with $ values → "Plus, order now and get these bonuses…" → total value → Price Reveal → price credited toward upgrading → CTA → PS limited time/supply (e.g., 72 hrs) |

Shortcut: product businesses selling mostly to Stage #3 can skip straight to the Flash Sale Sequence.

### 2. Flash Sale Sequence (5 messages)
For people already sold on the PROBLEM and the SOLUTION. If the new offer solves a *different* problem, treat the customer as Stage #1-2 and use Trust-Building instead.

| # | Message | Skeleton |
|---|---|---|
| 1 | Prepare | Tease the upcoming OFFER → how fast/easy/powerful ("Super Seven", ch11) → reason for not revealing it yet → "stay tuned" → PS: secret early sneak-peek link to the sales page ("don't share this") |
| 2 | Promote | Body = ch06 Trip-Wire Ad/Post Formula (problem-focused or promise-focused) → 3-part CTA → PS limited premium |
| 3 | Remind | Warning of what happens if they don't act → "last chance to [PROMISE] without [EXTERNAL OBJECTION]" → "Here's what you'll get when you [ACTION]…" bullets: relevant / superior / unique / without EXTERNAL / despite INTERNAL / risk removal → "If ___, then ___" → "Hurry…" + regret → CTA |
| 4 | Urgency | Offer Stack Urgency formula; deadline countdown (e.g., "Only 3 hours left!") + PS premium |
| 5 | Downsell | Trust-Building Downsell formula |

### 3. Abandoned Cart Sequence (4 messages, gated by opens)
Trigger: checkout started but not finished (two-step checkout). If they opened a message and didn't buy, send the next one. If they didn't open it, **resend the same message with a new subject/HINT**. Anyone who never converts drops into Trust-Building or long-term automations.

| # | Message | Subject/HINT patterns | Body template |
|---|---|---|---|
| 1 | Remind | "[NAME], your order is incomplete", "Oops! You forgot your [PRODUCT NAME]", "[NAME], your mom doesn't work here", "[NOTICE/ALERT/ERROR]: Payment incomplete", "RE: Your [PRODUCT] order" | 4 templates: *Physical* ("[NAME], you forgot your [PRODUCT NAME]! …saved your cart"), *Fear of Loss* (may go out of stock), *Digital + expiring discount* ([DISCOUNT # OR %] expires in [TIME PERIOD]), *Digital + expiring bonus* ([BONUS ITEMS] expire when you delete this email). All: [CART ITEMS WITH PICTURES] → Order Total → one-sentence guarantee → << CTA >> → PS: [BENEFIT STATEMENT] |
| 2 | Sweeten | "[NAME], here's a discount on your [PRODUCT NAME]", "Geez [NAME], I guess we'll have to bribe you!", "Okay [NAME], here's our shameless bribe" | *Added Discount:* "What if we give you [# OR %] off…today?" + expires when this email is deleted → cart → NEW Total → CTA → PS reviews. *Added Bonus:* FREE [BONUS PRODUCT] with pictures → CTA → PS bonus reviews |
| 3 | Warning | "FINAL REMINDER: Your [PRODUCT NAME] discount expires today", "WTF [NAME]? / We offered a FREE [BONUS PRODUCT] and you ghosted us!", "LAST CHANCE to save [# OR %]" | "Still want to save [# OR %]…last chance" → cart → Total (You Save [TOTAL SAVINGS]) → CTA → PS guarantee (+ PPS reviews for the bonus variant) |
| 4 | Downsell | "([Bad news / Sorry / Too Late / It's Over], )[NAME]( you missed out)… \| HINT: you missed out on [SWEETENER]( and [BENEFIT OF OFFER])" | Trust-Building Downsell formula |

### 4. Upsell Sequence (8 messages)
Trigger: bought the main offer, declined the upsell. It must **not collide with the call Booking/Reminder sequence**.
1. **Remind:** acknowledge the purchase and the declined upsell → limited time/supply → "best way to [BENEFIT] by [DEADLINE] without EXTERNAL / despite INTERNAL" + guarantee → "Here's what you'll get when you [ACTION]…" (relevant, superior, unique, without EXTERNAL, despite INTERNAL, risk removal) → early CTA → who it's for → "I'm so confident of this that…" + risk removal → CTA (e.g., "area open only another 24 hours").
2. **Resell:** body = your upsell opening formula → early CTA → CTA.
3-8. **Urgency, External, Internal, Commitment, Character Objections, Downsell:** same as the Trust-Building Offer Stack and Downsell.

### 5. Call Booking → Reminder Sequence
Trigger: call booked, or event/webinar registration. Send by email **and** SMS.

| Message | Timing | Skeleton |
|---|---|---|
| Confirmation | Immediately | Clear date/time → restate the call-booking promise → recap call rules → rules ensure [PROMISE] by [DEADLINE] |
| Daily Reminder | Every day until the call | One objection per message, using the Call Confirmation Video formula: Timing, Third Party, Financial, External, Internal, Commitment, Character. Invite a reply. |
| Evening Reminder | Night before | Short version of the confirmation + an invitation to **cancel if they won't follow the rules** |
| Morning Reminder | Morning of | Date/time → restate promise → optional key rule → "looking forward to it" |
| 2 Hour Reminder | 2 hrs before | Quick date/time → optional most important rule |
| 15 Minute Reminder | 15 min before | Date/time + how it will happen ("starts in 15 minutes") |
| Final Reminder | At start time | "I'm on the call now" + how to join or call back |

### 6. Loyalty Sequences (Review, then Referral), 3 messages each
Trigger: enough time has passed for the customer to get the promised result. Asking too early gets few reviews and irritates buyers.

| # | Review Sequence | Referral Sequence (positive reviewers only) |
|---|---|---|
| 1 Prepare | Thank them for their business → tie the decision to a positive trait of theirs → "it will pay off" → reinforce PROMISE + how to get the most from it | Thank them for the review + a positive trait → more reviews = more people helped (show testimonials) → "tomorrow, a FREE GIFT only for true fans" → ask for a reply with ways to improve → optional PS "keep this to yourself" |
| 2 Request | "How would you rate [PRODUCT] 1-5?" → if 4-5, a quick Zoom to hear why + "something new for favorite customers" → if lower, reply with what would make it a 5 | Interested in the referral incentive / know anyone? → win-win offer + payout details + earnings example at 5-10 referrals/month → "If ___, then" get on a call or reply → optional PS self-serve partner signup |
| 3 Remind | Nearly identical to the Request, with 2-3 alternate subject lines. **Max 3 sends**, then exit. | Same (e.g., "[NAME], I'll pay you $50 for this…") |

Review interview (recorded Zoom): (1) experience so far, (2) initial skepticism, (3) how it exceeded expectations, (4) one unexpected benefit, (5) likelihood to recommend, 1-5. Positive answers become a video testimonial (ask permission). Negative answers become a service call. Chronic complainers: end politely and move on.

## Upsell & Call Booking Formulas

**Upsell page order:** Opening → Offer Stack → CTA → Positioning → CTA → Post CTA → Power PS. Positioning comes *after* the stack here (on funnel pages it comes before) to catch any lingering objections.

- **Enhance Your Offer** (easiest): "What if you could / Want to [PROBLEM solved / PROMISE] *faster than [DEADLINE] or bigger*?" (or "only for people who…" / "skip this if you don't…") → reaffirm the original PROMISE → "If ___, here's why ___" (won't settle for speed/size, or wants a better result) → upsell USP → subhead: expires by deadline/supply → why you're inviting them → "Imagine…" subhead → future-pace the payoff at the upsell deadline.
- **Next Level Problem:** blunt headline about a problem *they just created* by buying → make its cost explicit while keeping the problem itself vague (breadcrumbing) → reaffirm PROMISE → "But this also means…" reveal, showing it cancels the benefits or creates new problems → hassles of DIY → "That's why… / The good news is…" introduce the upsell.
- **Next Level Promise** (hardest, pays the most): headline linking [ORIGINAL PROMISE] → [NEXT PROMISE] (+ deadline + EXTERNAL OBJECTION) → reaffirm → "Now imagine…" benefits → optional without EXTERNAL / despite INTERNAL → DIY hassles → "That's why…" → how the upsell delivers it.
- **Simple upsells** that need little copy and can run pre-checkout: more of the same consumable, or a complete set/kit that includes the original item (mug → dishes and coffee pot; beard oil → beard kit), with bundle discounts or set items given as bonuses.

**Call Booking Video** (3-5 min, on the post-purchase page):
- **Mandatory** (service offers; place it *after the final upsell*, and every buyer sees it): welcome and congratulate → "one step from [PROMISE]" → pay attention: what goes right or wrong + a teased surprise at the end → "the one thing" that separates people who get results (brand it) → "That's why…" step-by-step of how the call and delivery work → "This is how we ensure that you…" [PROMISE + DEADLINE, without EXTERNAL, despite INTERNAL] → surprise revealed on the next page → CTA to book.
- **Next Level Problem / Next Level Promise** (a high-ticket call after a low-ticket buy; place it *before the first upsell*, and show the upsell only to people who don't book): congratulate → the matching upsell-opening body → tie the call to the fix → scarcity on sessions or surprise bonuses → optional surprise revealed "on the call you're about to book" → "By the end of this call…". Hard no on the call = the upsell as a hat-in-the-hand close. Booked but no-show = promote the upsell by email/SMS/direct mail.
- **Call Confirmation Video** (on the booking confirmation page): congratulate → excited to deliver [PROMISE] → surprise at the end → "watch it all; it's mandatory or we cancel" → rules (focused and taking notes; confirm by SMS right after booking and the night before) → "This is how we ensure that you…" → get ahead of the high-ticket objections.

## Anti-patterns
- Sending every customer (or every subscriber) the same followup, whatever their stage.
- Pitching an unrelated product to existing customers through a Flash Sale. A new problem means Trust-Building.
- Upsells that need a VSL or webinar, or that push the buyer back to Stage #1-2.
- Judging front-end campaigns on immediate profit. The first sale earns a customer, and upsells liquidate ad spend.
- Running the Upsell Sequence over the Booking/Reminder sequence.
- Making exceptions to call rules, or keeping low-quality booked leads. Cancel them.
- Asking for reviews or referrals before the customer has results, reminding more than 3 times, or **offering incentives in exchange for reviews** (an FTC risk). Frame gifts as thanks for their business.
- Using the Flaw message to magnify the EXTERNAL objection (it backfires). Magnify the INTERNAL one.
- Making the solution definition clever or mysterious. Aim for clarity.

## Worked Example: Abandoned Cart for "TrailBrew Cold Brew Kit" ($49, physical)
1. **Remind:** Subject "Oops! You forgot your TrailBrew Kit" / HINT "Dana, you left your TrailBrew Kit in your cart!" Body: "Dana, you forgot your TrailBrew Kit! Thankfully we saved your cart and it's almost ready to ship." [Kit photo] Order Total: $49. "Love it for 60 days or your money back." << Finish my order >> PS: Smooth, low-acid cold brew in 12 hours with no machine.
2. **Sweeten** (opened, didn't buy): Subject "Geez Dana, I guess we'll have to bribe you!" / HINT "Finish your TrailBrew order and we'll throw in 2 reusable filters FREE…" Body: "What if we give you 2 FREE filters ($14 value) for completing your order today? This offer expires when you delete this email." [Kit + filter photos] Total: $49. << Claim my free filters >> PS: 3 customer reviews of the filters. (If they didn't open it, resend Remind with "[NOTICE]: Incomplete order".)
3. **Warning:** Subject "FINAL NOTICE: Your free filters expire today" / HINT "This is your LAST CHANCE to get your FREE filters." Body: "Dana, this is your last chance to claim your FREE GIFT…" Total $49 (You Save $14) → CTA → PS guarantee → PPS reviews.
4. **Downsell:** Subject "Sorry Dana, you missed out…" / HINT "you missed out on free filters and café-smooth cold brew…" Body: Downsell Formula. Offer a $12 TrailBrew Sampler (2 pre-filled filter packs) as a taste, with value bullets, credited toward the full kit, and a 72-hour expiry.

## AI Training
The chapter ends with a pointer to online AI training (theantifragilesalessystem.com/chapter-8) for drafting these sequences. Use it by feeding an AI your PROBLEM, PROMISE, objections, and offer stack together with each formula above.

## Key Takeaways
1. Map every subscriber to a stage and send the sequence for that stage. The same copy formulas carry across web, email, and SMS.
2. Trust-Building rebuilds the whole funnel in email. Use behavioral triggers (finished the webinar or VSL, opened messages) to skip people ahead, and remove buyers automatically.
3. Abandoned-cart followup is gated by opens: Remind → Sweeten → Warn → Downsell. Resend with a new subject when a message goes unopened.
4. Upsells exist to liquidate ad spend. Price them at 4-5x the front end, expect 10-20% take rates (order bumps and cross sells 10-50%), and win with the opening.
5. High-ticket (>$1-2k) needs a call. Sell the booking with a short video, protect show-up rates with rules and a 7-touch reminder cadence (expect 40-50% no-shows and 10-20% close rates from cold traffic).
6. Loyalty runs review first, then referral. Ask only after results, use recorded Zoom interviews for testimonials, and never pay for reviews.

## Connects To
- **ch03 funnel:** the stages of awareness and funnel types (webinar = Stage #1, VSL = Stage #2, Trip-Wire = Stage #3-4) decide where each subscriber enters.
- **ch04-ch07 stage copy:** Myth/Secret/Mistake/Alternative, Solution, Positioning (Relevance/Superiority/Uniqueness), Offer Stack, Price Reveal, Post CTA, and the Objection formulas are reused message by message.
- **ch09 traffic:** these sequences convert the leads that evergreen traffic brings in.
- **ch10 goals:** lead scoring for people who finish Trust-Building without buying, plus the show/close-rate math behind call funnels.
- **ch11 split-testing / Super Seven:** test two-step vs. one-step checkout and subject/HINT variants. The "Super Seven" appeals (fast, easy, etc.) are referenced throughout.
- **ch12 troubleshooting:** the law of averages (10-20% upsell take rate), heat maps for weak upsell pages, and no-show and close-rate fixes.
