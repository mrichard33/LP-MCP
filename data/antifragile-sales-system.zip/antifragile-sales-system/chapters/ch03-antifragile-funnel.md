# Chapter 3: An Antifragile Funnel

## Core Idea
Marketing is a process, not an event. A funnel is an algorithm for building trust through micro-commitments. Picking the right funnel type depends on **Angle Selling**: matching the message and funnel to the prospect's stage in the Buyer's Journey.

## Frameworks Introduced
**Angle Selling**: selling with messages that match the prospect's current stage in the Buyer's Journey. It is based on the prospect's perspective, not yours.
- When to use: choosing a funnel for cold paid traffic and writing all funnel copy (ch04–ch08).
- How: find the stage cold prospects are most likely in, use the matching funnel, and write copy that moves them one stage at a time.
- Why it works: most marketers only target Stage #3 (Comparing), which is why online marketing feels crowded. Reaching prospects earlier lets you connect before competitors and win at higher prices. Failure mode: the wrong funnel type fails no matter how often you rewrite copy, retarget or cut prices.

**Five Stage Buyer's Journey** (the author's adaptation of Eugene Schwartz's *Breakthrough Advertising* model, not HubSpot's three stages). Stages are defined by what the prospect knows or assumes about four things: the **PROBLEM**, the **ALTERNATIVE** solution(s), the **TYPE** of product/service, and your **BRAND**.
- **Stage #1 Indifferent**: unaware of the problem, or unaware how personal, critical and urgent it is. Job: educate them on how devastating it is.
- **Stage #2 Curious**: aware of the problem and exploring solutions or alternatives (DIY, in-house, drugs). Job: expose the hidden risks of the alternatives.
- **Stage #3 Comparing**: shopping your solution type. Job: position you as the most relevant, superior and unique option.
- **Stage #4 Negotiating**: has chosen you but hasn't paid. Needs reassurance on last-minute objections, not more education.
- **Stage #5 Committed**: now a customer. This is the Buyer's Journey to Customer Journey transition. Focus on satisfaction, loyalty and LTV.

**Stage → Funnel map (five funnel types)**
- Stage #1 → **Webinar Funnel**
- Stage #2 → **VSL (or Quiz) Funnel**
- Stage #3 → **Trip-Wire Funnel**
- Stage #4 → **Retargeting Funnel**

**TOFU / MOFU / BOFU micro-commitment funnel** (every step builds convenience, charisma, competence and character):
- B2C: TOFU: ad seen → 1–5% click → 10–20% subscribe for a freebie. MOFU: 10–20% buy the No-Brainer Offer → 10–20% take add-ons → 10–20% take the upsell → roughly break even. BOFU: sell 20–50% more via follow-up. All profit comes from here, and you reinvest it in ads.
- B2B/high-ticket: same TOFU. 1–5% of subscribers buy the offer, add-ons and upsells at 10–20% each, and you spend a few hundred dollars per customer. BOFU: 10–20% buy the primary service via follow-up and person-to-person sales, 10–20% of those upgrade, and 10–20% of those buy the top tier.

**Copywriting Kitchen (12 variables)**: define these once and reuse them in all copy (funnels, email/SMS/mail, scripts, books):
1. AUDIENCE 2. PROBLEM 3. PROMISE (BENEFIT) 4. MYTH(S) 5. MISTAKE(S) 6. SECRET(S) (ideally unknown to the audience) 7. ALTERNATIVE solution(s) 8. SOLUTION type 9. POSITIONING statements 10. No-Brainer OFFER 11. EXTERNAL OBJECTION(S): doubts about the solution type (will it work, what hassles come with it) 12. INTERNAL OBJECTION(S): doubts about themselves or their situation ("it works for others, not me")

**The Three Catches**: 1) It's a process, not an event: blueprint, build, run traffic, find weak links, tweak, repeat. 2) Mental toughness: persistence, resilience, critical thinking. Perfectionism and imposter syndrome call for a mindset coach. 3) The Fragility Factor: funnels that work, then stop, or break when scaled.

## Key Concepts
- **Funnel**: a step-by-step trust process from stranger to buyer to loyal customer to promoter.
- **Micro-commitment**: each small yes (click, opt-in, watch, buy) that moves a prospect toward the four trust beliefs.
- **Vending-machine fallacy**: expecting $2 back for every $1 put into ads right away.
- **Chinese Bamboo tree**: growth that happens underground first. Commit for 5–10 years, not 1–3.
- **Antifragile Funnel**: a funnel that becomes more effective and efficient over time and under stress.
- **Direct Response Copywriting**: "the Marketer's Secret Weapon." Writing that makes people respond by spending money.
- **VSL**: Video Sales Letter.

## Mental Models
- Use "profits live at the bottom of the funnel" when judging ad performance. At the top, measure trust, not profit.
- Use the coin analogy: the same product looks different depending on the angle. Diagnose the stage before writing.
- Use "the market picks the funnel" when tempted to choose a funnel you personally like.

## Anti-patterns
- **See ad → buy → profit → repeat**: no trust gets built. This is the "costliest marketing mistake ever."
- **Quitting ads after 1–2 weeks**: the main reason entrepreneurs never scale.
- **Choosing a funnel by preference**: a wrong funnel type sinks everything else.
- **Educating Stage #3/#4 prospects on the problem**: it bores or repels people who are already past that stage.
- **HubSpot's 3-stage journey**: dismissed as a "Rubber Chicken" version of Schwartz.

## Worked Example
B2B recruiting for tech startups. PROBLEM: high employee turnover. ALTERNATIVE: an in-house recruiting team. TYPE: recruiting services. BRAND: you. A Stage #1 founder shrugs off turnover as normal for startups, so run a Webinar Funnel that shows how devastating it becomes. A Stage #2 founder is building in-house, so use a VSL on the hidden risks of DIY recruiting. A Stage #3 founder is comparing recruiters, so use a Trip-Wire positioning you as most relevant, superior and unique. A Stage #4 founder has chosen you but hasn't signed, so use Retargeting that resolves last objections.

## AI Training
There is a link to "AI Training on Funnel Planning." Its purpose is to help define the 12 copy variables and their sub-variables (which appear only in the training), pick the funnel, and build it. No prompts are printed.

## Key Takeaways
1. A funnel is a trust algorithm of micro-commitments. Profit comes at BOFU through follow-up.
2. Expect to break even or lose money up front. Growth is slow at first, like the bamboo tree.
3. Diagnose the Buyer's Journey stage (Indifferent, Curious, Comparing, Negotiating, Committed) from what prospects know about problem, alternatives, type and brand.
4. Match the funnel to the stage: Webinar (#1), VSL/Quiz (#2), Trip-Wire (#3), Retargeting (#4).
5. Define the 12 Copywriting Kitchen variables once and reuse them everywhere.
6. Separate EXTERNAL objections (about the solution) from INTERNAL ones (about themselves).
7. Plan for process, mental toughness and fragility.

## Connects To
ch02 (offer in MOFU), ch04 (Stage #1/Webinar), ch05 (Stage #2/VSL), ch06 (Stage #3/Trip-Wire), ch07 (Stage #4/Retargeting), ch08 (follow-up/BOFU), ch10 (conversion benchmarks), ch11 (weak-link testing), ch12 (TOFU/MOFU/BOFU/SOFU troubleshooting)
