# Foreword & Introduction: The Dog Whistle You Don't Hear / The Root of All Marketing Problems

## Core Idea
Mistrust is at the root of all marketing problems. The fix is to earn trust intentionally, building charisma, competence and character rather than leaning on convenience, and to speak in the exact language of a narrowly defined audience (Kennedy's foreword).

## Frameworks Introduced
**The Four Ways to Earn Trust (Convenience, Charisma, Competence, Character)**: ranked from easiest and least "sticky" to hardest and stickiest.
- Convenience: fast, cheap, available. Quick to earn and quick to lose, because it depends on society-wide trust (the "Public Trust Barometer").
- Charisma: people like you. It makes a brand attractive and memorable.
- Competence: people believe you have the skill and experience to solve their problem. It removes fear barriers.
- Character: people believe you care and will keep your promises. It creates loyalty and promoters.
- When to use: audit every offer, message and funnel step for which trust type it builds.
- How: cut dependence on price and speed appeals. Deliberately design assets that show likability, results and care.
- Why it works: sticky trust survives shocks such as a recession, a new competitor or a disruptive technology. Failure mode: when convenience trust collapses (as in the 2020 shutdowns), long-working funnels stop working overnight.

**Antifragile (business/marketing)**: something that becomes stronger in response to resistance, uncertainty or crisis.
- How: keep marketing through slumps to take share from fragile competitors. Don't cut prices when a competitor enters. Adopt disruptive tech because you have the bandwidth to do so.

**Anatomy of The Antifragile Sales System (8 parts)**: 1) A Hungry Audience, 2) A No-Brainer Offer, 3) An Antifragile Funnel, 4) Strategic Copywriting, 5) Evergreen Traffic, 6) Measurable Goals, 7) Scientific Split Testing, 8) Funnel Troubleshooting.

**Dog Whistle Language (Kennedy foreword)**: embedded words and phrases that resonate deeply with one targeted segment and pass unnoticed by everyone else.
- How: profile the prospect in depth (age, life stage, values). Pick words that act as synonyms only for that group (e.g. "maturity" means reliability and diligence to people aged 62–75). Use sensory words that match how the list originally bought (visual for infomercial buyers, reading words for book-review buyers). Add "uh-oh" negatives that quietly discredit competitors ("fresh," "eager," "standardized").
- Why it works: the broader the audience, the less influence you have. Precision matching beats one-message-fits-all.

## Key Concepts
- **Mistrust**: the root cause of every marketing problem. Trust is what turns ideas into action.
- **Convenience-based trust**: trust given because verifying is inconvenient. It is fragile and attracts cheap customers who turn on you.
- **Rubber Chicken marketing**: vague, recycled advice ("be authentic," "sell benefits").
- **Entrepreneurial Purgatory**: being stuck on a plateau because you depend on convenience trust and simple tactics.
- **Public Trust Barometer**: society-wide consumer confidence. Convenience-based marketing rises and falls with it.
- **KISS trap**: looking for simple fixes to complex problems. It works while you climb and becomes a millstone near the top 1%.
- **Message-audience precision match**: splitting a list into 6–60 sub-segments with matched copy to beat a broad control.
- **Four respects (Kennedy)**: respect language, audience, the craft of selling, and integrity/authenticity.

## Mental Models
- Use the stickiness ladder (convenience → charisma → competence → character) when results are dismal, unstable or suddenly stagnant. You are probably over-relying on the first rung.
- Use dog whistle words when you know the segment deeply. Use sensory channel matching when you know how the list bought.
- Frame the question as "how much will we win?" rather than "will we win?" Get there by narrowing the audience, crafting the copy and choosing the media.

## Anti-patterns
- **Competing on fast/cheap/available**: this attracts the least loyal, most negative customers and breaks when public trust drops.
- **One-message-fits-all copy**: Kennedy calls it "foolish arrogance." It gives up influence.
- **Picking synonyms from a thesaurus for variety**: choose the word that fits the specific reader instead.
- **Wanting to write copy but disliking selling**: disrespect for the craft gets punished.

## Worked Example
Kennedy's financial-advisor copy ("MATURITY MATTERS") targeting savers aged 62–75 contrasts young advisors, with their "manicured" nails, "fresh and eager" manner and "standardized" charts, against advisors with "years of experience on this earth" who are "not falling for fads." Each bolded phrase is a dog whistle. "Maturity" signals reliability. "On this earth" is a gravitas phrase with a church-y tone. "Falling for" draws on older people's fear of falling and pride in being nobody's fool. The result was double-digit ROI improvements.

## AI Training
There is no training content in these sections. Each later chapter ends with a link to optional AI Training.

## Key Takeaways
1. Every marketing problem is a trust problem. Learn how trust works, then earn it on purpose.
2. Convenience trust is the least sticky. Balance charisma, competence and character instead.
3. An antifragile business keeps marketing through crises and gains share while fragile competitors retreat.
4. The system has 8 parts, running from Hungry Audience to Funnel Troubleshooting. This is a complex process, not a simple hack.
5. Narrow the audience and match its exact language. Dog whistle words are how you show respect.
6. Cash flow from customers, won through sticky trust, is the only sustainable funding source.

## Connects To
ch01 (Hungry Audience), ch02 (No-Brainer Offer; its five components map to the four trust types), ch03 (funnel as trust algorithm), ch04–ch08 (copy), ch09 (traffic), ch12 (troubleshooting), bonus1 (avatar depth for dog whistle language)
