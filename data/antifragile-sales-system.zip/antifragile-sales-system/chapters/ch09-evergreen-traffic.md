# Chapter 9: Evergreen Traffic

## Core Idea
One is the worst number in marketing: one client, one offer, or one traffic source leaves a business fragile and stuck in "boom-bust" cycles. Paid ads are how you scale to seven figures. Evergreen traffic (attention that keeps arriving when you are not actively working for it) is what keeps you there. You build it by treating traffic as **equity** rather than income. That means using paid and earned channels to grow the owned channels you control, and feeding all of them from one piece of seed content that you splinter.

## Frameworks Introduced

### Traffic Income vs Traffic Equity (mindset shift)
- **When:** as soon as the business makes money, and whenever you decide how to spend profit or effort.
- **How:** Put 50–80% of your attention into building equity, meaning assets that produce income when you aren't working on them. Examples: a list you have a relationship with (List + Your Relationship With The List = Equity), review volume on trusted sites, syndicated interviews and articles, and reusable ad assets. Keep 6–12 months of expenses in an emergency fund, then reinvest as much income as you can into equity. Don't pay yourself a large salary too early.
- **Allocation path:** Most people run New 90–100% / Evergreen 0–10%. Move to 50/50 first, then aim for New 0–20% / Evergreen 80–100%.

### The Antifragile Traffic Triad
Three channel types. Their strengths cancel each other's weaknesses.
| Type | Definition | Examples | Pros | Cons |
|---|---|---|---|---|
| Paid | You pay to publish and promote | PPC, magazine advertorials, video ads, radio, infomercials | Fast, direct, large reach | Highest cost, heavy competition, platform content rules |
| Earned | You earned the right to be published | SEO rankings, **your social pages/groups/profiles**, guest blogs, columns, podcast/radio/TV guest spots | Credibility, reach, publicity leverage | High time and labor cost, high rejection rates, platform rules |
| Owned | You own and control distribution | Website/RSS, email list, direct-mail newsletter, your podcast, branded print | Exclusive access, few restrictions, cheap, you own the data, evergreen | Takes time and money to grow the audience |

Social media counts as **earned**, not owned, because the platform can shadowban you or delete your account.

### The 3 Rules for picking channels (apply in this order)
1. **Equity:** Every channel must grow your owned channels (list, direct mail, membership). Use paid and earned channels only to feed owned ones. Don't overrate "as seen in" logos, because no media outlet can supply the trust formula for you (Convenience, Charisma, Competence, Character).
2. **Relevance:** The channel must reach your hungry audience (ch01). Ignore "you need to be on TikTok" advice based on hype or user counts.
3. **Credibility:** Where you show up frames how people see you. The author's example is an attorney whose ad sat in a urinal. Filter the relevant equity-building channels by credibility, and don't start from credibility alone.
- **Why it works:** traffic compounds into assets you own, so the business survives platform bans, ad-cost spikes, and recessions. **Failure mode:** chasing whichever channel is new or popular, which builds visibility without equity.

### How to Create Your Traffic Machine (3 steps, repeat monthly)
1. **Pick Your Traffic Channels** with the 3 Rules. Use at least 2 paid, 2 earned, and 2 owned channels, but start with no more than 3 of each. Aim for impact first and volume second.
2. **Plan Your Messaging** per channel and per stage of the Five Stages of Buyer's Journey. For example, Stage 1–2 uses teaser articles, advertorials, explainer videos, guest articles, SEO articles, and the trust-building sequence. Stage 3 uses trip-wire ads, the trip-wire sales page, and a flash-sale sequence. Stage 4 uses retargeting ads and a retargeting page. Stage 5 (customers) uses members-only pages, SMS/email flash sales, and direct-mail greeting cards.
3. **Create, Splinter, and Distribute:** Each month, take one piece of **seed content**, split it into about 20 subtopics, and produce a month of content for every channel. Draw from a **Content Pantry** (a book, course or lecture series, article/podcast library, or a swipe file organized by Buyer's Journey stage). Reevaluate channels monthly using ch10 KPIs.
- **Why it works:** messaging stays consistent and sequential across channels, and you never have to invent new ideas from scratch.

### Direct Mail as an owned channel
The author strongly recommends it, especially for B2B, existing customers, partners, and enterprise clients. Mailing 2–3 times a year sets you apart from inbox noise. Stats cited (DMA 2018): direct mail response rates of 5–9% vs about 1% for email, up to 90% opened vs 20–30% email open rates, 60% of catalog recipients visit the website, and 73% of consumers prefer mail from their favorite brands.

## Key Concepts
- **Evergreen Traffic:** attention that reaches your content and funnel without active effort.
- **New Traffic:** attention you have to keep generating yourself.
- **Equity:** an asset that earns when you aren't working. "The secret to evergreen income is evergreen traffic, and the secret to evergreen traffic is equity."
- **Paid / Earned / Owned Channels:** the three legs of the Antifragile Traffic Triad.
- **Seed Content:** the single monthly source piece (book chapter, podcast, article, interview transcript, or funnel copy).
- **Content Pantry:** a stocked library of source material for fast, consistent content.
- **Content Splintering:** one seed becomes about 20 subtopics, which become multi-format, multi-channel posts.
- **Attention problem:** marketing turns attention into money. Paraphrasing Rudy Mawer, you don't have a money problem, you have an attention problem.

## Mental Models
- Money isn't made, it's attracted. It moves through people, so attention comes before income.
- Paid and earned channels are rented land. Owned channels are the house you are building.
- "Where you show up sets the frame": a channel's credibility transfers to you, for better or worse.
- Pulling income out too early caps your wealth, much like eating ice cream five times a day while dieting.

## Anti-patterns
- 90–100% of effort going into new traffic, or depending mostly on one traffic source.
- Treating social media profiles as owned assets.
- Choosing channels because they are new, popular, or cheap ("Rubber Chicken" advice).
- Trying to be everywhere. Show up where your audience will find you.
- Buying "as seen in" badges that don't improve measurable results.
- Writing off direct mail as more expensive than email.
- Creating fresh content from scratch every week instead of splintering seed content.

## Worked Example
Example: a marketing coach running a VSL funnel, with a membership upsell and a 6-month high-ticket coaching call at the end. The seed content is a 12-chapter book. Each month, 1 chapter becomes 20 subtopics:
- **Owned:** Website gets 4 weekly blogs (the best 4 subtopics), each with a CTA to the VSL squeeze page. Email gets 20 messages and SMS gets 20 messages, each with a CTA to the VSL or that topic's social post. Direct mail gets 1 newsletter article (the best subtopic) with a CTA to the call-booking page.
- **Earned:** LinkedIn gets 20 posts and Facebook gets 20 posts, each with a CTA to the VSL squeeze page or the matching blog. Instagram gets 20 reel scripts and YouTube gets 20 short scripts, each asking viewers to like/share/follow and/or visit the VSL. LinkedIn, Facebook, and Instagram also get 20 quote images.
- Add paid ads and all three legs of the Triad are running.
- Sample shortlist: Paid (LinkedIn, Success Magazine), Earned (YouTube, Forbes.com), Owned (Website, Newsletter).

## AI Training
Online (chapter-9). It has you build an interview outline so that someone can interview you, then use the transcript as seed content and splinter it across channels.

## Key Takeaways
- Evergreen traffic is the only way to sustain income above seven figures. Paid traffic gets you there.
- Every paid and earned effort should grow an owned channel, especially your list and direct mail.
- Pick channels with Equity, then Relevance, then Credibility. Use 2–3 per type, not more.
- Plan content per channel and per Buyer's Journey stage, then splinter one seed piece into a month of content.
- Reinvest profits into equity once you have 6–12 months of emergency reserves.
- Direct mail is underused and far outperforms email on response rates.

## Connects To
ch00 (antifragility, trust formula), ch01 (hungry audience = Relevance rule), ch02 (No-Brainer Offer converts the attention), ch03 (funnel types and Buyer's Journey), ch04–ch07 (stage copy used per channel), ch08 (trust-building, flash sale, loyalty sequences for owned channels), ch10 (traffic KPIs for monthly channel review), ch12 (channel is the last suspect in TOFU troubleshooting), bonus2 (AI automation for splintering and omnipresence).
