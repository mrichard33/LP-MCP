# Chapter 11: Scientific Split-Testing

## Core Idea
You can build an Antifragile Sales Machine "as fast as you can split test." Ordinary A/B testing only finds a winning ad. **Scientific Split Testing** also starts from a hypothesis meant to reveal your audience's buying psychology: why they buy, why they don't, and how they want to buy. One test's insight then carries into every message in the funnel, from ads through sales scripts. The author estimates most marketers use about 5% of split testing's potential.

## Frameworks Introduced

### Control / Variant loop (basic split testing)
Send half the traffic to the **Control** and half to a **Variant**. After a few hundred to a few thousand visits, keep the winner as the new Control and build a new Variant. Test headlines first. When headline gains stop, move on to the opening, price, guarantee, subhead, CTA button text, and primary images.

### Scientific Split Testing (two goals)
1. Find the winning version.
2. Uncover buying-psychology insights.

**How:** Form a hypothesis based on one of the 4 elements. Test your top guess against your second-most-likely guess. Make the winner the control and test it against the next option. Once an element has a clear winner, use it in every message: traffic content, funnel copy, followup, and appointment-setting and sales scripts.
- **Why it works:** people rarely know or state their real reasons, but their clicks and purchases reveal them, and one insight improves every touchpoint. **Failure mode:** testing random tweaks without a hypothesis, or trusting clichés like "benefit copy always wins."

### The 4 Scientific Split Testing Elements
1. **Human Need(s):** 4 Need/Pain pairs.
   - Validation / Shame
   - Excitement / Boredom
   - Security / Fear
   - Purpose / Futility

   First find the driving need, then find the direction: do they move toward the need or away from the pain? Often one works for the hook and the other closes, and which is which varies by funnel. The core belief behind this is "Make them WANT to believe you." If they want to believe, they will accept almost any reason, even an unreasonable one. The author claims 2–3× KPI lifts on average and up to 10×.
2. **Seth's Super Seven:** the buyer's expectation of *how* the product solves the problem.
   1. Fast
   2. Easy
   3. Powerful
   4. Safe
   5. Durable
   6. Enjoyable
   7. Stylish

   Run them as a tournament: winner against the next element. Combine the top two in all copy (for example Fast + Easy). The product has to actually deliver on the winning claim.
3. **Stage of Awareness:** test Stage 1–3 messages against each other. You don't need an offer, only a couple of ads and a lead page. The winner tells you the funnel type: **Stage 1 → webinar funnel; Stage 2 → VSL funnel; Stage 3 → Trip-Wire funnel.**
   - Stage 1 (Indifferent) objections and rebuttals: "I don't have that problem" → make it relevant. "Not serious" → make it critical. "Can wait" → make it urgent.
   - Stage 2 (Curious): "What causes it?" → clarify the cause. "How to solve?" → reveal secrets. "I'm already doing ___" → expose mistakes. "Which is best?" → debunk alternatives. "Not for me" → sell your type of solution. One high-value curiosity appeal is enough for the test.
   - Stage 3 (Comparing): "Competent?" → bold guarantee. "Trustworthy?" → company story. "Available elsewhere?" → USP. Test all three.
4. **Primary Objection(s):** test these only with Stage 4 prospects, in retargeting funnels and near the end of the Trust-Building Sequence and Post-CTA.
   - Stage 4 objections: "What happens next?" → define the client journey. "What if it doesn't work?" → overcome objections or guarantee. "I can do this later" → limited time or supply.
   - Objection categories (ch07): **External** (product type), **Internal** (can the PROMISE happen for *me*), **Commitment** (time and action required), **Character** (do you care or just want money).
   - Put the winning objection into the Offer Stack, Post CTA, cart page, bonuses, and sales scripts.

### Elements to test
Headlines, subject lines, openings, CTAs, Post CTAs, objections, and No-Brainer Offers.

## Key Concepts
- **Control / Variant:** the incumbent version and the challenger.
- **Hypothesis:** a prediction tied to one test element, tested against your next-best guess.
- **Driving Need:** the human need at the root of the problem the product solves.
- **Pain-driven vs benefit-driven:** the audience's direction of motivation, found by testing.
- **Super Seven:** Fast, Easy, Powerful, Safe, Durable, Enjoyable, Stylish.
- **Stage of Awareness test:** the result chooses between webinar, VSL, and Trip-Wire funnels.
- **Primary Objection:** the hidden real objection. Stated ones like "let me think about it" are usually smoke screens.
- **Becoming the voice in their head:** the result of accumulated psychology insights.

## Mental Models
- Split testing is "the slowest fast way" to scale. Progress is incremental but compounds.
- Actions reveal what self-reports hide. Test behavior, not opinions.
- A test's real product is the insight into your audience, not the winning ad.
- Getting rich is hard by design. If it were easy, the 1% would be 90%.

## Anti-patterns
- Asking "how long will it take?" and quitting at the first sign of resistance.
- Testing without a hypothesis, or only to find a winning ad.
- Assuming benefit-driven copy always beats pain copy.
- Avoiding pain-point messages like Shame because they make you uncomfortable ("People want what they want").
- Promising a Super Seven quality the product doesn't deliver.
- Guessing awareness stage from AI funnel planning instead of confirming it by test.

## Worked Example
Coaching or income offer, Human Needs sequence:
1. Test Excitement ("For anyone ready to turn their yearly income into their MONTHLY income") against Security ("The safest way to replace your income from home"). Excitement wins, and the result is confirmed on ads, landing pages, emails, and posts.
2. Test Excitement against its pain, Boredom ("For anyone tired of their boring, dead-end job"). Boredom wins.

Insight: the audience is driven by the need for Excitement and motivated by moving away from Boredom. Next, check whether the need works better in hooks and the pain near the CTA and PS, or the reverse.

Super Seven: Fast ("Write copy 10x faster with this AI template system") against Easy ("so easy you'll want to do it for fun"). If both score well, merge them into a single "breeze through your copy 10x faster" message across all channels.

Stage test: "3 Warning Signs You're Aging Dangerously Fast" (Stage 1) against "3 Habits That Could Save Your Long-Term Memory" (Stage 2). If Stage 1 wins, build a webinar funnel.

Objection test: Version 1 ("What to expect during your first visit") beats Version 2 ($500 results guarantee), then Version 3 (offer expires when you leave) beats Version 1. "I can do this later" is the primary objection, so test next against the External, Internal, Commitment, and Character variants.

## AI Training
Online (chapter-11). It generates hypothesis-based variant pairs for each of the 4 elements.

## Key Takeaways
- Every test needs a hypothesis tied to Need, Super Seven, Awareness, or Objection.
- Find the driving need first, then whether they move toward the need or away from the pain.
- The Awareness test tells you which funnel to build (webinar, VSL, or Trip-Wire).
- Test objections only with Stage 4 audiences, such as retargeting and the end of trust-building.
- Apply every winning insight across all channels and scripts, not just the tested asset.
- Keep testing headlines until gains plateau, then move to other elements.

## Connects To
ch01 (audience psychology), ch02 (offer tests), ch03 (funnel selection and Stages of Awareness), ch04–ch06 (stage 1–3 message formulas), ch07 (objection categories and formulas), ch08 (Trust-Building Sequence as a test site), ch10 (KPIs that decide winners), ch12 (statistical significance and troubleshooting), bonus3 (grief-stage headline variants as test candidates).
