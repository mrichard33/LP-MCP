# Chapter 1: A Hungry Audience

## Core Idea
Money moves through people, and it moves because of human need. Start with a big, painful problem, not with a product or an audience. Then let real spending behavior show you who is hungry enough to pay what the solution is worth.

## Frameworks Introduced
**"Who's hungry and what are they hungry for?"**: this replaces "Who's your audience/avatar/demographic?"
- When to use: before building any product, offer or funnel, and again when an existing business is struggling. Either the product or the messaging may be wrong.
- How: list 3–5 problems that are **big, complex, painful, pervasive, and persistent**. Ignore who has them for now. Choose the one with the heaviest impact.
- Why it works: the bigger and more persistent the pain, the more people pay to fix it. Failure mode: starting from a "3am Beer Conversation" idea and then hunting for buyers who ignore you.

**Problem / Impact / Benefits (PRIMARY PROBLEM → NEGATIVE IMPACT → BENEFITS)**
- How: 1) Name the PRIMARY PROBLEM. 2) List every NEGATIVE IMPACT plainly, with nothing cute. 3) Flip each negative impact into its positive BENEFIT. 4) Write simple copy using only those three lists, with no product mention.
- Why it works: trust starts with connection, and connection comes from describing the prospect's everyday experience of the problem.

**Relevant / Critical / Urgent test**: people spend on problems they *perceive* as relevant, critical and urgent. Perceived severity predicts spending better than wealth does.

**Problem-to-Audience via response**: rather than doing hours of audience research, put simple problem/impact/benefit messages in front of a broad audience and see who responds by spending money. Then use what you learn about those responders to sharpen your messages.

## Key Concepts
- **Hungry Audience**: people with the biggest physical, social and/or emotional commitment to solving a problem, whatever their income.
- **Hunger beats purchasing power**: a broke but hungry buyer will find the money, while a rich buyer who doesn't care won't spend.
- **"Buyers want what they want, not what you want them to want."**: the core rule, repeated throughout the book.
- **Pick-Up Line Marketing**: clever or cute hooks that court attention without building connection.
- **Price-conscious customers**: people who have the problem but won't pay what the fix is worth. They are the least loyal and the most negative.
- **Say/do gap**: stated values change once you ask for time, effort or money, so surveys and opinions are unreliable.
- **Money moves through people**: the only moral way to get money is to persuade people to hand it over by earning trust.

## Mental Models
- Use "find the problem and you'll find the audience" when you are tempted to define a target market first.
- Use behavior over opinion (Vance Packard, *Hidden Persuaders*) when you are validating demand. Only spending counts.
- Use the golfer's-elbow contrast when judging hunger. A 22-year-old with a minor ache won't pay, while a man in his late 50s losing golf, fitness and time with his grandkids will pay hundreds.

## Anti-patterns
- **"If people really want it, you don't have to market it"**: people may not believe or understand you even when they want what you sell.
- **Starting from a product idea**: fancy funnels, AI hacks and split tests cannot rescue a product that doesn't solve a big problem.
- **Surveys, forums, friends, interest groups**: stated opinions don't predict spending.
- **Targeting wealth instead of hunger**: selling something they don't care about to rich people is like selling a yacht to a homeless person.
- **Clever hooks**: they get attention and maybe a few sales, but never consistent profit or scale past a few hundred thousand a year.

## Worked Example
B2B, customer churn. PROBLEM: churn. IMPACT: revenue loss, higher CAC, burned-out staff, bad reviews. BENEFITS: higher LTV, lower CAC, loyal advocates, five-star reviews. Copy: "Tired of losing customers? It's stunting your growth, making advertising expensive, burning out your staff and hurting your reputation. Wouldn't you rather have customers who buy again and again and promote you to friends? If that's the business you want, this will be the most important message you've ever read." No product is mentioned. (The B2C version does the same for arthritis foot pain.)

## AI Training
There is a link to "AI Training on Market Research." Its purpose is to help you research problems, impacts and hungry audiences. No prompts are printed in the book.

## Key Takeaways
1. Money moves through people and moves because of need. People pay to solve problems they believe are relevant, critical and urgent.
2. Start with the problem, not the audience or product. Existing businesses must redo this step too.
3. Choose problems that are big, complex, painful, pervasive and persistent. Pain size sets price tolerance.
4. Hunger outweighs purchasing power.
5. Map PROBLEM → NEGATIVE IMPACT → BENEFITS by flipping each impact into a benefit. Write plain, connection-first copy from those lists.
6. Validate by putting messages in front of a broad audience and watching who spends. Never rely on surveys.

## Connects To
ch00 (trust), ch02 (offer must be relevant to the problem), ch03 (PROBLEM/PROMISE variables, Buyer's Journey), ch04 (Stage #1 makes the problem relevant), ch09 (broad traffic tests), bonus1 (avatar)
