# Chapter 2: A No-Brainer Offer

## Core Idea
Paid advertising is the most reliable way to scale past seven figures. It only works when you accept losing money or breaking even on the first sale, using a No-Brainer Offer that makes becoming a customer easy and risk-free, and then profit from the repeat purchases that trust produces.

## Frameworks Introduced
**No-Brainer Offer (5 components → 4 trust impressions)**: a low-cost first offer that makes it as easy and risk-free as possible for a stranger to buy for the first time.
1. Promises an Outcome (Competence)
2. Removes Risk, of both money and time (Competence & Character)
3. Offers Fast and Easy Delivery (Convenience)
4. Overdelivers on Your Promise (Character)
5. Promotes Your Brand's Uniqueness (Charisma)
- The target impressions are: easy to do business with, likable and memorable, can deliver results, cares about customers.
- When to use: as the front-end offer for all cold paid traffic.
- How: write each of the five parts explicitly (plus the "Offer" line itself). Put the thank-you note, company story, catalog or brochure and a second offer inside the delivery.
- Why it works: customers buy from brands they already know and trust, so the first purchase is the trust-building step. Failure mode: a plain discount is *not* an offer. There is no risk removal, no overdelivery and no branding.

**Three types of No-Brainer Offers**
1. **Physical Products**: free plus shipping. Suited to e-commerce and direct mail, and can also front high-ticket services (e.g. a book mailed out to sell coaching).
2. **Introductory Services**: a deep-discount first engagement (e.g. 70% off), filtered by an automated application and by qualification messaging.
3. **Information Products**: the author's favorite. Near-zero delivery cost, educates the buyer, and makes you "the voice in their head."

**Customer-value math (buy customers, don't sell products)**: first work out what a customer is worth, then decide how much to lose acquiring one.
- How: monthly profit per customer × average lifespan = customer value. Compare that with the upfront loss (offer cost + ad cost) and the payback period.

**The offer relevance rule**: the offer doesn't need to solve the problem. It must help the buyer understand it better or make some progress on it or its symptoms.

## Key Concepts
- **"The goal of your first sale is to get a customer"** (Dan Kennedy): profit comes later, from repeats, reviews and referrals.
- **Expense vs investment**: nothing is expensive if it returns more than it cost. Remove "expensive" from your vocabulary.
- **Myth of "free" marketing**: networking, social posting, cold DMs and the like all cost time and energy. Energy is your #1 asset and time is #2.
- **Buy back time / buy speed**: invest money in ads as soon as you have *any* money, not once you can "afford" it.
- **Selling how buyers want to buy**: they want no gamble, easy ordering, fast delivery and more value than they paid.
- **Penny Pinchers**: price shoppers who treat the intro price as the real price. Filter them with an application form and with messaging.
- **Pareto Distribution (80/20)**: 10–20% of new customers produce most profit. Build trust after purchase to get the most from them.
- **Offer > copy**: a strong offer sells with average copy, and great copy can't save a bad offer.

## Mental Models
- Use "would you pay $50 for a customer worth several hundred in 90 days?" when someone says paid ads "didn't work."
- Use the trust-type mapping when auditing an offer. Every component should create a specific impression.
- Use a physical or direct-mail offer when everyone else markets only online. It sets you apart.

## Anti-patterns
- **Expecting profit on the first sale**: the #1 reason businesses never scale. They quit ads that aren't instantly profitable.
- **Plain discounts dressed up as offers**: they build no trust and deliver no overdelivery.
- **Timid risk reversal and cheap fulfillment**: fear of bold guarantees and reluctance to overdeliver kill conversions and repeat business.
- **No immediate second offer in the delivery**: a missed chance to move the customer to a repeat purchase.
- **Waiting to "afford" ads**: this gets the process backwards and keeps you at $20k–$50k/month.
- **Hunting for a "creative" offer**: people buy solutions to problems, not big ideas.

## Worked Example
Gourmet coffee, cold start. Ad: "Try your first bag RISK FREE for 30 days! [PROMISE] If this isn't the richest, smoothest cup you've ever had, [MONEY RISK] we'll refund 100% of shipping [TIME RISK] and buy you any competitor's bag up to $50. [DELIVERY] Just pay shipping; arrives in 72 hours." Overdeliver: premium branded package, thank-you note, company story, catalog, and a subscription offer at 25% off for life. Math: the bag costs $5 and sells for $12. The customer brings about $30/month profit (two bags plus mugs and machines) × 18 months ≈ $540 value. An upfront loss of up to about $50 (offer plus ads) is paid back in a little over a month.

Info-product version (arthritis nutrition service): a $7 starter course (ebook, videos, reset plan), with a promise to free you from reactionary arthritis, a 100% refund plus a $50 gift card, instant download, bonuses plus a community, and the company story inside.

## AI Training
There is a link to "AI Training on Offer Development." Its purpose is to help you design a No-Brainer Offer that converts on paid traffic, which the author calls the hardest step. No prompts are printed.

## Key Takeaways
1. Paid advertising is the scalable path. Word of mouth or going viral is a lottery.
2. The first sale buys a customer and trust. Break even or lose money on it on purpose.
3. Build the offer from 5 components: promise, risk removal, fast/easy delivery, overdelivery, brand uniqueness.
4. Know your customer value (monthly profit × lifespan) and let it set how much you can pay to acquire a customer.
5. Information products are the best No-Brainer Offers. They cost little to deliver and educate buyers for later offers.
6. Filter Penny Pinchers with applications and messaging. Profit comes from the top 10–20%.
7. The offer matters more than the copy. Take your time getting it right.

## Connects To
ch00 (four trust types), ch01 (problem relevance), ch03 (offer sits in MOFU; funnel math), ch06 (Stage #3 offer positioning/stack, qualification), ch08 (upsells, loyalty), ch10 (tracking customer value), ch12 (loyalty to love)
