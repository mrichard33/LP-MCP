# Chapter 10: Measurable Goals

## Core Idea
"What gets measured, gets better." The author says the biggest difference between entrepreneurs who break seven figures and those who backslide is setting measurable goals and tracking KPIs at every stage of commitment. Without numbers you are gambling. With them you can forecast returns on traffic spend and judge a funnel by long-term customer value instead of front-end ROAS.

## Frameworks Introduced

### Three Ingredients of Good Marketing: Math, Strategy, Psychology
- Earlier chapters covered Psychology. Strategy is psychology and math working together. Math means measurable goals.
- **How:** Every goal block uses the same template:
  - **MATH (GOAL):** a numeric KPI target.
  - **STRATEGY:** match the Buyer's Journey stage, the buying trigger(s), and the driving need.
  - **PSYCHOLOGY:** the copy techniques that move that metric.
- **Review loop:** If you beat the goal, work out which techniques caused it and apply them everywhere. If you miss, audit the asset for those same techniques.

### Five Marketing Stages (Stages of Commitment)
1. Traffic (attention and interest)
2. Lead (contact info)
3. Followup (email, SMS, phone, mail)
4. Sale
5. Customer (repeat purchases, reviews, referrals)

These are measured by **interaction**. They are different from the Buyer's Journey stages, which are about **awareness** and can't be measured directly. A lead can be at any awareness stage.

### Measurable goal criteria
Goals must be (1) specific enough to measure and (2) tied to a hard review deadline. Test a goal by checking whether it breaks into milestones. "Get more inbound leads" fails. "20 → 200 leads/month by this time next year" passes: split it into 12 monthly milestones and expect a slow, non-linear start (21, then 25...). Growth compounds by multiplication, which leads toward Dan Kennedy's "The Phenomenon," where one year out-earns the previous ten.

### KPI Forecasting
Track KPIs consistently, then scale spend using averages. Example: $1 per click-through means $1,000 buys about 1,000 squeeze-page visits. Forecasting lets you treat marketing as an investment rather than an expense or a fixed "marketing budget."
- **Why it works:** decisions rest on data rather than emotion, and the long-term value of customers justifies front-end losses. **Failure mode:** killing a break-even funnel because you only looked at ROAS or immediate KPIs.

### Lead Scoring
Assign points to subscriber actions, for example open = 1, first link click = 2, second link click = 3. When a subscriber crosses a threshold, trigger an automation: add them to a Flash Sale Sequence, add a customer to a Loyalty Sequence, or alert sales to call. Example: 30 opens + 5 first clicks + 4 second clicks moves the subscriber into the Flash Sale sequence.

## Key Concepts
- **KPI:** a measurable result that every published asset should produce.
- **Engagement:** the viewer stops to read, watch, or listen after an impression (for example, scrolling past the fold).
- **Traffic Conversion:** a buyer who purchases before becoming a lead. This differs from Lead Conversion.
- **Average Lead Conversion Cycle:** days from lead to first sale. It drives drip and purge timing.
- **Per-Pitch metrics:** revenue is measured per pitch, not per close, so you can forecast from the sales calendar.
- **Contracted vs Immediate revenue:** judge sales on the long-term contract value, not just the cash collected.
- **Customer KPIs:** these deserve 80% of your attention. The first sale earns a customer. It isn't meant to make the profit.
- **"You're gambling, not marketing":** the author's refrain for not knowing your numbers.

## Metrics & Thresholds
| Stage | KPI (definition / formula) | Book target / benchmark |
|---|---|---|
| Traffic | Impression→Engagement Rate = engagers ÷ impressions | e.g. 500/5,000 = 10% |
| Traffic | Avg Engagement Cost = spend ÷ engagements | e.g. $50/500 = $0.10 |
| Traffic | Engagement→Click-Through Rate = clicks to next step ÷ engagers | **Goal: 10–20% of viewers follow the CTA before abandoning** |
| Traffic | Avg Click-Through Cost = spend ÷ click-throughs | ~$1 in example |
| Lead | Lead Capture Rate = leads ÷ lead-page visitors | **20–50%** |
| Lead | Avg Cost Per Lead = spend ÷ leads | **$25–$50** |
| Lead | Avg Lead Cycle (days, visit→lead) | **≤30 days** (important for non-impulse offers) |
| Followup | Lead Conversion Rate = customers ÷ leads | **20–50%** |
| Followup | Avg Lead Conversion Cycle (days) | **≤30 days**. If about 90, move non-buyers to a long-term drip with lead scoring and remove them at 180 |
| Followup | Avg Lead Conversion Value = revenue ÷ converted leads | **$100** |
| Sales | Traffic Conversion Rate (buy before opt-in) | **1–3% of cold traffic** |
| Sales | Avg Traffic Conversion Cost / Value (include bumps, upsells, downsells) | **Value = 75–100% of Cost** (break-even front end is fine) |
| Sales | Call Booking Rate / Call Show Rate | **20–30% / 50–60%** (a 50% show rate is above average for cold traffic) |
| Sales | Avg Cost Per Call / Per Pitch = spend ÷ booked or ÷ showed | **~$250 per pitch** |
| Sales | Pitch Close Rate = sales ÷ pitches | **20–30%** |
| Sales | Avg Revenue Per Pitch (immediate) / Avg Contracted Per Pitch | **$400 / $5,000** |
| Customer | Avg Revenue Per Customer (measure over 3, 6, and 12 months) | **$500 in 90 days, $2,000 in year 1, $5,000 lifetime** |
| Customer | Avg Review Rate / Avg Review Rating / video testimonials | **20–40% / ≥4.5 stars / 5–10%** |
| Customer | Customer→Referral Rate / Referral Conversion Rate | **10–20% / 50–70%** |
| Customer | Avg Revenue Per Referral = referral revenue ÷ ALL referrals | **$500** |

Cited stats: inbound produces 3× more leads per dollar; nurtured leads make 47% larger purchases; CPL drops 80% after 5 months of consistent inbound; automated nurturing adds 10%+ revenue in 6–9 months; the odds of selling to an existing customer are 60–70% vs 5–20% for new prospects; loyal customers are worth up to 10× their first purchase.

## Worked Example
Take a Google Ads call funnel with these numbers: Booking 20%, Show 50%, Cost/Pitch $200, Close 20%, Revenue/Pitch $400, Contracted/Pitch $5,000. Spending $10,000 gets 50 shows, which gives 10 customers, about $4,000 immediate plus $50,000 contracted. Even at only $40k collected, that is 2× the spend. By the 80/20 rule, 2 of those 10 customers will likely add at least $20k later, and referrals add about $10k at no ad cost. That makes doubling spend to $20k a rational decision.

Customer-side example: a break-even VSL funnel brings in 20 customers a month at $500 per customer over 90 days and $2,000 per year. That is $10k in 90 days and $40k in a year, so the funnel is profitable after all. Over 5 months, 100 customers at a 10% referral rate give 10 referrals. At a 40% referral conversion rate, 4 of them buy, and at $500 per referral that is about $5k.

Followup forecast: CPL $25, LCR 20%, 21-day cycle, $599 value. $1,000 buys 40 leads, which gives about 8 customers in 21 days and about $4,792. (The book also says "$199 each" in this passage. Treat $599 as the operative figure.)

## AI Training
Online (chapter-10). It applies the Math/Strategy/Psychology goal template to your own funnel.

## Key Takeaways
- Set specific, deadlined goals for all 5 stages of commitment, and expect non-linear progress.
- Use the MATH / STRATEGY / PSYCHOLOGY block for every goal, and diagnose hits and misses with the same techniques.
- Forecast spend from averaged KPIs. Treat marketing as an investment.
- Track per-pitch revenue, both immediate and contracted, not just close rates.
- Judge funnels on Customer KPIs (90-day, 1-year, and lifetime revenue, reviews, referrals), not front-end ROAS.
- Lead scoring decides who gets flash sales, loyalty offers, or a sales call.

## Connects To
ch02 (the first sale earns a customer, not profit), ch03 (funnel stages), ch08 (flash sale, loyalty, reminder, call-booking sequences), ch09 (traffic channels and equity), ch11 (split-testing weak KPIs), ch12 (the same KPIs grouped by TOFU/SOFU/MOFU/BOFU, with benchmarks).
