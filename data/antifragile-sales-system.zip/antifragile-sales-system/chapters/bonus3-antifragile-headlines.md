# Bonus Chapter 3: Antifragile Headlines — by Loren M. West

## Core Idea
By the 80/20 principle, West says the headline carries at least 80% (sometimes 99%) of the value of any sales message: ads, pages, SMS, emails, letters, DMs. A strong headline pulls in the ideal buyer and repels everyone else. An **Antifragile Headline** combines two things: where the prospect sits on the **5 Levels of Market Awareness**, and the **grief-stage emotion** they are feeling about the problem (Kübler-Ross's Denial, Anger, Bargaining, Depression, Acceptance). The message then meets them in their current emotional state.

## Frameworks Introduced

### 3 Headline Elements
- **Pre-Head:** a filter. It disqualifies the wrong people and pulls the right ones down the page. It is usually a *question* that calls out a specific person, trait, situation, adversary, or desire.
- **Main Hook / Headline:** the BIG IDEA, a collapsed version of the whole message. It is a *statement* of authority making a definite promise to solve ONE core problem. Strengthen it with a time constraint, "Even if...", or "Without...".
- **Sub-Head:** closes the pre-head/headline loop, *opens a new loop* (a bonus for reading on), further qualifies or disqualifies, and carries the secondary benefits and problems solved. It is also a good place for "Even if/Without."

### 5 Headline Angles
1. **Pain-Points:** vivid, emotional pain and urgency.
2. **Direct-Pitch:** state the offer plainly, with the "why now" in the sub-head.
3. **Curiosity:** strange, unusual, or almost-too-good-to-be-true phrasing that lowers defenses.
4. **Controversy:** polarizing or absurd, a pattern interrupt. West's sign of success: the wrong people get angry while ideal clients show up ready to buy. Use with care.
5. **Story-Based:** drop the reader into the middle of the action like a film ("facts tell, stories sell").

### Simple Headline Framework (5 steps)
1. Identify the single BIG IDEA, tied to the main offer.
2. List the extra BENEFITS and PROBLEMS SOLVED, for use in the pre-head and sub-head.
3. Write a pre-head that calls out the target, ideally as a question aimed at a specific person.
4. Write a main headline addressing ONE major problem or goal, using an angle.
5. Write a sub-head that promises more information or an extra benefit for continuing, using an angle.

### AntiFragile Headline Chart (awareness level × grief emotion)
People don't move through the grief stages in order. They cycle through "micro" stages with every problem. So each awareness level has several possible emotions, and you pick the dominant one. The chart runs from COLD to HOT:
| Awareness level | Emotion → headline job |
|---|---|
| **1 Unaware** | **Anger:** address the frustration and reveal the hidden cause and the fix. **Depression:** empathize and position the offer as the light at the end of the tunnel. **Subconscious Rumination:** validate lingering stress, then offer a way out. |
| **2 Problem Aware** | **Bargaining:** show that a path to relief exists and "what-ifs" keep them stuck. **Enhanced Anger:** tap its intensity, highlight unfairness, give a sharp CTA, present the offer as the best or only option. **Enhanced Depression:** empathize and turn pain into a catalyst. **Denial:** help them get through resistance to a positive outcome. |
| **3 Solution Aware** | **Sustained Anger (Envy/Jealousy):** they feel cheated or late, so turn the frustration into action. **Informed Denial:** name the cold feet and prove it will work for them. **Acceptance:** they are comparing options, so show why YOUR solution is best. |
| **4 Product Aware** | **Bargaining:** a "deal with fate" over which product to pick. Show the power of choosing now. **Final Denial:** name the lingering doubt and make waiting more painful than buying. **Final Acceptance:** empower them and remove last-minute objections. |
| **5 Most Aware** | **Price Bargaining:** they are working out whether they can afford it, so strong positioning tips them over. **Total Acceptance:** use for retargeting, checkout, and upsell copy. |

West's original "perfect-order" mapping is a simpler template: Unaware = Denial, Problem Aware = Anger, Solution Aware = Bargaining, Product Aware = Depression, Most Aware = Acceptance.

### How to apply it (5 steps)
1. Get crystal clear on the ideal client.
2. Get clear on their problem and how you solve it.
3. Place them on the 5 Levels of Market Awareness.
4. Pick the dominant emotion at that level.
5. Write the headline from those inputs.
- **Why it works:** emotion drives action. When copy mirrors the reader's current emotional state, they feel heard and see you as an authority, and people say yes to authorities. **Failure mode:** stacking several promises in the main headline instead of one core problem, or using controversy recklessly.

## Key Concepts
- **Pre-Head / Main Hook / Sub-Head:** the three parts of a full headline.
- **BIG IDEA:** the single theme carried through the whole message.
- **Questions vs Statements:** questions call people out and filter them. Statements promise with authority.
- **Angle:** the creative lens (pain, pitch, curiosity, controversy, story).
- **Micro stages of grief:** condensed, out-of-order emotional cycles attached to any problem.
- **Subconscious Rumination:** perseverative negative thinking that keeps stress alive.
- **Buyer's state:** the goal state the headline moves the reader toward, away from pain.

## Mental Models
- The headline is the first domino in a chain of persuasion.
- Repelling the wrong reader matters as much as attracting the right one.
- Meet the reader where they are, both emotionally and in awareness.

## Anti-patterns
- Generic headlines that call nobody out.
- Several core promises in the main headline (secondary benefits belong in the sub-head).
- Assuming prospects move through emotions in a tidy order.
- Controversy for its own sake, or using the power manipulatively ("use it for GOOD").

## Worked Example
**Pharmacy-tech income workshop:**
- Pre-head: "Are You a Pharmacy Tech That's Tired of Working 60+ Hours Per Week Around People You Hate?"
- Headline: "This Closed-Door Workshop Reveals How to Make 6-Figures As a Pharmacy Tech Without Quitting Your Current Job!"
- Sub-head: "Plus, you'll also learn the secret to paying off all your student loan debt within 1 Year!"

**Emotion-matched variants** (original-order set):
- Unaware / Denial, business coaching: your business has a 97% chance of imploding unless you simplify with this 3-step method.
- Problem Aware / Anger, home business: if you clench your fists when your cold-hearted boss walks in, start your own business.
- Solution Aware / Bargaining, real estate: 1,000+ agents quit after 7 figures with a "lazy" system, and now you can too.
- Most Aware / Acceptance, Zoom sales: now that you see Zoom's power, here is the 1% system that 10x's revenue in 35 days. Use a variant for retargeting, upsells, and emails.

## AI Training
None in-text.

## Key Takeaways
- Put most of your copy effort into the headline.
- Build every headline as Pre-Head (question and filter), then Main Hook (one-promise statement), then Sub-Head (new loop plus extra benefits).
- Pick an angle: pain, direct pitch, curiosity, controversy, or story.
- Diagnose awareness level and dominant grief emotion, then write to that intersection.
- Most Aware and Total Acceptance copy belongs on retargeting, checkout, and upsell pages.

## Connects To
ch03 (Stages of Awareness), ch04–ch07 (stage-specific ad and page headlines, Stage 4 retargeting), ch11 (grief-emotion variants as Human Need and Stage-of-Awareness split tests), ch12 (Attention/Relevance fixes in TOFU), bonus1 (avatar drives the pre-head callout), bonus2 (Magic Headline formula in AI prompts).
