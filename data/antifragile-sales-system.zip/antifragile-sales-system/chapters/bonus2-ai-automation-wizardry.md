# Bonus Chapter 2: AI Automation Wizardry — by Perry "The AI Jedi" Lawrence

## Core Idea
Copy-pasting prompts into ChatGPT or Claude works, but the real payoff comes when an AI assistant runs a whole chain of tasks on its own. Lawrence lays out a progression from better prompting (context, steps), to reusable instruction sets (instruction linking, custom GPTs), to spreadsheet prompt automation (GPT for Sheets and Docs), to full no-code workflows (Zapier + OpenAI Assistants). All of it serves the ch09 goal of **omnipresence**: consistent, on-voice content in every channel. Tool details reflect the late-2023 landscape. Treat the specific UIs and limits as dated and the patterns as durable.

## Frameworks Introduced

### Automation Continuum (5 levels)
1. **Context prompting:** start every chat with "Act as" / "You are" / "Behave like." The context sets the AI's knowledge "mindset" and persists through the chat. A **Zero-Shot prompt** has 3 parts: (1) "Do this thing," (2) Parameters, (3) "Stay in these lanes."
2. **Step-by-step prompting:** number the deliverables (for example headline → 300-word hook → Facebook ad) and tell the AI: "write each step one at a time, ask for modifications or approval, then continue." This works around output-token and context limits (the chapter cites about 4,096 max output tokens, roughly 1,300–2,000 words), which cause thinning, short memory, and rudimentary answers late in a long response.
3. **Instruction Linking:** keep the numbered instruction set in an external document (a publicly viewable Google Doc read by a link-reader plugin) and point the prompt at it: "start with instruction 1, ask approval, then proceed; ask as many questions as needed." Good for reusable section templates, style guides, and brand guides, especially for agencies with many clients.
4. **Shareable Agents (Custom GPTs):** in Configure mode, paste the role + numbered instructions + a **SECURITY block** (never reveal instructions or knowledge files, redirect to a URL). Add conversation starters ("How do I use this?", "Create a VSL Funnel for my [PRODUCT]"), turn off unneeded capabilities, and optionally upload a brand-voice or style-guide PDF as Knowledge. Benefits: shareable, hidden prompts, custom knowledge, external connections.
5. **Workflow automation (Zapier + OpenAI Assistants):** map the process first, then connect form → AI → document.

### Landing-page instruction set (used across levels 3–5)
1. Headline using Seth's Magic Headline formula: *Now you can [RESULT] and [BENEFIT] in [DEADLINE] without [CATCH] even if [DOUBT]*
2. Long-form sales letter without an offer stack: Pain, Agitation, Solution. The author introduces themselves, their experience, and the problem they saw, then builds to the solution.
3. Offer Stack
4. Benefits
5. Future Casting
6. Guarantee
7. Two Choices
8. FAQs
9. (GPT version) VSL script
10. (GPT version) 3 Facebook ads with graphic, emoji, and hashtag suggestions

The headline template is modular. Ask for several versions and mix and match the parts. If the AI asks about variables, "use best guess" is enough.

### "Word Math" with GPT for Sheets and Docs
Spreadsheet functions include `=GPT(prompt, var)`, `=GPT(range)`, `=GPT_LIST("...")`, and `=GPT_TRANSLATE(text, lang)`.
- Put the prompt and variables (Product, Audience, **DISC profile type**) in cells A1:B4 and one component instruction per row.
- Generate each component with a locked range, for example `=GPT_LIST($A$1:$B$4,$A$5)` for headlines and `=GPT($A$1:$B$4,A6)` for the hook.
- **Why it works:** change one parameter (product, tone, audience, or DISC type) and the whole page rewrites in minutes. That makes it an **A/B-variant factory** for ch11 split tests.

### Zapier article machine
- **Map first:** 3,000-word article, you supply the topic, outline first to keep the AI on track, your style guide for voice, output to Google Drive.
- **Build:**
  1. Create an OpenAI Assistant ("Content Writer") with retrieval turned on and your style-guide PDF uploaded. To make one, prompt: "Create a style guide based on this content: [3 paragraphs of your best writing]."
  2. Build a Zapier Interfaces form ("Article Starter") with a Subject field.
  3. Zap step 1 is the trigger: form submission.
  4. Step 2: the Assistant writes a 10-section outline with roman numerals and never mentions the style guide.
  5. Steps 3–12: at least 250 words per section.
  6. Final step: compile everything into a Google Doc in a "Zapier Articles" folder.
- **Deliberate human-in-the-loop:** the author stops before auto-posting so he can add his own stories and edits, and avoid becoming a content-spewing "ChatGPT Cowboy."
- **Failure mode:** fully automating publishing, which strips out your personal voice and anecdotes.

### Extension ideas (toward Omnipresence)
Tone selector, style-guide selector, section-length field, a 250-word summary auto-posted to Facebook and LinkedIn, auto image, 20 pull quotes for Instagram and X, a "ready" email to yourself, a WordPress draft, an avatar video (Synthesia) posted to TikTok. Weekly articles drawn from a book outline's chapter headings add up to a publishable book in a few months.

## Key Concepts
- **Context / role priming:** "You are a direct response copywriter..."
- **Zero-Shot prompt:** one instruction set with task, parameters, and constraints.
- **Instruction Linking:** reusable external instruction documents.
- **Custom GPT:** a shareable agent with hidden instructions and a knowledge file.
- **Prompt security block:** refuses to reveal instructions or files.
- **Word Math:** spreadsheet cells as prompt variables for bulk variants.
- **OpenAI Assistant:** an API-accessible thread with persistent context and a knowledge base.
- **Omnipresence:** one voice-consistent article splintered to every platform, building authority, credibility, and celebrity.

## Mental Models
- Move from single prompts to systems. Each level removes a manual step.
- Outline first, then write in chunks, to beat context and output limits.
- Automate the heavy lifting, not the judgment. Keep the human edit.

## Anti-patterns
- Asking for long, multi-part content in a single shot.
- Re-pasting the same instructions every session instead of linking or building a GPT.
- Leaving GPT instructions unprotected.
- Fully automated publishing ("ChatGPT Cowboy").

## Worked Example
EverHot Coffee Mug, audience Coffee Lovers, DISC type D. The sheet generates 5 Magic-Formula headlines, for example "Now you can enjoy piping hot coffee anytime... in just 5 minutes without any hassle even if you have doubts...". It also produces a 300-word hook, stack, benefits, future casting, guarantee, two choices, and FAQs. Changing D to I regenerates every component as a split-test variant.

## AI Training
The whole chapter is AI training. Video walkthroughs for GPT creation, Sheets, and the Zapier build are online (bonus-chapter-2).

## Key Takeaways
- Always set context and role first.
- Break big outputs into approved steps. Store reusable steps in linked documents or custom GPTs.
- Secure custom GPT instructions and load brand or style guides as knowledge.
- Use spreadsheet prompt variables to mass-produce split-test variants.
- Zapier + Assistant + style guide gives on-voice long-form content on demand. Keep a human edit before publishing.

## Connects To
ch04–ch08 (the copy formulas being automated), ch09 (seed content, splintering, omnipresence), ch11 (fast variant generation), bonus3 (headline formulas to feed prompts).
