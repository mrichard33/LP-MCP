# Bonus Chapter 1: Crafting the Perfect Customer Avatar — by Eric Vignola

## Core Idea
Most businesses win customers without knowing who those customers are, so their marketing falls flat when they try to scale. A detailed **customer avatar**, meaning one named, specific person rather than "everyone with back problems," makes messages resonate and makes scaling easier: more ad spend, new products, better offers. The avatar is only finished when you have "walked a mile in their shoes" by writing a diary entry from their point of view.

## Frameworks Introduced

### Avatar Build Sequence (the profile layers)
- **When:** before scaling ads, launching any product or offer, or entering a new niche. Build one per product, offer, or niche.
- **How:**
  1. **Problem solved:** People buy the solution, not the tool. They don't need a hammer, they need to hang a picture. Every product solves a problem.
  2. **Demographics ("Demographics = Dollar Signs"):** age, gender, income, marital status, children. The same product needs different messages for a married father than for a single man in his 20s.
  3. **Influences and interests:** the movies, books, and magazines they consume. These show what they will and won't do (a delegator buys a picture-hanging *service*, not a hammer) and what WORDS to use.
  4. **Lifestyle and behavior:** diet, health habits, where they shop, vitamins, cooking. These show their persistence (a diet-hopper needs the "5-minute" version) and their need-versus-want spending.
  5. **Values and goals:** someone who values time hears efficiency. Someone who wants status hears "small details handled flawlessly."
  6. **Daily focus ("The Daily Grind"):** is the day about just surviving, or about getting one thing done? This tells you when and how to reach them, for example tired at the end of the day.
  7. **Free time:** hobbies, investments, politics, pets. A stamp collector shows patience. A serious athlete shows willingness to spend. A pet owner shows how they care for others.
  8. **Friends and social network:** how their circle talks about the problem (frame weight vs which image suits which room). Use testimonials that *sound like* their friends.
  9. **Barriers and challenges:** what has held them back: not knowing solutions exist, doubting their skill, feeling they must research first. Remove those obstacles inside the offer, the way TV mounts now ship with guides, levels, and multiple screw types.
  10. **Compile, name, and add a photo.**
  11. **Write the avatar's diary entry.** The author calls this the most important step.
- **Why it works:** people filter out almost all marketing unless it calls to them specifically or speaks to a pain they are dealing with right now. **Failure mode:** believing you are the avatar. Even if you once were, you aren't anymore.

### Big-Picture Avatar Thinking
Research the avatar beyond the first product. The hammer may be your entry into a whole tool line, and a chiropractor can add massage, nutrition, and exercise plans. Knowing the avatar reveals the adjacent problems you can sell to next.

## Key Concepts
- **Customer Avatar:** a named, specific ideal customer with a full psychographic profile.
- **Tool vs Solution:** customers buy the outcome, not the instrument.
- **Callout:** the message has to feel addressed to them personally or it gets filtered out.
- **Need vs Want spending:** shopping and nutrition habits show what they will pay for.
- **Social-proof matching:** reviews in the language of the avatar's peer group.
- **Barriers:** the reasons they postpone buying. Every delay is a lost sale.
- **Avatar Diary:** a first-person emotional narrative that recreates empathy.

## Mental Models
- "Get specific, not generic." Marketing to everyone reaches no one.
- If you don't know WHY they would buy, any success you have is an accident.
- Obsessive detail pays off on small products because they open the door to the whole line.

## Anti-patterns
- Answering "who is it for?" with "everybody."
- Competing on the product alone ("look, a hammer!", a discount, a comfy grip) against every other hammer.
- Assuming you are the avatar.
- Stopping at a demographic sheet without the diary.
- Letting AI fill the whole profile without prefilling and checking it yourself.

## Worked Example
**John Smith**, about 35, an engineer, married with 2 kids, owns a home. He loves family time, but his eating and exercise habits have slipped and he now struggles to keep up with his kids. For a picture-hanging offer aimed at a father like John, the angle is: quick, efficient, no problems, the kids are amazed, his wife smiles, and friends ask who he hired. The same message would fail with a single man in his 20s. If John's reading is all about delegating and outsourcing, sell him a fast picture-hanging service or a course on hiring the right handyman instead of the hammer.

## AI Training
Two prompts. Prefill everything you know first and verify the output.
1. **Avatar Profile prompt:** input the offer, market, offer type, niche, and benefit. It asks for one problem-aware avatar (using *Breakthrough Advertising* awareness stages) with:
   - Name, gender, job, salary
   - 3 favorite movies, books, and websites
   - 4 personality traits, values, and interests
   - Big Secret Fear, Big Complaint about existing solutions, 4 pain points, Secret Desire, Lifestyle Desire
   - Top 5 desires, emotions, and beliefs
   - 3 decision triggers, purchase frequency, prior purchases, AOV
   - Want to gain / be / do / avoid
   - Seeing / Thinking / Hearing / Feeling / Saying / Doing

   Minimum 800 words.
2. **Avatar Diary prompt:** "imagine you are the avatar" and write a diary entry of at least 900 words in passionate, visceral, emotional language covering their deepest fears and desires.

## Key Takeaways
- Start with the problem and outcome, not the product.
- Layer demographics, influences, lifestyle, values, daily focus, hobbies, friends, and barriers.
- Barriers belong in the offer design. Remove the obstacles that make people wait.
- Match testimonials and wording to the avatar's peer group.
- Write the diary for every product, offer, or niche. It is the step that gives you clarity.

## Connects To
ch01 (Hungry Audience, market research), ch02 (No-Brainer Offer: remove barriers, add bonuses), ch03 (Stages of Awareness), ch04–ch07 (callouts and objection language), ch11 (split tests confirm the avatar's Need and Super Seven), bonus3 (headline pre-heads call out the avatar).
