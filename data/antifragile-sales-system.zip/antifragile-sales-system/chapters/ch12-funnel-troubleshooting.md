# Chapter 12: Funnel Troubleshooting

## Core Idea
Your funnel won't work at first. The author says 90% of success comes from troubleshooting after launch: find the weak KPI, map it to the psychological phase it measures, fix the copy, and keep going until the funnel is ready to scale. Split the funnel into four parts (TOFU, SOFU, MOFU, BOFU), diagnose each with its ch10 KPI group, and judge results by the Law of Averages and Statistical Significance, never by elapsed time or dollars spent.

## Frameworks Introduced

### Anatomy of a Marketing Funnel: TOFU / SOFU / MOFU / BOFU
| Part | Contents | KPI group (ch10) | Psychological job |
|---|---|---|---|
| **TOFU** (Top) | Anything that engages prospects without asking for money: blogs, videos, lead pages, webinar registration, VSLs, sales pages, quizzes | Traffic + Lead | Attention → Interest |
| **SOFU** (Side, the author's term) | Followup to *prospects*: Trust-Building, Flash Sale, and other presale sequences | Followup | Interest → Desire + Trust |
| **MOFU** (Middle) | Invitations to buy: checkout, paid registration, card-required trials, abandoned cart, some retargeting | Sales | Desire → Action |
| **BOFU** (Bottom) | Customer content: upsells, onboarding, repeat-purchase, reviews, referrals | Customer | Trust → Loyalty → Love |

SOFU exists because many leads detour before buying. Its job is to lead them back to MOFU. A business that depends only on first-24–72-hour sales is fragile.

### Psychology of a Marketing Funnel (4 decision phases)
- **Attention:** join the conversation in their head.
- **Interest:** high-value curiosity + breadcrumbing.
- **Desire:** emotional contrast (problem vs promise).
- **Action:** urgency + objections + emotional contrast.

**Breadcrumbing** is the glue between the phases. A weak KPI tells you which phase handoff is broken.

### TOFU diagnostic sequence
1. Low Attention KPIs: fix **Relevance** first. Then suspect the offer or audience (revisit ch01–03). Suspect the channel (ch09) last. Unusually high attention can mean **Pick-Up Line Marketing**, where content is clever or shocking but disconnected from what the prospect is thinking.
2. Low Interest KPIs: check for low-quality attention or missing **High-Value Curiosity**. Then check the 4 walls: "Who is this for? Why should I care? What do I get? How do I get it?" A specific CTA alone often produces big lifts. Then check breadcrumbing (99% likely to be the cause).
3. Low Lead KPIs: suspect low-value curiosity or weak breadcrumbing, or a **"left-hand turn in Downtown Boston"**, meaning the Who/Why/What/How or wording doesn't match between the ad and the next page. Also run speed and usability tests on all devices and browsers.
4. Once TOFU is healthy, stop polishing it. Give 90% of attention to SOFU and 10% to Scientific Split Testing on TOFU.

### MOFU: 3 levers and 4 micro KPIs
Levers: (1) Reasons to Believe (Trust, via rapport and positioning), (2) Answer Remaining Objections (ch07), (3) Turn Up Desire to Believe (urgency).

Micro KPIs for webinar, VSL, or sales page:
1. **Retention Rate:** a low early rate means "Who/Why" is missing. A low late rate means an unclear "What" or weak desire and breadcrumbing. On trip-wire and retargeting pages, show the "What" above the fold. Don't do this in webinars or VSLs, because revealing it early inflates checkout visits and lowers checkout completion.
2. **Stick Rate:** add breadcrumbing at the biggest drop-off points. Remove **speed bumps**, meaning sections that are Confusing, Unbelievable, Boring, or Awkward.
3. **Checkout Visit Rate:** problems here point to positioning, objections, or an unclear "How." Add an accordion FAQ and heat-map it to see which objections go unanswered. Uncover hidden objections by split testing, not by asking.
4. **Checkout Rate:** a low rate means buyers reached checkout too early (before the stack, objections, or positioning as Relevant, Superior, Unique) or the post-CTA urgency was weak. Don't rush people to checkout.

### BOFU: turning loyalty into love, 7 techniques (from the planned book *Copywriting for Aspiring Cult Leaders*)
1. Become the Voice in Their Head
2. Forgive and Reframe Their Past
3. Throw Rocks at Their Enemies
4. Give Them a New Family
5. Give Them a New Identity
6. Give Them a New Mission
7. Appeal to Their Need for Purpose

Deliver these through a **Brand Lexicon**, a private language of words, catch phrases, metaphors, frameworks, and stories. Trust becomes loyalty only if you deliver on promises and exceed expectations. By the 80/20 rule, about 20% of customers produce about 80% of BOFU profit and referrals.

### Law of Averages and Statistical Significance
- **Law of Averages:** about 10% of people reach each next step. For example, 10,000 ad views → 1,000 page visits → 100 checkout visits → 10 buyers. Use it as the fallback benchmark for minimum viability.
- **Statistical Significance:** judge KPIs on unique visits or results, not days or dollars. "2 sales this week" and "$500 spent, $99 made" are the wrong frame.
- **Why it works:** it stops premature kills and false wins. **Failure mode:** calling 2 sales from 50 visits a 4% conversion rate, or calling 0 sales from 50 visits a failure.

## Key Concepts
- **SOFU:** the author's term for the prospect followup loop that feeds MOFU.
- **Pick-Up Line Marketing:** flashy attention that doesn't turn into interest.
- **Left-hand turn in Downtown Boston:** a message mismatch between funnel steps.
- **Speed bumps:** confusing, unbelievable, boring, or awkward copy segments.
- **Micro KPIs:** Retention, Stick, Checkout Visit, and Checkout Rates.
- **Chemical Orgasm:** the dopamine from curiosity and breadcrumbing combined with the serotonin, oxytocin, and norepinephrine that desire adds.
- **Brand Lexicon:** the private language that turns loyalty into love.
- **Phony objections:** "let me think about it" or "costs too much." They are smoke screens for hidden internal objections.

## Mental Models
- Each underperforming KPI marks a missing piece of psychology. Map the KPI to its phase, then fix that technique.
- Check causes in this order: messaging, then offer or audience, then channel.
- Troubleshooting is a process, not an event. Attachment to results clouds judgment.
- Shiny objects lead to dull outcomes. Troubleshoot one offer and one funnel until it works.

## Anti-patterns
- Expecting profit the day traffic starts, or quitting before reaching significance.
- Blaming the channel first.
- Over-optimizing TOFU when the payoff is further down the funnel.
- Mismatched Who/Why/What/How between ad and page.
- Rushing prospects to checkout, which produces commodity buyers, refunds, and non-use.
- Salespeople afraid to close or to ask for enough upfront money. Objections that surface only at the end of the call.
- Relying on self-reported objections.

## Metrics & Thresholds
| Part | Metric (phase) | Benchmark |
|---|---|---|
| TOFU | Impression→Engagement (Attention) | Paid **2–5%**, earned **≥10%**, owned email/SMS **15–50%** |
| TOFU | Engagement→Click-Through (Interest) | Paid **~50%**, earned **≥10%**, email **1–5%**, SMS **~50%** |
| TOFU | Lead Capture Rate (Breadcrumbing) | **15–60%** paid and earned. Under 10% is acceptable if CPL is fine and BOFU compensates |
| SOFU | Lead Conversion Rate (Desire + Trust) | **10–30%** paid leads, **40–60%** referral leads |
| SOFU | Email open / click-through | **15–50% / 1–5%**. Opens come from Relevance + High-Value Curiosity. Clicks depend on Why/What/How |
| MOFU | Early Retention | Webinar **80–90% at 10 min**. VSL **60–80% after 1st minute**. Sales page **80–90% below the fold** |
| MOFU | Late Retention | Webinar **50–60% after offer intro**. VSL **60–80% after offer**. Sales page **30–50% reach stack/CTA** |
| MOFU | Checkout Visit Rate | Sales page **≥10%**, webinar **≥20–30%** |
| MOFU | Checkout (Completion) Rate | **10–20%** |
| MOFU | Call Booking Rate (Desire + Breadcrumbing) | Post-lead-capture **≥10%**, post-purchase **40–80%** |
| MOFU | Avg Cost Per Pitch | Seen from **$50 to $500**. Matters less than whether closing KPIs cover it |
| MOFU | Call Show Rate (Breadcrumbing + Trust) | Driven by the confirmation video and reminder sequence |
| MOFU | Pitch Close Rate (Objections + Desire) | **10–20% paid**. The author's framework reaches up to **30% paid, 80% referrals** |
| BOFU | Revenue/Customer, Review Rate (Loyalty). Rating, Referral Rate, Referral Conversion, Revenue/Referral (Love) | Use the ch10 targets |
| All | Law of Averages | **~10% per step** |
| All | Statistical Significance | **150–200 results** for new funnels, steps, sources, or audiences. **Several hundred to 1,000** for mature or heavily tested assets |

## Worked Example
A VSL funnel gets 1,000 unique visits and 10 sales in one week. The author treats 2 sales from 100 visits as a good start and 10 from 1,000 as underperforming. (Strict 10%×10% math gives 1%, so read 1% as a floor, not a target.) The sample size is significant, so troubleshoot:
1. Early VSL retention is 45% after 1 minute, below 60–80%. Fix "Who is this for / Why should I care" and make the hook match the ad (no Downtown Boston turn).
2. Late retention is fine, and checkout visits run 25% of viewers, but checkout completion is 4%, below 10–20%. The buy button appears before the offer stack and objection handling. Move the CTA after the stack, add post-CTA urgency, add an accordion FAQ, and heat-map it.
3. Split test the top FAQ-revealed objections (ch11) and declare a winner only after 150–200 results.

The BOFU fix uses the 7 techniques. The fitness-niche email example: we both hate cardio (1). It isn't your fault, the Instagram influencers misled you (2, 3). You and me (4), one of the 1% of men over 45 (5), on a mission to prove 45 is prime (6), invited as 1 of 10 elite men to build a legacy (7).

## AI Training
Online (chapter-12). It has you feed in your KPIs and locate the weak phase and the copy fix.

## Key Takeaways
- Map every KPI to its phase: Attention, Interest, Desire, Trust, Action, Loyalty, or Love.
- Diagnose in order: messaging, then offer or audience, then channel.
- Keep Who/Why/What/How consistent across every step of the funnel.
- Use micro KPIs (Retention, Stick, Checkout Visit, Checkout) to find MOFU leaks.
- Get ahead of objections with confirmation videos, reminders, and early handling on the call.
- Judge by unique visits, the 10% Law of Averages, and 150–200+ results.
- The first sale earns a customer. Profit comes from SOFU and BOFU.

## Connects To
ch01–ch03 (audience, offer, funnel when TOFU fails), ch04–ch07 (stage copy fixes, objection formulas), ch08 (followup, upsell, reminder, loyalty sequences), ch09 (channel as the last suspect), ch10 (KPI definitions and goals), ch11 (split testing to uncover hidden objections), bonus3 (headlines for Attention).
