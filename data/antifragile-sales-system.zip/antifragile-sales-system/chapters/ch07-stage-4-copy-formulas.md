# Chapter VII: Stage #4 Copy Formulas

## Core Idea
Stage #4 (Negotiating) prospects are mostly sold on your OFFER but haven't bought, because at least one trust point (Convenience, Charisma, Competence, Character) is still unmet or they're procrastinating. A Retargeting Funnel closes them with a bold reminder ad, a "Here's Why" reopening, the Offer Stack, objection answers, and the CTA / Post CTA / Power PS closing sequence. That closing sequence is also used in the webinar, VSL and trip-wire funnels.

## Frameworks Introduced
**Stage #4 Objections and Rebuttals**: "What happens next?" → define their client journey. "What if it doesn't work?" → overcome their objections. "I can do this later." → make a limited time or supply offer. Plus make buying easy. A confusing CTA is a Convenience failure and makes retargeting expensive.

**Checkout benchmark**: if 10–20% of sales page visitors reach checkout, at least 10% of those should buy. If not, find the failing trust point and fix the offer, sales page and checkout page before you retarget.

**Retargeting Ad: Reminder → Offer → Action**: this is the trip-wire ad made shorter, bolder and more urgent. The Offer section reinforces the one trust type most likely to tip them (Competence via testimonial clips, or Character via the emotional transformation). ch11 split testing tells you which.

**"Here's Why" Story (Reopening)**: learned from Dan S Kennedy. It explains the reason for your Guarantee, your Price or your Urgency. Master this and you won't need other reopenings. (Recommended reading: Bill Glazer, *Outrageous Advertising That's Outrageously Successful*.)
- Why it works: it turns the suspicious part of the offer into the reason to trust it. Failure mode: an unconvincing reason reads as a gimmick.

**4-element Call to Action**: (1) the exact action, (2) exactly what happens next, (3) restated PROMISE and DEADLINE, (4) restated GUARANTEE and RISK REMOVAL. Any order works.

**Internal Pressure Post CTA**: uses cognitive dissonance, contrasting the emotional pain of the PROBLEM with the emotional benefit of the PROMISE. It outperforms external (deadline or scarcity) pressure and makes limited-time offers work better.

**4 Objection Types**: External (about your product type), Internal (whether it can work for *them*), Commitment (the time and action required is too much to ask, or too good to be true), Character (your motives). They are universal across niches.
- **Two sales to make**: first that it works, then that it will work for *them*. Most marketers only make the first.

**Retargeting Funnel Elements (7)**: Ad/Post, Reopening, Offer Stack, Objections, CTA, Post CTA, Power PS.

## Key Concepts
- **Ad retargeting vs followup retargeting**: paid ads to page or checkout visitors vs email, SMS or mail to captured leads (ch08).
- **Splinter in the mind**: a "Now that you know this, you'll…" embedded suggestion that makes the message recur later, even if they don't buy now.
- **Double tie-down subheader**: "Isn't It Time to Stop [PROBLEM], and Start [PROMISE]?"
- **Feel, Felt, Found**: the empathy structure for the Internal and Commitment objections.
- **Mini-rant**: a concrete description of the hassle or disappointment that shows empathy (Character).
- **Skeptical vs cynical prospect**: skeptics have real questions and are worth persuading. Cynics hunt for reasons to say no, so don't chase them.
- **"Too much to ask" prospects**: those who want instant gratification. They're often toxic clients, so filter them out with Qualification and the commitment formula.
- **Power PS**: a final urgency booster after the Post CTA (10 types, can be stacked as PS/PPS/PPPS + final CTA).

## Mental Models
- Stage #4 needs reassurance, not more education. Extra persuasion can turn them off.
- Be bold. Anyone scared off by strong retargeting copy wasn't going to buy anyway.
- A sales page that gets people to checkout on information converts better than one that sends them there on impulse. Don't put the buy button at the top just to boost checkout visits, because people click it only to see the price.
- Nailing the INTERNAL objection feels like mind-reading. It boosts perceived Competence and Character, and it's easier to do in copy than live.

## Anti-patterns
- **Optimizing the sales page only for checkout visits**: checkout conversion drops, refunds rise, and you get "dumb questions."
- **Retargeting before fixing the offer or checkout**: retargeting stays costly while the trust gap stays open.
- **Going easy in retargeting copy**: soft copy loses urgency.
- **Claiming *all* customers had the same fear** in a "felt" statement: this creates skepticism, so say "many."
- **Trying to persuade cynics**: they drain you and trash your reputation.
- **Relying on external pressure alone**: internal pressure (dissonance) does more.

## Copy Formulas
**Retargeting Ad**
- Reminder: a briefer, more urgent version of the trip-wire hook. Question w/Contrast ("Still want to get rid of [PROBLEM]?"), Future Pacing ("They're waiting…"), or If-Then turned into "Why keep [PROBLEM]?"
- Offer: short summary of [OFFER]+[PROMISE] + a bit of proof or story + guarantee, reinforcing either Competence ([#] customers + testimonial clips) or Character (the confidence regained, "it did the same for me").
- Action: "Here's what happens when you [ACTION] today:" bullets (what you get / how it's delivered / steps to the result) → CTA with "right now/hurry" → PS: you missed the last bonus, but here's another.

**Reopening: "Here's Why" Story (3 variants)**
- Reason for Guarantee: headline "Here's Why I'll [RISK REMOVAL] if You Don't [PROMISE]" → "By now you're probably [eager]…" → "But you might also be worrying [EXTERNAL OBJECTION]" → "Like you, I…" + a detailed story of a bad purchase (excitement, daydreams, then the stomach-turning moment and your physical reaction) → other disappointments → "I've shared several reasons…" [PROMISE recap] → if you fulfill the guarantee terms and feel like I did, I'll honor [RISK REMOVAL] → "If ___, here's…" → CTA.
- Reason for Price: headline "If This is So Good, Why The Low Price? / Why Is This Only [PRICE]?" → eager + "wondering about price" → "Like you, many customers felt the same…" → "After working with us, customers found…" [PROMISE by DEADLINE, without EXT, despite INT] → it's low because you're confident they'll buy the bigger product, or buy again and refer → guarantee if it felt too good to be true → transition.
- Reason for Urgency: headline "Why Can't I Get This After [DEADLINE]? / Why Only [SUPPLY]?" → eager + hesitation → "Like you, I…" → the reason, from 7 options: Service Quality, Exclusive Advantage, Collector's Appeal, Price Increase, PreOrdering, Coming Upgrade, FOMO Factor (ground-floor opportunities) → how that reason ensures [PROMISE] → recap → guarantee → transition.

**Call to Action (10 example styles)**: Lead With Benefit; Lead With Action; Surprise Premium; Last Minute Urgency; Free Trial; Jealousy Factor (someone else takes the spot); "If You're [PROMISE], [ACTION]"; Problem vs Promise ("Why pay/struggle with [PROBLEM]? Within [DEADLINE] you could [PROMISE]"); Nothing to Lose; Promise vs Problem. Each includes all 4 CTA elements.

**Post CTA (Internal Pressure)**
1. Double tie-down subheader: "Isn't It Time to Stop [PROBLEM] and Start [PROMISE]?" / "…Start [PROMISE] and Stop [PROBLEM]?" / "Haven't You Waited Long Enough for [PROMISE]?" / "Haven't You Suffered from [PROBLEM] Long Enough?"
2. "You want [PROMISE]. By now you know there are only two choices left:" 1) [PROBLEM + pain] 2) [PROMISE + benefits].
3. "Forget all the… / No more wasting time with…" [MYTHS/MISTAKES/ALTERNATIVES used earlier] → none of it matters without [USP advantage] → take 3 shots at their ongoing negative impact.
4. The cost they've already paid + "you're running out of [time/money/opportunity]…" (the CRISIS is coming).
5. Confirming question: "Want to [PROMISE] without [EXT] despite [INT]?"
6. Direct command to [ACTION] tied to [PROMISE]+[DEADLINE] + the cost of doing nothing, DIY or ALTERNATIVES.
7. "The moment you [ACTION]…" + future pacing to the PROMISE within the DEADLINE.
8. "Other [SOLUTION] will claim [X], but how many will [your GUARANTEE]?" + a bold claim they can't match.
9. Splinter: "Now that you know this, you'll…" + "You'll think about this every time you [PROBLEM moment]…" + "It's time to stop [PROBLEM] and [PROMISE] so you can [benefit]."

**Power PS (10 types)**: Point of No Return, Regret, Responsibility, Jealousy, Gain vs Lose, Nothing to Lose, Ego Jab, Coming Crisis, Future Pacing, Reverse Psychology. Stack three (PS/PPS/PPPS) and then a final short CTA.

**Objection Formulas**. Placement: in webinar, VSL and trip-wire funnels, put them after the price reveal and CTA (or in the FAQ). In retargeting, put the top objection before the Offer Stack and the rest after the first CTA.
- External: subhead in the prospect's words ("What About [EXT]? / Will I Have to [EXT]? / I Don't Want [EXT]") → assume the sale: "Before you [ACTION], we want you 100% confident about [relevant feature]" → we understand the hassle + a mini-rant on its cost → "If [EXT], then [that's why you hesitated]" → we've been in your shoes → "That's why we've…" [removed the hassle] → "So before we welcome you as our new customer, just know…" + a metaphor → guarantee → "If ___, then ___" to the Offer Stack or CTA.
- Internal: subhead ("What if I [INT]? / Does This Work if [INT]? / This Sounds Great, But [INT] / I Don't Want to [INT] Again") → "If you're still reading, it means [hope]" → "But you might be secretly thinking [INT]" → Feel (mini-rant) → "Sound familiar? You're not alone" → Felt (many customers, with underdog stories) → Found (the INT became an advantage or was nullified by a feature, ideally your USP) → "That's why we've…" guarantee → transition.
- Commitment: answer both sides, most common first (usually too good to be true). *Too good to be true*: subhead "Can I Really [PROMISE] in [DEADLINE]?" → If-Then affirming the skepticism → Feel (horror stories) → If-Then "it's normal" → Felt (underdogs) → Found (a feature makes it possible) → guarantee. *Too much to ask*: subhead "Can it Happen Faster Than [DEADLINE]?" → If-Then disqualifying unreasonable expectations → the MYTH behind it, debunked with the ch04 Myth-Busting formula + its pain → a "fork in the road" contrast → transition.
- Character: subhead "Aren't You Just Trying to Make Money? / If You Really Want to Help, Why Isn't This Free?" → If-Then "that's why you're still reading" → "It won't…/I won't…" (my life goes on either way) → flip: "It will…" (broad physical, financial, social and emotional life changes for them) → "I've offered…" [guarantee] → "I've shown…" [superiority, relevance, uniqueness] → the success-story people will keep winning whether or not you buy. The author credits the formula's origin to Dan Kennedy or older direct response, not to Brunson.

## Worked Example
A Post CTA for a cold-traffic program. The subhead asks whether it's time to break their income plateau. They want seven figures, and there are two choices left: keep burning out hoping to go viral, or learn to convert cold traffic. Forget the theories about delegation and systems, because none of it matters without inbound traffic. Then three shots at the alternatives: the warm network runs out, cold calling and emailing have limits, and SEO doesn't scale. Next the cost: you're running out of warm contacts. The confirming question asks if they want to get unstuck. The command is to join and learn cold-traffic conversion, then future pacing: once you crack it, buying traffic becomes an investment. Last comes the splinter: "Now that you know this, you'll remember it every time you're struggling to find new business." That reminder drives follow-up re-engagement.

## AI Training
The chapter-end link (theantifragilesalessystem.com/chapter-7) points to AI-assisted help writing retargeting ads, "Here's Why" reopenings, CTAs, Post CTA messages, Power PS lines and objection answers.

## Key Takeaways
1. Fix the offer, sales page and checkout (aim for 10%+ checkout conversion) before paying to retarget.
2. Retargeting copy is short, bold and urgent, and reinforces the single trust type that's missing.
3. Reopen with a "Here's Why" story that justifies your Guarantee, Price or Urgency.
4. Every CTA states the action, what happens next, the PROMISE+DEADLINE and the guarantee.
5. Internal pressure (a two-choices dissonance plus a splinter) beats external scarcity. Finish with stacked Power PS lines.
6. Pre-empt all four objection types in the copy. Filter out "too much to ask" and cynical prospects instead of persuading them.

## Connects To
ch03 (retargeting funnel, trust types), ch04 (Myth-Busting formula for commitment objections), ch05 (VSL funnels end with these elements), ch06 (Offer Stack, Qualification, External vs Internal Pressure, guarantee), ch08 (followup retargeting, abandoned cart, splinter re-engagement), ch11 (which trust type to reinforce, objection order, human needs), ch12 (FAQ and troubleshooting, BOFU conversion).
