# Cheatsheet — Decide Like Czerepak

## Which funnel, which message? (by Buyer's Journey stage)
| Stage | Prospect knows | Funnel | Message job | Their objection |
|---|---|---|---|---|
| #1 Indifferent | Doesn't feel the problem | Webinar ("Workshop" or "Masterclass") | Make the problem feel relevant → critical → urgent | "I don't have it / it isn't serious / I can wait" |
| #2 Curious | Knows the problem, exploring fixes | VSL or Quiz | Expose the hidden risks of the alternatives, sell the category | "The DIY or current fix is fine" |
| #3 Comparing | Shopping your solution type | Trip-Wire | Position the brand: X Factor, Superiority, Relevance, Uniqueness | "Why you?" |
| #4 Negotiating | Chose you, hasn't paid | Retargeting / cart save | Reassure on last-minute objections, add urgency | Too good to be true, too much to ask |
| #5 Committed | A customer | Loyalty sequences | Upsell → review → referral | — |
Stages #3 and #4 are put off by education, so stop teaching and start positioning. Selling "buy now" or "we're better" to Stage #2 gets dismissed as junk.

## Benchmarks
| Metric | Target |
|---|---|
| Ad CTR / click to next step | 1–5% paid ad CTR; 10–20% to the next step |
| Lead capture / opt-in | 15–60% (plan on 20–50%); CPL $25–50 |
| Lead cycle / lead→customer | ≤30 days; 20–50% within 30 days |
| Cold-traffic sale | 1–3%; front-end value should be 75–100% of acquisition cost |
| Offer conversion | 10–20% B2C, 1–5% B2B; add-ons and upsells 10–20% each |
| Followup lift | +20–50% more sales |
| Email | 15–50% open, 1–5% click |
| Sales page / webinar retention | 80–90% early; 30–60% late |
| Checkout visit → completion | ≥10% (page) or 20–30% (webinar) visit; 10–20% complete |
| Calls | 20–30% book, 50–60% show (plan for 40–50% no-shows), 10–30% close; ~$250 per pitch |
| Customer value | $500 at 90 days, $2,000 at year one, $5,000 lifetime |
| Reviews / referrals | 20–40% review, ≥4.5 stars; 10–20% refer, 50–70% referral close |
| Upsell | Price 4–5× the front end; expect 10–20% take rate |
| Direct mail vs email | 5–9% vs ~1% response |
| Statistical floor | 150–200 results per variant; ~10% of people per step (Law of Averages) as the minimum bar |

## Decision rules
- **When a problem is hungry but its buyers are poor, still choose it over a wealthy but indifferent audience**, because commitment to solving the problem beats buying power (ch01).
- **Trust only spending**, never surveys or forums, to validate demand (ch01).
- **Fix the offer before the copy**, because a strong offer sells with average copy. At Stage #3, the offer outweighs the copy (ch02, ch06).
- **Plan to break even or lose money on the first sale.** Profit comes from followup and BOFU. Cap the loss using customer value (ch02, ch03).
- **Don't quit ads after 1–2 weeks.** Find the weak link, because marketing is a process, not an event (ch03).
- **Follow the Law of One** in every message: one problem, emotion, solution, benefit and call to action (ch05).
- **No buy button at the top of a long page**, because people click it to see the price and checkout conversion drops (ch07).
- **Above ~$2K, sell a booked call.** Cancel people who break the call rules (ch08).
- **Never pay or incentivize people for reviews** (FTC risk). Only send referral requests to positive reviewers (ch08).
- **Test hypotheses, not random changes.** Test one element at a time, then move from the headline to the opening, price, guarantee and CTA (ch11).
- **Don't judge by elapsed time or money spent.** Wait for 150–200+ results (ch12).
- **Diagnose in order: messaging → offer/audience → channel** (ch12).
- **Aim for 80–100% evergreen traffic effort** (not 90–100% chasing new traffic). Keep a 6–12 month reserve before reinvesting (ch09).
- **Use the market type to pick the Stage #2 angle**: B2C → story, B2B → secret, information-saturated → mistake, product-saturated → alternative (ch05).
- **Match the price-reveal transition to the buyer's need**: Validation or Purpose → private invitation; Excitement → special price; Security → "at no risk" (ch06).

## Tells & smells
- Engagement is high but nobody buys → an offer or targeting problem, not a copy problem (ch06).
- Drop-off right after positioning, or price objections → one positioning element is weak (ch06).
- Drop-off right when the offer appears on a warm list → they still doubt the solution category, so add a Solution Pitch (ch05).
- A clever hook with a weak click-through → Pick-Up Line Marketing (ch01, ch12).
- Who/Why/What/How changes between funnel steps → a "left-hand turn in Downtown Boston" that loses people (ch12).
- Results crash after a public-trust shock → you were running on convenience trust; rebuild on competence and character (ch00).
- Price shoppers flooding an intro offer → add an application gate and qualifying messages (ch02).
