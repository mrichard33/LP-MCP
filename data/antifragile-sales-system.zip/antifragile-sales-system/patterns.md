# Patterns & Techniques — The Antifragile Sales System

## Problem → Impact → Benefit Flip
**When to use**: Starting a business or rescuing a stalled offer.
**How**: List 3–5 problems that are big, painful, pervasive and persistent. List every negative impact of each. Flip each impact into a benefit. Write copy with no mention of the product. Then run simple problem-focused ads and profile whoever **buys**. (ch01)
**Trade-offs**: Plain copy gets less attention than clever hooks, and you pay ad money up front instead of time on research.

## No-Brainer Offer Build
**When to use**: A front-end offer for cold paid traffic.
**How**:
- A clear promise.
- Risk removal for both money and time.
- Fast delivery and overdelivery.
- Branding.
- A second offer built into the delivery.

Add an application gate if price shoppers show up. Size the acceptable first-sale loss with customer value (monthly profit × lifespan). (ch02)
**Trade-offs**: The first sale may lose money, so you must recover it through followup.

## Stage → Funnel Match (Angle Selling)
**When to use**: Choosing a funnel for cold traffic.
**How**: Diagnose the prospect's stage, then pick the funnel. #1 Indifferent → Webinar. #2 Curious → VSL or Quiz. #3 Comparing → Trip-Wire. #4 Negotiating → Retargeting. #5 → Customer followup. If you're unsure, run Stage 1, 2 and 3 ads to a lead page (the Awareness Probe) and build the funnel the winner points to. (ch03, ch11)
**Trade-offs**: A wrong diagnosis sinks the whole funnel, and the earlier stages need longer funnels.

## Copywriting Kitchen
**When to use**: Before writing any copy.
**How**: Define the 12 variables once (AUDIENCE, PROBLEM, PROMISE, SOLUTION, ALTERNATIVE, EXTERNAL and INTERNAL OBJECTION, and so on), then fill every formula from them. (ch03)
**Trade-offs**: Slow to set up, fast from then on.

## Four-Section Ad (Attention / Curiosity / Objections / Action)
**When to use**: Stage #1 webinar ads.
**How**: Open with a symptom triad and a crisis. Add 4 "learn" bullets built on High-Value Curiosity. State what the event is NOT about and what it reveals. Finish with a call to action and a scarcity PS. Call it a "Workshop" or "Masterclass", never a "webinar". (ch04)
**Trade-offs**: The copy runs long, so split-test shorter versions.

## Market-Type Indoctrination
**When to use**: A Stage #2 VSL.
**How**: Pick the angle from the market type: B2C → story, B2B → secret, information-saturated → mistake, product-saturated → alternative. Use the same angle in the ad, squeeze page, opening and indoctrination. Use open loops ("And that's not all…"). End with a Solution Pitch that exposes the X Factor. (ch05)
**Trade-offs**: If you pick the wrong angle, it misfires everywhere it appears.

## Offer Stack with Objection Bonuses
**When to use**: Trip-Wire and sales pages.
**How**: Introduction → Value Stacking (one bonus with a dollar value for each objection: Time, Money, Social, External, Internal) → Price Reveal matched to the buyer's dominant need → Two-guarantee Risk Removal → Urgency. Place Qualification or a Take Away before the offer. (ch06)
**Trade-offs**: Makes the offer more complex, and the take-away loses a few sales.

## Here's Why Reopening + Post-CTA Pressure
**When to use**: Retargeting pages for Stage #4.
**How**: Explain why the guarantee, price or urgency exists with a "Like you, I…" story. Give a 4-element call to action. Follow it with a double tie-down, two choices, the cost of doing nothing, a future pace and a "splinter" line. Handle objections with Feel-Felt-Found, and answer "too good to be true" before "too much". (ch07)
**Trade-offs**: A weak reason reads as a gimmick.

## Stage-Routed Followup
**When to use**: Every new lead.
**How**: Start the Trust-Building Sequence at the prospect's stage entry point, and skip people ahead based on behavior. Abandoned checkout goes to the cart sequence (opens drive the next message). After purchase, show the Upsell (priced at 4–5× the front end), then the call booking and Reminder sequence, then Review → Referral loyalty. (ch08)
**Trade-offs**: Needs an automation platform and tagging.

## Seed-and-Splinter Traffic Machine
**When to use**: Monthly content production.
**How**: Create one seed piece and split it into 20 subtopics. That becomes about 4 blog posts, 20 emails, 20 SMS, 20 posts per social channel and 1 mail piece, drawn from a Content Pantry. Use 2–3 channels each of Paid, Earned and Owned. (ch09)
**Trade-offs**: Only works with a stocked Content Pantry.

## Math / Strategy / Psychology Goal Block
**When to use**: Setting a goal at any of the five stages (Traffic, Lead, Followup, Sale, Customer).
**How**: Give each goal a numeric KPI, a strategy matched to the stage, and the named copy techniques you'll use. Forecast with spend ÷ cost KPI × conversion rate × value. Review hits and misses against the same techniques. (ch10)
**Trade-offs**: Needs consistent tracking.

## Hypothesis Tournament (Scientific Split Testing)
**When to use**: Any split test.
**How**: Test one element per round: a Human Need, one of the Super Seven, awareness stage, or objection. Run your top guess against your second guess, then run the winner against the next option. Carry the insight into all of your copy. Test objections only on Stage #4 audiences. (ch11)
**Trade-offs**: Slow, and it needs 150–200+ results per variant.

## KPI → Phase Diagnosis
**When to use**: A funnel is underperforming.
**How**: Match the weak KPI to a phase: Attention, Interest, Desire, Trust or Action. Fix in this order: messaging, then offer and audience, then channel. On sales pages, work through the MOFU micro-KPIs in order: Retention → Stick → Checkout Visit → Checkout. Check that Who/Why/What/How match from step to step. (ch12)
**Trade-offs**: Needs analytics and heat maps.

## Avatar + AI Workflow
**When to use**: Before building any offer, and for scaling copy production.
**How**: Build the profile in this order: problem → demographics → influences → lifestyle → values → daily grind → barriers. Then write the Avatar Diary. For AI, give numbered steps with an approval gate at each, move reused instructions into a linked document or a Custom GPT, and use Word Math sheets to generate variants. (bonus1, bonus2)
**Trade-offs**: AI output must be verified and edited by a human.

## Emotion × Awareness Headline
**When to use**: Any headline.
**How**: Identify the awareness level. Pick the dominant grief emotion for that level. Write the headline in three layers: Pre-Head (call out the reader), Main Hook (one promise), Sub-Head (secondary benefits). (bonus3)
**Trade-offs**: Misreading the emotion can alienate the reader.
