---
name: antifragile-sales-system
description: "Book reference only: \"The Antifragile Sales System\" by Seth Czerepak. Use when someone asks what the book says, wants the full formula templates, benchmarks, or chapter detail, or when antifragile-copywriter needs deeper formula detail. Do NOT use to write Reece Windows & Doors copy; use antifragile-copywriter for all copy, SMS, email, ad and funnel content."
---

<!-- argument-hint: [topic, framework name, or chapter id like ch06] -->

# The Antifragile Sales System
*How to Build an Evergreen, Inbound Sales Machine That Makes Big, Consistent Profits on Autopilot*
**Author**: Seth "The Red Neo" Czerepak (2024) | **Words**: ~153K | **Chapters**: 12 + intro + 3 guest bonus chapters | **Generated**: 2026-09-18

## How to Use This Skill
> For Reece copy, use **antifragile-copywriter**; this skill is its formula library.

- **No arguments**: use the core frameworks below.
- **A topic** (e.g. `offer stack`, `abandoned cart`, `split test`): find it in the Topic Index and read that chapter file before answering.
- **A chapter** (e.g. `ch06`): load `chapters/ch06-*.md`.
- **Formula lookups**: load the chapter for the prospect's stage (ch04–ch07) or ch08 for followup to get the [PLACEHOLDER] templates. Don't write final copy here; hand the formula to antifragile-copywriter.
- **Diagnosis, benchmarks or which funnel to use**: read [cheatsheet.md](cheatsheet.md).

---

## Core Frameworks & Mental Models

**1. Mistrust is the root problem; the Four Ways to Earn Trust (ch00).** Every message builds trust through Convenience, Charisma, Competence or Character.
- Convenience trust (price, speed) is the fastest to win and the first to collapse. It rises and falls with the "Public Trust Barometer".
- An **antifragile** business earns competence and character trust, so it gets stronger in a crisis. When a competitor appears, don't cut prices.
- **Dog Whistle Language**: segment the audience and use each group's own identity words.

**2. Hungry Audience (ch01).** Ask: who's hungry, and what are they hungry for?
- Hunger (commitment to solving the problem) beats wealth.
- List 3–5 big, painful, pervasive, persistent problems. Map each **PRIMARY PROBLEM → NEGATIVE IMPACT → BENEFITS**.
- People spend on a problem when it feels **Relevant, Critical and Urgent**.
- Validate demand only by who **spends**, not by surveys.
- Avoid Pick-Up Line Marketing: clever hooks that build no trust.

**3. No-Brainer Offer (ch02).** A low-cost, risk-free first offer.
- Parts: promise, money-and-time risk removal, fast delivery, overdelivery, branding, and a second offer built into the delivery.
- Types: physical product, introductory service, information product.
- Plan to break even or lose money on the first sale. Cap the loss at customer value (monthly profit × lifespan).
- Filter out Penny Pinchers with applications.
- Fix the offer before the copy.

**4. Antifragile Funnel = Angle Selling across the Five Stage Buyer's Journey (ch03).** The stage is set by what the prospect knows about the PROBLEM, ALTERNATIVE, TYPE and BRAND.

| Stage | Funnel |
|---|---|
| #1 Indifferent | Webinar |
| #2 Curious | VSL or Quiz |
| #3 Comparing | Trip-Wire |
| #4 Negotiating | Retargeting |
| #5 Committed | Customer followup |

- Each step asks for one micro-commitment. Profit shows up at BOFU (followup). Reinvest it in ads.
- Before writing anything, set up the **Copywriting Kitchen**: 12 variables (AUDIENCE, PROBLEM, PROMISE, SOLUTION, ALTERNATIVE, EXTERNAL and INTERNAL OBJECTION, …).

**5. Stage #1 copy (ch04).**
- **Four-Section Ad**: Attention (symptom triad + crisis) → Curiosity (High-Value Curiosity + breadcrumbing) → Objections (what it's NOT about) → Action.
- Answer the Stage #1 objections in order: relevant, critical, urgent.
- Webinar openings: Story, Hypnotic, or Pain vs Promise. Each ends with "you'll [PROMISE] without [EXTERNAL], even if [INTERNAL]".
- Stories: Hero's Journey (default), Conspiracy (saturated or suspicious markets), Tragic Teacher (authority).
- Add myth-busting. Call it a "Workshop", not a "webinar".

**6. Stage #2 copy (ch05).**
- The market type sets the angle: B2C → story, B2B → secret, information-saturated → mistake, product-saturated → alternative.
- **Law of One**: one problem, emotion, solution, benefit and CTA per message.
- **Indoctrination** reveals secrets, exposes mistakes or debunks alternatives, citing credible sources and surrogate endorsements.
- The 9-element **Solution Pitch** sells the solution category and ends with the **X Factor**, a flaw in the category that your brand fixes.

**7. Stage #3 copy (ch06).**
- **Bold Promise Opening**: PROMISE + DEADLINE + EXT/INT OBJECTION + CONDITIONS + RISK REMOVAL.
- **Offer Positioning**: X Factor, Superiority, Relevance, Uniqueness (USP: specific, beneficial, legally unique), Qualification/Take Away.
- **Offer Stack**: Introduction → Value Stacking (one priced bonus per objection) → Price Reveal matched to the dominant need → two guarantees → Urgency. Goal: Perceived Value > Perceived Cost.

**8. Stage #4 copy (ch07).**
- **Here's Why Story**: justify the guarantee, price or urgency.
- 4-element CTA, then the **Internal Pressure** post-CTA: double tie-down, two choices, cost of inaction, "splinter in the mind".
- **Power PS** (10 types).
- Objections come in four types: External, Internal, Commitment, Character. Handle them with Feel-Felt-Found.
- Answer "too good to be true" before "too much to ask".
- Don't put the buy button at the top of a long page.

**9. Followup (ch08).** Stage-routed sequences:
- **Trust-Building**: Welcome → Problem → Promise → Indoctrination → Solution → Positioning → Offer Stack → Downsell. Skip people ahead based on behavior.
- **Flash Sale**.
- **Abandoned Cart**: Remind → Sweeten → Warning → Downsell. Triggered by opens; needs a two-step checkout.
- **Upsell**: enhance the offer, next-level problem, or next-level promise. Price at 4–5× the front end; expect 10–20% to take it.
- **Call Booking + Reminder**: sell a call above ~$2K, enforce call rules, expect 40–50% no-shows.
- **Loyalty**: the Customer Ladder (Buyers → Loyalists → Promoters → Referrers, plus Winbacks). Ask for a review before a referral; never pay for reviews.

**10. Evergreen Traffic (ch09).**
- **Antifragile Traffic Triad**: Paid, Earned and Owned channels, chosen by Equity, Relevance and Credibility. Use 2–3 of each.
- Build **Traffic Equity**, not traffic income. One monthly **Seed Content** piece gets **splintered** into ~20 subtopics across every channel.
- Direct mail gets 5–9% response vs about 1% for email.

**11. Measurable Goals (ch10).**
- Each of the five stages (Traffic, Lead, Followup, Sale, Customer) gets a Math/Strategy/Psychology goal.
- Forecast KPIs with spend ÷ cost KPI × conversion rate × value.
- **Lead Scoring** triggers flash sales and calls. The front end only has to earn the customer; back-end value is the target ($5K lifetime).

**12. Scientific Split-Testing (ch11).**
- Test hypotheses on one element at a time: Human Needs (Validation, Excitement, Security, Purpose), **Seth's Super Seven** (Fast, Easy, Powerful, Safe, Durable, Enjoyable, Stylish), awareness stage, or primary objection.
- The winner becomes the control. Roll the insight into all copy.

**13. Funnel Troubleshooting (ch12).**
- Look at the funnel in four parts: TOFU (engagement), SOFU (followup), MOFU (buy invitations), BOFU (customers).
- Map a weak KPI to a phase: Attention, Interest, Desire, Trust or Action. Fix messaging first, then offer/audience, then channel.
- On sales pages and webinars, walk the MOFU micro-KPIs: Retention → Stick → Checkout Visit → Checkout.
- Wait for 150–200+ results before judging. The Law of Averages (~10% per step) is the minimum bar.

**14. Guest bonuses.**
- **Avatar + Avatar Diary** (Vignola).
- **AI automation** (Lawrence): numbered steps with approval gates, Instruction Linking, Custom GPTs, Word Math sheets.
- **Antifragile Headlines** (West): Pre-Head / Main Hook / Sub-Head, matched to awareness level × grief emotion.

---

## Chapter Index
| id | Title | Key frameworks |
|---|---|---|
| [ch00](chapters/ch00-introduction.md) | Foreword & Introduction | Four Ways to Earn Trust, Antifragile, Dog Whistle Language |
| [ch01](chapters/ch01-hungry-audience.md) | A Hungry Audience | Problem→Impact→Benefits, Relevant/Critical/Urgent |
| [ch02](chapters/ch02-no-brainer-offer.md) | A No-Brainer Offer | 5 components, risk removal, customer value math |
| [ch03](chapters/ch03-antifragile-funnel.md) | An Antifragile Funnel | Angle Selling, 5-Stage Buyer's Journey, Copywriting Kitchen |
| [ch04](chapters/ch04-stage-1-copy-formulas.md) | Stage #1 Copy Formulas | Webinar ad, registration, openings, stories, myth-busting |
| [ch05](chapters/ch05-stage-2-copy-formulas.md) | Stage #2 Copy Formulas | Market types, Law of One, indoctrination, Solution Pitch |
| [ch06](chapters/ch06-stage-3-copy-formulas.md) | Stage #3 Copy Formulas | Bold Promise, Offer Positioning, Offer Stack, price reveals |
| [ch07](chapters/ch07-stage-4-copy-formulas.md) | Stage #4 Copy Formulas | Here's Why, CTA, Post CTA, Power PS, objections |
| [ch08](chapters/ch08-followup-formulas.md) | Followup Formulas | Trust-Building, Flash Sale, Cart, Upsell, Call, Loyalty sequences |
| [ch09](chapters/ch09-evergreen-traffic.md) | Evergreen Traffic | Traffic Triad, Seed & Splinter |
| [ch10](chapters/ch10-measurable-goals.md) | Measurable Goals | 5-stage KPIs, forecasting, lead scoring |
| [ch11](chapters/ch11-scientific-split-testing.md) | Scientific Split-Testing | Human Needs, Super Seven, awareness probe |
| [ch12](chapters/ch12-funnel-troubleshooting.md) | Funnel Troubleshooting | TOFU/SOFU/MOFU/BOFU, benchmarks, Law of Averages |
| [bonus1](chapters/bonus1-perfect-customer-avatar.md) | Perfect Customer Avatar (Vignola) | Avatar build, Avatar Diary |
| [bonus2](chapters/bonus2-ai-automation-wizardry.md) | AI Automation Wizardry (Lawrence) | Instruction Linking, Custom GPTs, Word Math |
| [bonus3](chapters/bonus3-antifragile-headlines.md) | Antifragile Headlines (West) | Pre-Head/Hook/Sub-Head, emotion × awareness |

## Topic Index
- **Abandoned cart / checkout** → ch08, ch07, ch12
- **Ads (copy)** → ch04 (webinar ad), ch05 (VSL ad), ch06 (trip-wire ad), ch07 (retargeting ad)
- **AI / prompts / automation** → bonus2, bonus1
- **Avatar / audience research** → ch01, bonus1
- **Benchmarks / KPIs** → ch10, ch12, ch03
- **Buyer's Journey / awareness stages** → ch03, ch11, bonus3
- **Call booking / high-ticket** → ch08, ch10, ch12
- **Content / organic traffic** → ch09
- **CTA / PS / urgency** → ch07, ch06
- **Guarantee / risk removal** → ch02, ch06, ch07
- **Headlines / hooks / curiosity** → bonus3, ch04, ch05
- **Indoctrination / myth-busting** → ch05, ch04
- **Loyalty / reviews / referrals** → ch08, ch12
- **Objections** → ch07, ch04, ch06
- **Offer design / pricing** → ch02, ch06
- **Positioning / USP** → ch06
- **Split testing** → ch11
- **Storytelling** → ch04, ch07
- **Traffic channels** → ch09
- **Troubleshooting a funnel** → ch12
- **Trust** → ch00, ch06
- **Upsells / order bumps** → ch08, ch03
- **VSL / squeeze page** → ch05
- **Webinar / registration** → ch04, ch12

## Supporting Files
- [glossary.md](glossary.md): key terms with chapter references
- [patterns.md](patterns.md): techniques with when, how and trade-offs
- [cheatsheet.md](cheatsheet.md): stage → funnel table, benchmarks, decision rules, warning signs

---

## Scope & Limits
These are synthesized summaries, not the book text. Copy formulas are paraphrased templates. The book's "AI Training" sections are only links to the author's site, so their prompts are not included. Benchmarks are the author's targets, not guarantees. The book's own numbers conflict in a few places, and the chapter files flag each one.
