# Formulas, Story Arcs & Techniques — Reece Deployment Reference

**Sources:** Board B v6.19 (story arcs, deployment matrix, objection branches), HL MCP `workflow_registry` (canonical codes, stage, trust state, copy levers; pulled 2026-09-18), and the `antifragile-sales-system` skill (full formulas).
**Naming:** Use the **canonical code** everywhere. The legacy code comes from the registry's `legacy_name` and is shown only so older docs can be matched up.
**Rule:** When a workflow's name and its registry data disagree, pick the formula from the registry's **stage + copy levers**, not from the name.
**Full templates:** each formula below links to its chapter in the `antifragile-sales-system` skill (`AS/chNN`). Load that chapter when you need the complete template.

---

## 1. Story Arcs (SA1–SA5)

| Arc | Emotional path | Use for |
|---|---|---|
| **SA1 Hurricane Damage** | Fear → Relief → Gratitude | Pre-frame, myth-busting, VSL opening, booking urgency, confirmation, retargeting |
| **SA2 Code Compliance Mistake** | Surprise → Anxiety → Determination | Pre-frame, indoctrination secrets, solution-pitch intro, objection trust branch, high-intent indoctrination |
| **SA3 Cheap Window Regret** | Frustration → Regret → Resolve | Indoctrination mistakes, calculator track, solution-pitch flaw, booking positioning, price/competitor objections, sales |
| **SA4 Insurance Claim Disaster** | Shock → Anger → Urgency | Pre-frame, indoctrination alternatives, VSL X-factor, timing objection, retargeting |
| **SA5 Home Value Increase** | Hope → Excitement → Pride | Calculator bridge, high-intent indoctrination, solution social proof, booking investment reframe, offer stack, expansion, referral stories |

Story arcs set the emotional angle; the external constraint (timing, scarcity, cost) drives the call to action.

---

## 2. Deployment Matrix

Buyer stage: **#1** Indifferent · **#2** Curious · **#3** Comparing · **#4** Negotiating · **#5** Committed. Formula ids (F1–F12) point to Section 3.
**Arc source:** unmarked = Board B deployment matrix or the workflow's own node. **†** = no matching matrix row, so the nearest row is used; confirm before relying on it.

| Canonical | Name | Legacy | Stage | Trust state | Copy levers | Pressure | Arcs | Formula | Techniques |
|---|---|---|---|---|---|---|---|---|---|
| E.0 | Master Router | W0.0 | — | n/a | none | none | — | *no copy (routing)* | — |
| E.1 | Risk Report Bridge | W0.1 | #1 | warming | none | none | SA1+SA2+SA4 | F1 | T1, T2, T9 |
| E.2 | Calculator Bridge v2 | W0.2 | #1 | warming | none | none | SA5 (calc bridge) + SA1+SA2+SA4 | F1 | T1, T9 |
| E.3 | Chatbot Qualifier | W0.3 | #1 | warming | curiosity | low | SA1+SA2+SA4 | F1 (survey questions) | T2, T13 |
| E.4 | Canvassing Bridge | W0.4 | #1 | cold | relevance | low | SA1+SA2+SA4 | F1 | T1, T3 |
| E.5 | Unknown Source Bridge | W0.5 | #1 | cold | none | none | SA1+SA2+SA4 | F1 | T1 |
| E.6 | Referral Bridge | W0.6 | #1 | warming | rapport | low | SA1+SA2+SA4 | F1 + borrowed trust from the referrer | T1, T12 |
| E.7 | High-Intent Digital Bridge | W0.7 | #1→#3 | decision-stage | positioning | medium | SA2+SA5 | F1 → F4 (short) | T1, T6 |
| E.8 | Bulk Import Bridge | — | — | — | — | — | — | *no copy (routing)* | — |
| S1.0 | Cold Awakening | W11.0 | #1 | cold | relevance, curiosity | low | SA1+SA3+SA4 † | F10 | T2, T13, T14 |
| S1.1 | Re-engage Weakest Point | S1.1 | #1 | cold | relevance, curiosity, hope | low | SA1+SA3+SA4 † | F10 (lead with an external constraint) | T2, T13, T14 |
| S1.2 | Calculator Re-engagement | W11.2 | #1 | cold | relevance, curiosity, hope | low | SA5+SA3 † | F10 | T2, T13 |
| S1.3 | Stale Lead Revival | — | #1 | dormant | relevance, curiosity, pain-reactivation | low | SA1+SA3+SA4 † | F10 (pain reactivation) | T3, T13, T14 |
| S1.6 | Guide-Sent Re-engagement | WF3 Nurture | #1 | warming | curiosity, rapport | low | SA1+SA3+SA4 † | F10 | T2, T12 |
| S1.7 | CD Re-engagement | CD-Reengagement | #1 | cold | relevance | low | SA1+SA3+SA4 † | F10 | T1, T13 |
| S2.0 | Risk Report Indoctrination | W1.0 | #2 | warming | rapport, storytelling, authority, hope | medium | SA1+SA2+SA3+SA4 | F2 | T4, T5, T12 |
| S2.1 | Calculator Indoctrination v3 | W1.1 | #2 | warming | rapport, storytelling, authority, hope | medium | SA1+SA2+SA3+SA4 | F2 (mistakes lead: SA3) | T4, T5 |
| S2.2 | Chatbot Indoctrination | W1.2 | #2 | warming | rapport, storytelling, authority, hope | medium | SA1+SA2+SA3+SA4 | F2 | T4, T5, T12 |
| S2.3 | High-Intent Abbreviated Indoctrination | W1.3 | #2→#3 | decision-stage | authority, positioning | medium | SA2+SA5 | F2 (2 messages) → F3 | T5, T6 |
| S2.4 | VSL Briefing Push | W2.0 | #2 | warming | authority, positioning, storytelling | medium | SA1+SA2+SA4+SA5 | F2 (VSL promise) | T2, T4, T5 |
| S2.5 | Pricing Accuracy Education | W2.1 | #2 | warming | authority, positioning | medium | SA1+SA2+SA4+SA5 | F2 → F3 (price myths) | T5, T6 |
| S2.6 | Window Estimate Education | W2.2 | #2 | warming | authority, storytelling | medium | SA1+SA2+SA4+SA5 | F2 | T4, T5 |
| L.2-HPA | Home Protection Assessment | WF2 HPA | #2 | warming | authority, storytelling | medium | SA1+SA2+SA4+SA5 † | F2 | T4, T5 |
| S3.0 | Solution Pitch | W3.0 | #3 | decision-stage | positioning, authority | high | SA2+SA3+SA5 | F3 → F4 | T6, T7 |
| S3.1 | Calculator Positioning Burst v3 | W3.1 | #3 | decision-stage | positioning, authority | high | SA2+SA3+SA5 | F4 | T6, T7 |
| S3.2 | WE Path Solution Pitch | W3.2 | #3 | decision-stage | positioning, authority | high | SA2+SA3+SA5 | F3 → F4 | T6, T7 |
| S3.3 | Chatbot Authority & Positioning | W3.3 | #3 | decision-stage | positioning, authority | high | SA2+SA3+SA5 | F4 | T6, T7 |
| S4.0 | Protection Profile Review Nurture | W4.0 | #4 | decision-stage | positioning | high | SA3+SA5+SA1 | F5 | T6, T8, T11 |
| S4.1 | MV Booking | W4.1 | #4 | decision-stage | positioning, authority | high | SA3+SA5+SA1 | F5 | T6, T8, T11 |
| S4.5 | Post-Engagement Seinfeld Nurture | W4.5 | #2–#3 | trust-built | storytelling, authority | medium | all 5, rotating over 12 weeks | F6 | T4, T12 |
| S4.6 | Protection Profile Review Prep | W6.0 | #4 | decision-stage | authority, positioning | high | SA5+SA1 | F7 | T8, T11 |
| S4.7 | Protection Profile Review No-Show Recovery | W7.0 | #4 | decision-stage | urgency, rapport | high | SA5+SA1 † | F8 | T8, T10, T12 |
| S4.10 | Sale Recorded | W10.0 | #5 | customer | none | none | SA5+SA3 (sales scripts) | *no copy (event)* | — |
| S5.1 | Decision Compression Reactivation | W5.1 FS2 | #4 | decision-stage | urgency, scarcity, cognitive-dissonance | compression | SA1+SA3+SA4 † | F9 | T8, T10, T11 |
| S5.2 | Appointment Rescue (Policy Executor) v2 | W5.2 FS3 | #4 | decision-stage | urgency, scarcity, cognitive-dissonance | compression | SA1+SA5 | F9 → F8 | T8, T10, T11 |
| A.CC-1 / A.MV-1 / A.WE-1 | Confirmation Call / Measurement Verification / Window Estimate Reminders | W-C1 / W-M1 / W-E1 | #4 | decision-stage | none | medium | SA5+SA1 | F7 (logistics only) | T8 |
| A.CC-1-N / A.MV-1-N / A.WE-1-N | …No-Show | W-C1N / W-M1N / W-E1N | #4 | decision-stage | urgency | high | SA5+SA1 † | F8 | T8, T10 |
| F.0 | Post-Appointment Follow-Up | W8.0 | #4 | decision-stage | positioning, rapport | high | SA5+SA3 † | F4 (recap) + F11 | T6, T7, T12 |
| O.0 | Objection Handler | W9.0 | #4 | decision-stage | positioning, authority, rapport | high | by branch (see F11) | F11 | T7, T12, T15 |
| O.SP | Spouse Check-in Reminder | — | #4 | decision-stage | rapport | medium | SA5 | F11 (spouse branch) | T7, T12 |
| C.0 | Customer Onboarding | W12.0 | #5 | customer | rapport | low | SA5 + all | F12 | T12 |
| C.1 | Install Progress Updates | W12.1 | #5 | customer | rapport | low | SA5 + all | F12 (status updates) | T12 |
| C.2 | Post-Install Check-In | W12.2 | #5 | customer | rapport | low | SA5 + all | F12 | T12 |
| C.3 | Expansion | W12.3 | #5 | customer | positioning | low | SA5 | F12 (upsell) | T6 |
| C.4 | Review Solicitation | W12.4 | #5 | customer | rapport | medium | SA5 | F12 (review) | T12 |
| C.5 | Referral Overlay | W12.5 | #5 | customer | rapport | low | SA5 | F12 (referral) | T12 |
| C.6 | Review Amplifier | W12.6 | #5 | customer | rapport | low | SA5 | F12 (review) | T12 |
| C.7 | Unprompted Referral Capture | W12.7 | #5 | customer | none | none | — | *no copy (capture)* | — |

**Notes on the † rows:**
- **S1.x** arcs follow the copywriter's Reactivation row (SA1+SA3+SA4). S1.2 uses SA5+SA3 because the calculator track is SA5/SA3 in the arc library.
- **S4.7 and A.x-N** use the Confirm set, matching the S5.2 rescue arcs.
- **S5.1** uses the Retargeting set.
- **F.0** uses the Sales set.
- **L.2-HPA** uses the VSL/Education set.

**Overrides:**
- A behavioral state tag overrides sequence position. `buyer-state:ready-hesitant` jumps to momentum capture. `buyer-state:comparing` forces SA3 positioning.
- A `neg-signal:message-mismatch` tag means switching the story arc in the next message.
- `neg-signal:trust-gap` means injecting SA2 authority plus the guarantee.

---

## 3. Short Fill-In Formulas

Placeholders come from the Copywriting Kitchen: [AUDIENCE] [PROBLEM] [SYMPTOM] [PROMISE] [BENEFIT] [DEADLINE] [SOLUTION] [ALTERNATIVE] [MYTH] [SECRET] [MISTAKE] [EXTERNAL OBJECTION] [INTERNAL OBJECTION] [GUARANTEE] [USP] [OFFER] [ACTION].

**F1 · Pre-Frame / Stage #1.** Make the problem feel relevant, then critical, then urgent. → AS/ch04
> 3 symptom questions ("Have you noticed…", "Do you often…", "Are you…") → the [PROBLEM] escalating toward a crisis (arc beat) → "If [desire], then…" → one next step. Never position Reece yet.

**F2 · Indoctrination: Secret, Mistake or Alternative.** → AS/ch05, AS/ch08 (Trust-Building messages 3–4)
> "Have you ever wondered why [past efforts failed]?" → confirm it with a tie-down → "According to [SOURCE], it's not [MYTH] but [SECRET/MISTAKE] that…" → impact → "And that's not all…" → close on "So how do you [BENEFIT]?" (an open loop).
> *VSL promise variant:* 3 questions ("Are you…", "Do you want…", "Have you been…") → "This short video reveals [insight] so you can [BENEFIT] without [EXTERNAL OBJECTION], even if [INTERNAL OBJECTION]."

**F3 · Solution Pitch: sell the category, not the brand.** → AS/ch05 (9 elements)
> "You could keep [cost of doing nothing / MYTH / ALTERNATIVE]…" → what [SOLUTION] is → why it works where [ALTERNATIVE] can't → metaphor ("[SOLUTION] is like…") → expert and peer proof → why it matters more today → **X Factor**: "Some [SOLUTION]s are [flaw]… Thankfully…"

**F4 · Offer Positioning.** Sell Reece specifically. → AS/ch06
> X Factor ("[OFFER] is a [SOLUTION] that…", plus how it was built) → Relevance ("Why [AUDIENCE] prefer [OFFER] for [PROMISE]") → Superiority (Feel-Felt-Found plus results) → Uniqueness ("A promise no other [SOLUTION] can make: [USP]") → Qualification ("This isn't for everyone…").

**F5 · Booking CTA.** → AS/ch07 (CTA), AS/ch08 (Call Booking)
> Restate [PROMISE] by [DEADLINE] → what happens at the appointment (in-home = the environment change) → 2–3 micro-qualifier questions → 3-part CTA: what to do, why, and why now → booking escape hatch.

**F6 · Seinfeld email.** → Brunson `b1-ch07`; AS/ch08
> A story hook from daily life (a rotating arc) → the lesson it reveals about [PROBLEM/SOLUTION] → one soft link. Roughly 90% story, one offer. Write as a friend who knows windows, not as a company.

**F7 · Confirmation and reminders.** → AS/ch08 (Reminder Sequence)
> Confirmation (date/time + the promise of the call or visit + the ground rules) → daily reminders, each handling one objection (timing, third party, financial…) → evening (offer to reschedule) → morning → 2 hours before → 15 minutes before → "on my way / starting now".

**F8 · No-show recovery.** → AS/ch07 ("Here's Why" story, Power PS)
> "We missed you, [NAME]; no problem." → a reason to rebook now (a real external constraint) → one-tap reschedule → PS: a Coming Crisis or Nothing to Lose PS (see T10).

**F9 · Decision Compression / Flash Sale.** → AS/ch08 (Flash Sale), AS/ch07 (Post-CTA)
> Prepare → Promote → Remind ("last chance to [PROMISE] without [EXTERNAL OBJECTION]") → Urgency ("WARNING: [exact deadline/quantity] + the consequence") → Downsell. Use only real constraints.

**F10 · Re-engagement.** Passive and low pressure. → AS/ch04 (curiosity), AS/ch07 (Power PS)
> A pattern interrupt, or "Has anything changed with [PROBLEM]?" → one curiosity seed or new external constraint → a single low-commitment reply ask. Never compress.

**F11 · Objection Handler.** → AS/ch07 (objection formulas)
> Headline in the prospect's own words ("What about [OBJECTION]?") → "If you're still reading, it means [hope]" → Feel-Felt-Found ("Many homeowners felt… they found [USP] fixed it") → [GUARANTEE] → next step.
> **Branches and their arcs:** Price → SA3 · Timing → SA4+SA1 · Spouse → SA5 · Trust → SA2 · Competitor → SA3 · DIY → SA3+SA4.
> **Time-lapse:** under 90 days, reference the appointment · 91–365 days, re-relevance hook first · 365+ days, cold pattern interrupt.

**F12 · Customer journey.** Never sell, never educate. → AS/ch08 (Loyalty, Upsell)
> Status or milestone → celebrate the result (SA5 pride) → a review ask with a 1–5 rating, then a referral ask sent only to positive reviewers. Never offer an incentive for a review. For C.3 expansion, use a "next level problem/promise" upsell.

---

## 4. Techniques

| # | Technique | What it does | Where it's defined |
|---|---|---|---|
| T1 | Relevant → Critical → Urgent | Beats the three Stage #1 objections, in that order | AS/ch01, AS/ch04 |
| T2 | High-Value Curiosity + breadcrumbing | Curiosity tied to the problem or benefit; close one loop, open the next | AS/ch04 |
| T3 | Double tie-down | Symptom statement plus a tag question the prospect has to agree with | AS/ch04, AS/ch07 |
| T4 | Open-loop indoctrination | "And that's not all…" chaining through secrets, mistakes and alternatives | AS/ch05 |
| T5 | Surrogate endorsement | An expert or code authority endorses the idea, not Reece | AS/ch05 |
| T6 | Law of One | One problem, emotion, solution, benefit and CTA per message | AS/ch05 |
| T7 | Feel-Felt-Found | Empathize, show that others felt the same, show what they found fixed it (ideally the USP) | AS/ch07 |
| T8 | 3-part CTA | What to do, why, and why now | AS/ch07, AS/ch08 |
| T9 | Pain vs Promise contrast | Put the problem next to the promise in headlines and CTAs | AS/ch04 |
| T10 | Power PS | Point of No Return, Regret, Coming Crisis, Nothing to Lose and 6 more; stack up to 3 | AS/ch07 |
| T11 | Real external constraint | Timing, scarcity or cost as the reason to act, never fake urgency | AS/ch06, AS/ch07 |
| T12 | Attractive Character voice | Backstory, parables, flaws and polarity; sound like a friend who knows windows | Brunson `b1-ch04` |
| T13 | Pattern interrupt / channel switch | Break the silence (switch SMS ↔ email, change the format) | AS/ch08; Board B neg-signal routing |
| T14 | Seth's Super Seven | Frame the benefit as Fast, Easy, Powerful, Safe, Durable, Enjoyable or Stylish | AS/ch11 |
| T15 | Hook-Story-Offer diagnosis | Low opens = hook · low click-through = story · low conversion = offer | Brunson `b1-ch02`; AS/ch12 |

---

## 5. Unassigned (no registry workflow yet — do not write copy until assigned)

| Item | Source | Status |
|---|---|---|
| **S4.2** | Registry: "S4.2 Reserved" (draft, no copy levers) | Reserved, not built |
| **Window Estimate / HPA booking copy** | Board B node "S4.2 Window Estimate / HPA Booking" | No workflow owns it. **Do not** put it under A.WE-1, which is a confirmation workflow |
| **W6.1** | Board B S4.0 node, "GHL Stack: W5.0 + S5.1 + S4.6 + W6.1" | No registry match; purpose unknown |
| **TBD-S5.0 (W5.0) FS1 Cold Booking Push** | Board B, BUILD NEW | Not in the registry |
| **TBD-S5.3 (W5.3) Downsell Path** | Board B, BUILD NEW | Not in the registry |
| **Winback (TBD-C.8)** | Board B node labelled "C.6 Winback" | C.6 is Review Amplifier in the registry; C.8 isn't registered yet |
