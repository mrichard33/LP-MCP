---
name: antifragile-copywriter
description: "(v2) Use this skill whenever you need to write marketing copy, SMS, email body content, funnel content, ad copy, VSL scripts, subject lines, or any persuasive messaging for Reece Windows & Doors following the Antifragile Sales System. Trigger on: 'write copy', 'draft content', 'email body', 'SMS copy', 'subject line', 'story arc', 'belief shift', 'indoctrination', 'objection handling', 'positioning', 'solution pitch', 'HSO', 'buyer stage', 'Seinfeld email', or when creating content for any GHL workflow messaging step. Also trigger when asked to review or audit existing copy against the Antifragile framework. Ensures every word follows the 5-stage buyer journey, correct formulas, right story arcs, and Reece brand voice. Do NOT use for HTML template structure (reece-html-email), build guides (reece-ghl-build-guide), or diagnostics (ghl-mcp-diagnostic)."
metadata:
  version: "2.0"
---

# Antifragile Copywriter — Strategic Content Engine (v2)

**Version 2.0 (2026-09-18):** adds `references/formulas.md` (deployment matrix keyed to canonical `workflow_registry` codes, story arcs SA1–SA5, short formulas F1–F12, techniques T1–T15); replaces legacy W#.# workflow codes with canonical codes; adds cross-references to the `antifragile-sales-system` and `brunson-secrets` reference skills.

## Overview

Every piece of marketing content for Reece Windows & Doors is governed by the Antifragile Sales System framework. This skill is the single source of truth for the copywriting framework, messaging strategy, and content rules. Read `references/formulas.md` for the complete formula library, story arcs, technique index, and deployment matrix.

## Quick Start

1. Read `references/formulas.md` for the deployment matrix (canonical workflow codes), story arcs, short formulas, and techniques. For full formula templates, load the `antifragile-sales-system` chapter it links to.
2. **Identify the buyer stage** (#1–#5)
3. **Identify the funnel position** (canonical workflow code from `workflow_registry`, e.g. S2.0, and step)
4. **Select the formula** for the stage transition
5. **Select the story arc(s)** from the deployment matrix
6. **Select the technique(s)** from the technique library
7. **Write** following the rules below
8. **Verify** against the output checklist

---

## Core Framework: The Antifragile Sales System

### Trust Model (Fragile → Antifragile)

Sustainable marketing builds trust through four mechanisms:

- **Convenience** — Easy to do business with (quickest, least sticky)
- **Charisma** — Likable, memorable brand
- **Competence** — Proven results (dissolves fear barriers)
- **Character** — Genuine care about solving their problem (creates loyalty/promoters)

Convenience-based trust is fragile. The system earns Competence and Character trust so the funnel becomes antifragile — stronger under market stress, competition, and uncertainty. Every piece of copy must serve the mission of building these trust types intentionally.

### Funnel Structure

- **TOFU** — Capture attention/leads
- **SOFU** — Nurture, indoctrinate, educate (email/SMS/content)
- **MOFU** — Convert interest to action (appointments)
- **BOFU** — Close, maximize LTV, referrals

### DotCom Secrets Integration

These 10 principles govern funnel and content strategy:

1. **Value Ladder:** Bait → Trip-Wire → Core → Profit Max → Continuity
2. **Attractive Character:** Backstory, Parables, Flaws, Polarity in all messaging
3. **Seinfeld Nurture (S4.5):** 12 weekly emails for engaged non-bookers
4. **HSO Mandate:** Hook → Story → Offer at every touchpoint
5. **Funnel Stack:** Confirmation pages introduce next value ladder tier
6. **Hyperactive Buyer Alert:** Score >50 in 48h = fast-track
7. **Survey Funnel:** Chatbot buckets for segmentation
8. **Pre-Frame Bridges:** Entry bridges set emotional/intellectual frame
9. **Environment Change:** In-home appointment = high-value assessment (WE/HPA, NOT phone)
10. **Micro-Qualifier:** 2–3 qualifying questions before booking CTA

### Related Reference Skills

For deeper formula detail, see **antifragile-sales-system**. For funnel strategy, storytelling (Epiphany Bridge) and traffic, see **brunson-secrets**. This skill always governs the final Reece copy.

---

## The First Question: What Stage Is the Reader In?

Before writing a single word, answer this. Everything flows from it.

| Stage | Name | Messaging Goal | Must NOT |
|-------|------|----------------|----------|
| #1 Indifferent | Unaware of problem severity | Make problem RELEVANT, CRITICAL, URGENT | Pitch, price, position, or push booking |
| #2 Curious | Exploring solutions | Reveal SECRETS, expose MISTAKES, debunk ALTERNATIVES | Hard-sell, compare vendors |
| #3 Comparing | Evaluating vs competitors | Position as RELEVANT, SUPERIOR, UNIQUE | Re-educate (they already know) |
| #4 Negotiating | Decided, hasn't committed | Overcome specific objection, compress decision | More education, generic follow-up |
| #5 Committed | Customer | Validate, delight, referral | Sell, educate, make them feel like a prospect |

**Most common mistake:** Writing Stage #3 positioning for Stage #1 prospects. Match message to stage.

---

## HSO Mandate — Every Touchpoint

**Hook:** Pattern interrupt. Earns 5 more seconds. Lives in subject lines, first sentences.
**Story:** The structured persuasive case. Where formulas live.
**Offer:** Next micro-commitment. Always present. Match to trust level.

Diagnostic: Low opens = weak Hook | Low read-through = weak Story | Low conversions = weak Offer

### Booking Escape Hatch (DS Rec #8)

Every email includes a booking path. L1-L2: P.S./footer ("Ready now? Skip ahead: [link]"). L3+: primary CTA.

---

## The Attractive Character — DS Rec #2

All messaging speaks through the AC persona — a person, not a brand.

**Backstory:** Expert who's seen what happens when families don't protect their homes.
**Parables:** The 5 story arcs (SA1–SA5) are teaching stories.
**Flaws:** "We're not the cheapest — if you're looking for cheapest, we're probably not the right fit."
**Polarity:** Takes clear positions. "Insurance protects insurers, not homeowners."

---

## Brand Voice

**Tone:** Expert neighbor, not corporate salesperson. Florida local, anchored to the lead's own market (Fort Lauderdale, Tampa, Orlando, Sarasota, Fort Myers, Lakeland, Jacksonville, St. Petersburg) via `{{contact.city}}`, never "South Florida" as a default. Problem-first, conversational.

**Crews (locked wording):** "factory-trained, Reece-certified crews, dedicated exclusively to Reece projects, never random subcontractors." Do NOT write "in-house crews" or "we don't subcontract" (GTD §1.4 is canon; VSL v3.7 pillar-two line is superseded).

**Never use:** "Dear valued customer" | exclamation marks in subjects | ALL CAPS body | "Don't miss out!" / "Act now!" / "Limited time!" | emoji in email | "We at Reece..." | "I just wanted to..." | jargon without explanation

**Always use:** `{{contact.first_name}}` | `{{contact.city}}` | `{{custom_values.rep_name}}` | contractions | specific numbers ("$28,000 increase" not "significant increase") | questions mirroring inner dialogue

---

## Channel Rules

### Email = The Argument
Structured persuasion: data, stories, evidence. 150-400 words. HSO. Deploys story arcs and formulas.

### SMS = The Emotional Hook
Standalone emotional response. NEVER summarizes email. NEVER says "I just sent you an email." Under 160 chars ideal, 320 max. Opens with `{{contact.first_name}}`. Includes booking link (raw URL). Emotionally independent.

### SMS GPT Prompt Template
Under 300 chars total. One question, one question mark. Return final text only — no labels/tags/brackets.

### Chatbot = The Conversation
Responsive, not scripted. Qualifies through questions. DS Rec #7 Survey Funnel approach.

### VSL = The Full Experience
Opening → Indoctrination → Solution Pitch → Offer. Heavy use of Techniques #5 and #6.

---

## Writing for Workflow Positions

| Position | Purpose | Formula | Story Arcs | Key Rule |
|----------|---------|---------|------------|----------|
| Pre-Frame (E.x) | Set emotional/intellectual frame | HSO + light belief disruption | SA1, SA2, SA4 | Warm, "you're in the right place" |
| Indoctrination (S2.0–S2.3) | Unaware → problem-aware → solution-aware | Secrets/Mistakes/Alternatives | SA1–SA4 | Never position Reece yet |
| Education/VSL (S2.4–S2.6) | Deepen understanding, build L3 | Bridge indoctrination→solution | SA1, SA2, SA4, SA5 | Introduce SOLUTION TYPE, not brand |
| Solution Pitch (S3.x) | Build solution trust | Intro→Social Proof→Flaw/X-Factor | SA2, SA3, SA5 | Positioning BEGINS here |
| Booking (S4.0–S4.1) | Convert to appointment | HSO + strong Offer | SA3, SA5, SA1 | Confident, direct, not pushy |
| Seinfeld (S4.5) | Keep non-bookers warm (12 wks) | DS Rec #3, lighter HSO | All 5 rotating | Friend who knows windows, not company |
| Objection (O.0) | Address specific objection | 6 branches (see formulas.md) | Match to objection | Never argue — acknowledge then reframe |
| Re-engagement (S1.x) | Re-engage cold prospects | Sprint bursts + pattern interrupts | SA1, SA3, SA4 | Has anything changed? |
| Customer Journey (C.x) | Validate, delight, referrals | Status + milestones + referral ask | SA5 primary | NEVER sell, NEVER educate |

---

## Trust Escalation

L1 Attention (Convenience) → L2 Credibility (Competence) → L3 Solution (Competence+Character) → L4 Commitment (Character+Convenience) → L5 Experience (All) → L6 Ownership (All four)

**Rules:** Never ask for commitment beyond current level. Objection trust gaps: Price=L3, Timing=L4, Trust=L2, Spouse=L4×2, Competitor=L3, DIY=L2. Booking Escape Hatch exception: booking link always present but positioned by trust level.

---

## Copy Audit Framework

When reviewing existing copy, evaluate:

1. **Stage alignment** — message appropriate for buyer stage?
2. **HSO compliance** — Hook, Story, Offer identifiable?
3. **Story arc deployment** — right arc for funnel position?
4. **Trust level match** — ask matches current trust level?
5. **Formula fidelity** — correct formula for stage transition?
6. **SMS independence** — emotionally standalone?
7. **AC persona** — expert neighbor or corporate brochure?
8. **Booking Escape Hatch** — booking path present?
9. **Local relevance** — lead's own Florida market referenced (not "South Florida" by default)?
10. **Technique selection** — correct technique for position?

---

## Output Checklist

- [ ] Buyer stage identified (#1–#5)
- [ ] Funnel position identified (canonical code)
- [ ] Correct formula for stage transition
- [ ] Story arc(s) from deployment matrix
- [ ] Technique(s) from library
- [ ] HSO present
- [ ] Booking Escape Hatch included
- [ ] AC persona voice
- [ ] Local relevance to the lead's own Florida market
- [ ] Crew wording matches GTD §1.4 (no "in-house" / "we don't subcontract")
- [ ] Trust level respected
- [ ] No premature positioning
- [ ] SMS emotionally independent (if applicable)
- [ ] Specific numbers over vague claims
- [ ] No banned phrases/formatting
